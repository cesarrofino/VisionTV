package com.haymette.visiontv

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import android.os.SystemClock
import android.util.Base64
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Hosts the local HTML/CSS/JS UI and exposes a minimal, validated bridge to native features. */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("vision_tv", MODE_PRIVATE) }
    private var pickId = 0
    private var fails = 0
    private var lockUntil = 0L

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = 0xFF030A2B.toInt()
        window.navigationBarColor = 0xFF030A2B.toInt()
        setupWeb()
    }

    /** Cria (ou recria) a WebView. Se o sistema matar o processo da WebView durante a reprodução, recriamos em vez de fechar a app. */
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb() {
        web = WebView(this)
        web.setBackgroundColor(0xFF030A2B.toInt())
        web.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
            textZoom = 100
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) =
                !r.url.toString().startsWith("file:///android_asset/")

            override fun onRenderProcessGone(v: WebView, d: RenderProcessGoneDetail): Boolean {
                try { (v.parent as? ViewGroup)?.removeView(v); v.destroy() } catch (_: Exception) {}
                setupWeb()
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Native")
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.onResumeApp&&window.onResumeApp()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.goBack&&window.goBack())?1:0") { if (it != "1") finish() }
    }

    private fun cb(id: Int, ok: Boolean, text: String) = runOnUiThread {
        web.evaluateJavascript("window.__cb($id,$ok,${JSONObject.quote(text)})", null)
    }

    private fun readCapped(i: InputStream): String {
        val out = ByteArrayOutputStream(); val buf = ByteArray(16384); var total = 0
        while (true) {
            val n = i.read(buf); if (n < 0) break
            total += n; if (total > 40_000_000) throw Exception("Ficheiro demasiado grande")
            out.write(buf, 0, n)
        }
        return out.toString("UTF-8")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 77) return
        val uri = data?.data
        if (res != RESULT_OK || uri == null) { cb(pickId, false, "Cancelado"); return }
        val id = pickId
        Thread {
            try { contentResolver.openInputStream(uri)!!.use { cb(id, true, readCapped(it)) } }
            catch (e: Exception) { cb(id, false, e.message ?: "Erro ao ler o ficheiro") }
        }.start()
    }

    inner class Bridge {
        @JavascriptInterface fun version(): String = packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"

        @Suppress("DEPRECATION")
        private fun currentCode(): Int = packageManager.getPackageInfo(packageName, 0).versionCode

        @JavascriptInterface fun versionCode(): Int = currentCode()

        @JavascriptInterface fun updateRepo(): String = BuildConfig.UPDATE_REPO

        /** Downloads the release APK (GitHub release of this app only) and validates package + version. */
        @JavascriptInterface fun downloadUpdate(url: String, id: Int) {
            Thread {
                try {
                    val repo = BuildConfig.UPDATE_REPO
                    if (repo.isBlank() || !url.startsWith("https://github.com/$repo/releases/download/")) throw Exception("Origem da atualização não permitida")
                    val dir = File(cacheDir, "updates").apply { mkdirs() }
                    val f = File(dir, "update.apk"); f.delete()
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000; c.readTimeout = 30000
                    c.setRequestProperty("User-Agent", "VISIONTV/1.0")
                    if (c.responseCode !in 200..299) throw Exception("Resposta HTTP ${c.responseCode}")
                    val total = c.contentLengthLong; var done = 0L; var last = -1
                    c.inputStream.use { i -> f.outputStream().use { o ->
                        val buf = ByteArray(32768)
                        while (true) {
                            val n = i.read(buf); if (n < 0) break
                            o.write(buf, 0, n); done += n
                            if (total > 0) { val p = (done * 100 / total).toInt(); if (p != last) { last = p; runOnUiThread { web.evaluateJavascript("window.__prog&&window.__prog($p)", null) } } }
                        }
                    } }
                    if (total > 0 && done != total) throw Exception("Download incompleto")
                    @Suppress("DEPRECATION") val info = packageManager.getPackageArchiveInfo(f.path, 0) ?: throw Exception("APK inválido")
                    if (info.packageName != packageName) throw Exception("O APK não corresponde a esta aplicação")
                    @Suppress("DEPRECATION") if (info.versionCode <= currentCode()) throw Exception("O APK não é mais recente")
                    cb(id, true, "ready")
                } catch (e: Exception) { File(File(cacheDir, "updates"), "update.apk").delete(); cb(id, false, e.message ?: "Falha no download") }
            }.start()
        }

        /** Opens the system installer for the downloaded APK. Android requires the user to confirm. */
        @JavascriptInterface fun installUpdate(): String {
            val f = File(File(cacheDir, "updates"), "update.apk")
            if (!f.exists()) return "missing"
            if (!packageManager.canRequestPackageInstalls()) {
                runOnUiThread { startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))) }
                return "perm"
            }
            val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f)
            runOnUiThread {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            return "ok"
        }

        @JavascriptInterface fun kvGet(k: String): String = prefs.getString("kv_$k", "") ?: ""

        @JavascriptInterface fun kvSet(k: String, v: String): Boolean {
            if (!Regex("[A-Za-z0-9_.:-]{1,80}").matches(k) || v.length > 12_000_000) return false
            prefs.edit().putString("kv_$k", v).apply(); return true
        }

        @JavascriptInterface fun fetchText(url: String, id: Int) {
            Thread {
                try {
                    if (!Regex("https?://.+", RegexOption.IGNORE_CASE).matches(url)) throw Exception("URL inválido")
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000; c.readTimeout = 25000
                    c.setRequestProperty("User-Agent", "VISIONTV/1.0")
                    if (c.responseCode !in 200..299) throw Exception("Resposta HTTP ${c.responseCode}")
                    c.inputStream.use { cb(id, true, readCapped(it)) }
                } catch (e: Exception) { cb(id, false, e.message ?: "Falha de rede") }
            }.start()
        }

        @JavascriptInterface fun pickFile(id: Int) {
            runOnUiThread {
                pickId = id
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
                @Suppress("DEPRECATION") startActivityForResult(i, 77)
            }
        }

        private fun hash(pin: String, salt: ByteArray): ByteArray =
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 120000, 256)).encoded

        @JavascriptInterface fun pinExists(): Boolean = prefs.contains("pin_h")

        @JavascriptInterface fun pinSet(p: String): Boolean {
            if (!Regex("\\d{4,8}").matches(p)) return false
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            prefs.edit().putString("pin_s", Base64.encodeToString(salt, 0))
                .putString("pin_h", Base64.encodeToString(hash(p, salt), 0)).apply()
            return true
        }

        @JavascriptInterface fun pinCheck(p: String): Boolean {
            if (SystemClock.elapsedRealtime() < lockUntil) return false
            val s = prefs.getString("pin_s", null) ?: return false
            val h = prefs.getString("pin_h", null) ?: return false
            val ok = MessageDigest.isEqual(hash(p, Base64.decode(s, 0)), Base64.decode(h, 0))
            if (ok) fails = 0 else if (++fails >= 5) { fails = 0; lockUntil = SystemClock.elapsedRealtime() + 60000 }
            return ok
        }

        @JavascriptInterface fun locked(): Boolean = SystemClock.elapsedRealtime() < lockUntil

        @JavascriptInterface fun play(json: String): Boolean {
            return try {
                val o = JSONObject(json); val a = o.getJSONArray("items")
                val names = ArrayList<String>(); val urls = ArrayList<String>()
                val groups = ArrayList<String>(); val progs = ArrayList<String>()
                val refs = ArrayList<String>(); val uas = ArrayList<String>()
                for (i in 0 until minOf(a.length(), 200)) {
                    val x = a.getJSONObject(i); val u = x.optString("u")
                    if (u.startsWith("http://") || u.startsWith("https://")) {
                        names.add(x.optString("n")); urls.add(u)
                        groups.add(x.optString("g")); progs.add(x.optString("e"))
                        refs.add(x.optString("r")); uas.add(x.optString("a"))
                    }
                }
                if (urls.isEmpty()) return false
                PlayData.names = names; PlayData.urls = urls; PlayData.groups = groups; PlayData.progs = progs
                PlayData.refs = refs; PlayData.uas = uas
                PlayData.fav = o.optString("fav"); PlayData.aspect = o.optInt("aspect", 0)
                PlayData.index = o.optInt("i", 0).coerceIn(0, urls.size - 1)
                runOnUiThread {
                    try { startActivity(Intent(this@MainActivity, PlayerActivity::class.java)) }
                    catch (e: Exception) { PlayData.clear() }
                }
                true
            } catch (e: Exception) { false }
        }
    }
}
