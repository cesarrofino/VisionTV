package com.haymette.visiontv

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

/** Full-screen Media3/ExoPlayer playback with queue, retry, errors, aspect ratio and PiP. */
class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var pv: PlayerView
    private lateinit var spin: ProgressBar
    private lateinit var errBox: LinearLayout
    private lateinit var errTxt: TextView
    private lateinit var title: TextView
    private var index = 0
    private var zoomMode = 0
    private val modes = intArrayOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_ZOOM, AspectRatioFrameLayout.RESIZE_MODE_FILL)

    private fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        index = intent.getIntExtra("index", 0)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        pv = PlayerView(this).apply { keepScreenOn = true; setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER) }
        spin = ProgressBar(this)
        title = TextView(this).apply { setTextColor(Color.WHITE); textSize = 18f; setPadding(40, 28, 40, 8) }
        errTxt = TextView(this).apply { setTextColor(Color.WHITE); textSize = 17f; gravity = Gravity.CENTER; setPadding(40, 20, 40, 20) }
        errBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; visibility = View.GONE
            setBackgroundColor(0xCC061820.toInt())
            addView(errTxt)
            addView(btn("Tentar novamente") { errBox.visibility = View.GONE; player?.prepare(); player?.play() })
            addView(btn("Voltar") { finish() })
        }
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        root.addView(pv, FrameLayout.LayoutParams(match, match))
        root.addView(title, FrameLayout.LayoutParams(match, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        root.addView(spin, FrameLayout.LayoutParams(120, 120, Gravity.CENTER))
        root.addView(errBox, FrameLayout.LayoutParams(match, match))
        val zoom = btn("Proporção") { zoomMode = (zoomMode + 1) % 3; pv.resizeMode = modes[zoomMode] }
        root.addView(zoom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END))
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            title.visibility = v; zoom.visibility = v
        })
        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        val names = intent.getStringArrayListExtra("names") ?: arrayListOf()
        val urls = intent.getStringArrayListExtra("urls") ?: arrayListOf()
        if (urls.isEmpty()) { finish(); return }
        val p = ExoPlayer.Builder(this).build()
        p.setMediaItems(urls.indices.map { i ->
            MediaItem.Builder().setUri(urls[i]).setMediaMetadata(MediaMetadata.Builder().setTitle(names.getOrElse(i) { "" }).build()).build()
        }, index.coerceIn(0, urls.size - 1), 0L)
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(st: Int) {
                spin.visibility = if (st == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                if (st == Player.STATE_READY) errBox.visibility = View.GONE
            }
            override fun onMediaItemTransition(m: MediaItem?, r: Int) {
                title.text = m?.mediaMetadata?.title ?: ""; index = p.currentMediaItemIndex
            }
            override fun onPlayerError(e: PlaybackException) {
                spin.visibility = View.GONE
                errTxt.text = when (e.errorCode) {
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED, PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                        "Sem ligação ou o servidor não respondeu. Verifique a Internet."
                    PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "A fonte recusou o pedido ou o canal não está disponível."
                    PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED, PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
                    PlaybackException.ERROR_CODE_DECODING_FAILED -> "Este formato de transmissão não é compatível."
                    else -> "Não foi possível reproduzir este canal."
                }
                errBox.visibility = View.VISIBLE
            }
        })
        pv.player = p; pv.requestFocus(); player = p
        title.text = names.getOrElse(index) { "" }
        p.prepare(); p.playWhenReady = true
    }

    override fun onUserLeaveHint() {
        if (Build.VERSION.SDK_INT >= 26 && packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE) && player?.isPlaying == true)
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
    }

    override fun onPictureInPictureModeChanged(inPip: Boolean, c: Configuration) {
        super.onPictureInPictureModeChanged(inPip, c)
        pv.useController = !inPip
    }

    override fun onStop() {
        super.onStop()
        player?.release(); player = null; pv.player = null
    }
}
