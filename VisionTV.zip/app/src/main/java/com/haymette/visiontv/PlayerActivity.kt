package com.haymette.visiontv

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Leitor em ecrã inteiro (Media3/ExoPlayer) com controlos próprios:
 * barra superior com estado em direto e qualidade, controlos centrais, lista lateral de canais,
 * favoritos, proporção, volume/brilho por gestos, repetição automática em caso de erro e PiP.
 */
@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
class PlayerActivity : Activity() {
    private companion object {
        val ACC = 0xFF1F7BFF.toInt()
        val ACC2 = 0xFF0B4FE0.toInt()
        val PANEL = 0xF2070F3A.toInt()
        val TX2 = 0xFFB4C8F0.toInt()
        val LIVE = 0xFFE5484D.toInt()
        val GLASS = 0x66050C33
        val GLASS_PRESSED = 0x99FFFFFF.toInt()
        const val HIDE_MS = 4000L
        const val MAX_RETRIES = 2
        val ASPECT_NAMES = arrayOf("Ajustar", "Cortar", "Esticar")
        const val DEFAULT_UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    }

    private val handler = Handler(Looper.getMainLooper())
    private val prefs: SharedPreferences by lazy { getSharedPreferences("vision_tv", MODE_PRIVATE) }
    private lateinit var am: AudioManager
    private var player: ExoPlayer? = null

    private var names = ArrayList<String>()
    private var urls = ArrayList<String>()
    private var groups = List(0) { "" }
    private var progs = List(0) { "" }
    private var refs = List(0) { "" }
    private var uas = List(0) { "" }
    @Volatile private var curRef = ""
    @Volatile private var curUa = ""
    private var favKey = ""
    private var index = 0
    private var zoomMode = 0
    private val modes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )

    private var retries = 0
    private var reconnecting = false
    private var controlsOn = true
    private var panelOpen = false
    private var panelW = 0

    private lateinit var root: FrameLayout
    private lateinit var pv: PlayerView
    private lateinit var controls: FrameLayout
    private lateinit var spin: ProgressBar
    private lateinit var titleTv: TextView
    private lateinit var subTv: TextView
    private lateinit var qualityTv: TextView
    private lateinit var playBtn: ImageButton
    private lateinit var muteBtn: ImageButton
    private lateinit var favPill: TextView
    private lateinit var aspectPill: TextView
    private lateinit var hud: LinearLayout
    private lateinit var hudIcon: ImageView
    private lateinit var hudText: TextView
    private lateinit var hudBar: ProgressBar
    private lateinit var panel: LinearLayout
    private lateinit var chList: ListView
    private lateinit var err: LinearLayout
    private lateinit var errMsg: TextView
    private val adapter = ChAdapter()

    // gestos
    private var gKind = 0
    private var gAcc = 0f
    private var gStart = 0f
    private var gLeft = false

    private val hideTask = Runnable { if (!panelOpen && err.visibility != View.VISIBLE) hideControls() }
    private val hudTask = Runnable { hud.animate().alpha(0f).setDuration(200).withEndAction { hud.visibility = View.GONE }.start() }
    private val retryTask = Runnable {
        reconnecting = false
        player?.let { it.seekToDefaultPosition(); it.prepare(); it.play() }
        updateSpinner()
    }

    // ---------- utilitários de UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun rect(fill: Int, radius: Int, stroke: Int = 0, strokeDp: Int = 0, oval: Boolean = false) = GradientDrawable().apply {
        setShape(if (oval) GradientDrawable.OVAL else GradientDrawable.RECTANGLE)
        setColor(fill)
        if (!oval) cornerRadius = dp(radius).toFloat()
        if (strokeDp > 0) setStroke(dp(strokeDp), stroke)
    }

    private fun states(fill: Int, pressed: Int, radius: Int, oval: Boolean = false, border: Int = 0x26FFFFFF) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), rect(fill, radius, ACC, 2, oval))
        addState(intArrayOf(android.R.attr.state_pressed), rect(pressed, radius, 0, 0, oval))
        addState(intArrayOf(), rect(fill, radius, border, 1, oval))
    }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        includeFontPadding = false
        if (bold) typeface = Typeface.DEFAULT_BOLD
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun iconBtn(res: Int, size: Int, pad: Int, fill: Int, pressed: Int, desc: String, onClick: () -> Unit) =
        ImageButton(this).apply {
            setImageResource(res)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            background = states(fill, pressed, 0, true)
            setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
            contentDescription = desc
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
            isFocusable = true
            setOnClickListener { onClick(); poke() }
        }

    private fun pill(res: Int, label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER_VERTICAL
        includeFontPadding = false
        setCompoundDrawablesWithIntrinsicBounds(res, 0, 0, 0)
        compoundDrawablePadding = dp(8)
        setPadding(dp(14), 0, dp(18), 0)
        minHeight = dp(44)
        background = states(GLASS, GLASS_PRESSED, 14)
        isFocusable = true
        isClickable = true
        setOnClickListener { onClick(); poke() }
    }

    private fun textBtn(label: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 14f
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(22), 0, dp(22), 0)
        minHeight = dp(46)
        background = if (primary) states(ACC, ACC2, 14, false, 0) else states(0x26FFFFFF, 0x4DFFFFFF, 14)
        isFocusable = true
        isClickable = true
        setOnClickListener { onClick() }
    }

    // ---------- ciclo de vida ----------
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        // Lista vinda de PlayData (não do Intent): evita TransactionTooLargeException e fecho da app.
        names = ArrayList(PlayData.names)
        urls = ArrayList(PlayData.urls)
        if (urls.isEmpty()) { finish(); return }
        val g = PlayData.groups; val e = PlayData.progs
        groups = List(urls.size) { g.getOrNull(it) ?: "" }
        progs = List(urls.size) { e.getOrNull(it) ?: "" }
        refs = List(urls.size) { PlayData.refs.getOrNull(it) ?: "" }
        uas = List(urls.size) { PlayData.uas.getOrNull(it) ?: "" }
        while (names.size < urls.size) names.add("")
        index = PlayData.index.coerceIn(0, urls.size - 1)
        favKey = PlayData.fav.takeIf { Regex("[A-Za-z0-9_.:-]{1,80}").matches(it) } ?: ""
        zoomMode = PlayData.aspect.coerceIn(0, 2)
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.also {
                it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        buildUi()
        setContentView(root)
        refreshMeta()
        refreshMute()
    }

    @Suppress("DEPRECATION")
    private fun applyImmersive() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersive()
    }

    override fun onStart() {
        super.onStart()
        applyImmersive()
        if (player != null) return
        applyHeaders(index)
        // Rede: redirecionamentos http↔https, User-Agent de browser e Referer por canal (#EXTVLCOPT).
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000).setReadTimeoutMs(20000)
            .setDefaultRequestProperties(mapOf("User-Agent" to DEFAULT_UA))
        val ds = ResolvingDataSource.Factory(http) { spec ->
            val h = HashMap<String, String>()
            if (curRef.isNotBlank()) {
                h["Referer"] = curRef
                try { val u = Uri.parse(curRef); if (!u.scheme.isNullOrBlank() && !u.host.isNullOrBlank()) h["Origin"] = "${u.scheme}://${u.host}" } catch (_: Exception) {}
            }
            if (curUa.isNotBlank()) h["User-Agent"] = curUa
            if (h.isEmpty()) spec else spec.withAdditionalHeaders(h)
        }
        // Decodificador alternativo se o de hardware falhar (evita falhas em certos canais).
        val rf = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        val p = ExoPlayer.Builder(this, rf)
            .setMediaSourceFactory(DefaultMediaSourceFactory(ds))
            .setHandleAudioBecomingNoisy(true).build()
        p.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true
        )
        p.setMediaItems(urls.indices.map { i ->
            MediaItem.Builder().setUri(urls[i])
                .setMediaMetadata(MediaMetadata.Builder().setTitle(names[i]).build()).build()
        }, index, 0L)
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                updateSpinner()
                if (state == Player.STATE_READY) {
                    retries = 0
                    err.visibility = View.GONE
                    schedHide()
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { refreshPlayIcon(); schedHide() }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { refreshPlayIcon() }
            override fun onMediaItemTransition(m: MediaItem?, reason: Int) {
                index = p.currentMediaItemIndex
                applyHeaders(index)
                qualityTv.visibility = View.GONE
                refreshMeta()
            }
            override fun onVideoSizeChanged(videoSize: VideoSize) { showQuality(videoSize.height) }
            override fun onPlayerError(e: PlaybackException) { handleError(e) }
        })
        pv.player = p
        player = p
        p.prepare()
        p.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        pv.player = null
    }

    // ---------- construção da interface ----------
    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        pv = PlayerView(this).apply {
            useController = false
            setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
            resizeMode = modes[zoomMode]
            keepScreenOn = true
        }
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (panelOpen) closePanel() else toggleControls()
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (e1 == null || panelOpen) return false
                if (gKind == 0) {
                    gKind = if (abs(dy) > abs(dx) * 1.4f) 1 else 2
                    if (gKind == 1) {
                        gLeft = e1.x < pv.width / 2f
                        gAcc = 0f
                        gStart = if (gLeft) currentBrightness() else currentVolume()
                    }
                }
                if (gKind != 1) return false
                gAcc += dy / pv.height.toFloat() * 1.3f
                val v = (gStart + gAcc).coerceIn(0f, 1f)
                if (gLeft) setBrightness(v) else setVolume(v)
                return true
            }
        })
        pv.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) gKind = 0
            true
        }
        root.addView(pv, FrameLayout.LayoutParams(match, match))

        // --- controlos ---
        controls = FrameLayout(this)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), dp(14), dp(24), dp(30))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xD9000000.toInt(), 0x00000000))
        }
        top.addView(iconBtn(R.drawable.ic_pl_back, 44, 10, GLASS, GLASS_PRESSED, "Voltar") { finish() })

        titleTv = tv("", 18f, Color.WHITE, true)
        subTv = tv("", 13f, TX2)
        qualityTv = tv("", 11f, Color.WHITE, true).apply {
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = rect(0x33FFFFFF, 7)
            visibility = View.GONE
        }
        val liveDot = View(this).apply { background = rect(LIVE, 0, 0, 0, true) }
        val live = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(9), dp(4))
            background = rect(0x33E5484D, 7, 0x88E5484D.toInt(), 1)
            addView(liveDot, LinearLayout.LayoutParams(dp(7), dp(7)).apply { rightMargin = dp(6) })
            addView(tv("AO VIVO", 11f, 0xFFFF8A8E.toInt(), true))
        }
        val meta = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(live)
            addView(qualityTv, LinearLayout.LayoutParams(wrap, wrap).apply { leftMargin = dp(8) })
            addView(subTv, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(10) })
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(titleTv)
            addView(meta, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(7) })
        }
        top.addView(titles, LinearLayout.LayoutParams(0, wrap, 1f).apply { leftMargin = dp(14); rightMargin = dp(14) })
        if (canPip()) top.addView(iconBtn(R.drawable.ic_pl_pip, 44, 10, GLASS, GLASS_PRESSED, "Imagem sobre imagem") { enterPip() })
        controls.addView(top, FrameLayout.LayoutParams(match, wrap, Gravity.TOP))

        val center = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        center.addView(iconBtn(R.drawable.ic_pl_prev, 52, 14, GLASS, GLASS_PRESSED, "Canal anterior") { step(-1) })
        playBtn = iconBtn(R.drawable.ic_pl_pause, 76, 22, ACC, ACC2, "Reproduzir ou pausar") { togglePlay() }
        center.addView(playBtn, (playBtn.layoutParams as LinearLayout.LayoutParams).apply { leftMargin = dp(30); rightMargin = dp(30) })
        center.addView(iconBtn(R.drawable.ic_pl_next, 52, 14, GLASS, GLASS_PRESSED, "Canal seguinte") { step(1) })
        controls.addView(center, FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), dp(30), dp(24), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xE6000000.toInt(), 0x00000000))
        }
        bottom.addView(pill(R.drawable.ic_pl_channels, "Canais") { openPanel() })
        aspectPill = pill(R.drawable.ic_pl_aspect, "Proporção: ${ASPECT_NAMES[zoomMode]}") { cycleAspect() }
        bottom.addView(aspectPill, LinearLayout.LayoutParams(wrap, wrap).apply { leftMargin = dp(10) })
        favPill = pill(R.drawable.ic_pl_heart, "Favorito") { toggleFav() }
        bottom.addView(favPill, LinearLayout.LayoutParams(wrap, wrap).apply { leftMargin = dp(10) })
        bottom.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        muteBtn = iconBtn(R.drawable.ic_pl_volume, 44, 10, GLASS, GLASS_PRESSED, "Silenciar") { toggleMute() }
        bottom.addView(muteBtn)
        controls.addView(bottom, FrameLayout.LayoutParams(match, wrap, Gravity.BOTTOM))
        root.addView(controls, FrameLayout.LayoutParams(match, match))

        // --- indicador de carregamento ---
        spin = ProgressBar(this).apply {
            indeterminateTintList = ColorStateList.valueOf(ACC)
            visibility = View.GONE
        }
        root.addView(spin, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))

        // --- HUD de volume/brilho/mensagens ---
        hudIcon = ImageView(this)
        hudText = tv("", 14f, Color.WHITE, true)
        hudBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(ACC)
            progressBackgroundTintList = ColorStateList.valueOf(0x33FFFFFF)
        }
        hud = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(18), dp(12))
            background = rect(0xE6070F3A.toInt(), 16, 0x33FFFFFF, 1)
            visibility = View.GONE
            addView(hudIcon, LinearLayout.LayoutParams(dp(22), dp(22)).apply { rightMargin = dp(12) })
            addView(hudText)
            addView(hudBar, LinearLayout.LayoutParams(dp(110), dp(4)).apply { leftMargin = dp(14) })
        }
        root.addView(hud, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(26) })

        // --- lista lateral de canais ---
        panelW = minOf(dp(340), (resources.displayMetrics.widthPixels * 0.5f).toInt())
        val closeP = iconBtn(R.drawable.ic_pl_close, 40, 9, 0x00000000, 0x33FFFFFF, "Fechar lista") { closePanel() }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(10), dp(8))
            addView(tv("Canais", 17f, Color.WHITE, true), LinearLayout.LayoutParams(0, wrap, 1f))
            addView(tv("${urls.size}", 13f, TX2).apply { setPadding(0, 0, dp(8), 0) })
            addView(closeP)
        }
        chList = ListView(this).apply {
            divider = null
            dividerHeight = 0
            selector = rect(0x331F7BFF, 12)
            cacheColorHint = 0
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            setPadding(dp(8), dp(4), dp(8), dp(12))
            this.adapter = this@PlayerActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> switchTo(pos); closePanel() }
        }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rect(PANEL, 0)
            isClickable = true
            visibility = View.GONE
            setPadding(0, dp(8), 0, 0)
            addView(head)
            addView(chList, LinearLayout.LayoutParams(match, 0, 1f))
        }
        root.addView(panel, FrameLayout.LayoutParams(panelW, match, Gravity.END))

        // --- erro ---
        val warn = ImageView(this).apply {
            setImageResource(R.drawable.ic_pl_alert)
            setColorFilter(0xFFF2C94C.toInt())
        }
        errMsg = tv("", 14f, TX2).apply { gravity = Gravity.CENTER; maxLines = 3; maxWidth = dp(420) }
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(textBtn("Tentar novamente", true) { retryNow() })
            addView(textBtn("Próximo canal", false) { step(1) }, LinearLayout.LayoutParams(wrap, wrap).apply { leftMargin = dp(10) })
            addView(textBtn("Voltar", false) { finish() }, LinearLayout.LayoutParams(wrap, wrap).apply { leftMargin = dp(10) })
        }
        err = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xF2071C2A.toInt())
            isClickable = true
            visibility = View.GONE
            setPadding(dp(32), dp(20), dp(32), dp(20))
            addView(warn, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(tv("Não foi possível reproduzir", 19f, Color.WHITE, true), LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(14) })
            addView(errMsg, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(8) })
            addView(actions, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(22) })
        }
        root.addView(err, FrameLayout.LayoutParams(match, match))
    }

    private inner class ChAdapter : BaseAdapter() {
        override fun getCount() = urls.size
        override fun getItem(position: Int): Any = names[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val cur = position == index
            val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
            val texts = LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(tv(names[position], 14f, Color.WHITE, cur))
                if (groups[position].isNotBlank()) addView(
                    tv(groups[position], 11.5f, TX2),
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, wrap).apply { topMargin = dp(3) }
                )
            }
            return LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(58)
                setPadding(dp(8), dp(8), dp(12), dp(8))
                background = if (cur) rect(0x261F7BFF, 12, ACC, 1) else null
                addView(tv("${position + 1}", 12f, if (cur) ACC else TX2, cur).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(34), wrap))
                addView(texts, LinearLayout.LayoutParams(0, wrap, 1f))
                if (cur) addView(ImageView(this@PlayerActivity).apply {
                    setImageResource(R.drawable.ic_pl_play)
                    setColorFilter(ACC)
                }, LinearLayout.LayoutParams(dp(18), dp(18)))
            }
        }
    }

    // ---------- controlos: visibilidade ----------
    private fun showControls() {
        controlsOn = true
        controls.animate().cancel()
        controls.visibility = View.VISIBLE
        controls.animate().alpha(1f).setDuration(180).start()
        schedHide()
    }

    private fun hideControls() {
        controlsOn = false
        controls.animate().cancel()
        controls.animate().alpha(0f).setDuration(220).withEndAction { if (!controlsOn) controls.visibility = View.GONE }.start()
    }

    private fun toggleControls() { if (controlsOn) hideControls() else showControls() }

    private fun schedHide() {
        handler.removeCallbacks(hideTask)
        if (controlsOn && player?.isPlaying == true && !panelOpen && err.visibility != View.VISIBLE) handler.postDelayed(hideTask, HIDE_MS)
    }

    private fun poke() { if (!controlsOn) showControls() else schedHide() }

    private fun flash(msg: String, icon: Int, progress: Int = -1) {
        hudIcon.setImageResource(icon)
        hudText.text = msg
        if (progress >= 0) { hudBar.progress = progress; hudBar.visibility = View.VISIBLE } else hudBar.visibility = View.GONE
        hud.animate().cancel()
        hud.alpha = 1f
        hud.visibility = View.VISIBLE
        handler.removeCallbacks(hudTask)
        handler.postDelayed(hudTask, 1100)
        hudIcon.setColorFilter(Color.WHITE)
    }

    // ---------- lista lateral ----------
    private fun openPanel() {
        panelOpen = true
        hideControls()
        adapter.notifyDataSetChanged()
        panel.visibility = View.VISIBLE
        panel.translationX = panelW.toFloat()
        panel.animate().translationX(0f).setDuration(220).start()
        chList.setSelection(maxOf(0, index - 2))
        chList.requestFocus()
    }

    private fun closePanel() {
        if (!panelOpen) return
        panelOpen = false
        panel.animate().translationX(panelW.toFloat()).setDuration(200).withEndAction { if (!panelOpen) panel.visibility = View.GONE }.start()
        pv.requestFocus()
    }

    // ---------- reprodução ----------
    private fun togglePlay() {
        val p = player ?: return
        if (p.isPlaying || p.playWhenReady) p.pause() else {
            if (p.isCurrentMediaItemLive) p.seekToDefaultPosition()
            if (p.playbackState == Player.STATE_IDLE) p.prepare()
            p.play()
        }
        refreshPlayIcon()
    }

    private fun refreshPlayIcon() {
        val on = player?.let { it.isPlaying || it.playWhenReady } ?: false
        playBtn.setImageResource(if (on) R.drawable.ic_pl_pause else R.drawable.ic_pl_play)
        if (!on) { handler.removeCallbacks(hideTask); if (!controlsOn) showControls() }
    }

    private fun step(dir: Int) {
        val n = urls.size
        if (n > 1) switchTo((index + dir + n) % n)
    }

    private fun applyHeaders(i: Int) {
        curRef = refs.getOrNull(i) ?: ""
        curUa = uas.getOrNull(i) ?: ""
    }

    private fun switchTo(i: Int) {
        applyHeaders(i)
        retries = 0
        reconnecting = false
        handler.removeCallbacks(retryTask)
        err.visibility = View.GONE
        index = i
        player?.let { it.seekToDefaultPosition(i); it.prepare(); it.play() }
        refreshMeta()
        updateSpinner()
    }

    private fun retryNow() {
        retries = 0
        reconnecting = false
        handler.removeCallbacks(retryTask)
        err.visibility = View.GONE
        player?.let { it.seekToDefaultPosition(); it.prepare(); it.play() }
        updateSpinner()
    }

    private fun updateSpinner() {
        val buffering = player?.playbackState == Player.STATE_BUFFERING
        spin.visibility = if ((buffering || reconnecting) && err.visibility != View.VISIBLE) View.VISIBLE else View.GONE
    }

    private fun handleError(e: PlaybackException) {
        if (isFinishing || isDestroyed) return
        if (retries < MAX_RETRIES) {
            retries++
            reconnecting = true
            updateSpinner()
            handler.removeCallbacks(retryTask)
            handler.postDelayed(retryTask, 1500L * retries)
            return
        }
        reconnecting = false
        errMsg.text = when (e.errorCode) {
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                "Sem ligação ou o servidor não respondeu. Verifique a Internet."
            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "A fonte recusou o pedido ou o canal não está disponível."
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
            PlaybackException.ERROR_CODE_DECODING_FAILED -> "Este formato de transmissão não é compatível."
            else -> "Não foi possível reproduzir este canal."
        }
        err.visibility = View.VISIBLE
        updateSpinner()
        handler.removeCallbacks(hideTask)
    }

    private fun showQuality(h: Int) {
        if (h <= 0) { qualityTv.visibility = View.GONE; return }
        val label = when { h >= 2160 -> "4K"; h >= 1080 -> "FHD"; h >= 720 -> "HD"; else -> "SD" }
        qualityTv.text = "$label  ${h}p"
        qualityTv.visibility = View.VISIBLE
    }

    private fun refreshMeta() {
        titleTv.text = names[index]
        subTv.text = progs[index].ifBlank { groups[index].ifBlank { "Canal" } }
        refreshFav()
        adapter.notifyDataSetChanged()
    }

    private fun cycleAspect() {
        zoomMode = (zoomMode + 1) % modes.size
        pv.resizeMode = modes[zoomMode]
        aspectPill.text = "Proporção: ${ASPECT_NAMES[zoomMode]}"
        flash("Proporção: ${ASPECT_NAMES[zoomMode]}", R.drawable.ic_pl_aspect)
    }

    // ---------- favoritos (partilhados com a interface web) ----------
    private fun favList(): MutableList<String> {
        val raw = prefs.getString("kv_$favKey", "") ?: ""
        return try {
            val a = JSONArray(if (raw.isBlank()) "[]" else raw)
            MutableList(a.length()) { a.getString(it) }
        } catch (e: Exception) { mutableListOf() }
    }

    private fun refreshFav() {
        val on = favKey.isNotEmpty() && favList().contains(urls[index])
        favPill.setCompoundDrawablesWithIntrinsicBounds(if (on) R.drawable.ic_pl_heart_on else R.drawable.ic_pl_heart, 0, 0, 0)
        favPill.text = if (on) "Nos favoritos" else "Favorito"
        favPill.visibility = if (favKey.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun toggleFav() {
        if (favKey.isEmpty()) return
        val l = favList()
        val u = urls[index]
        val on = !l.contains(u)
        if (on) l.add(0, u) else l.remove(u)
        prefs.edit().putString("kv_$favKey", JSONArray(l).toString()).apply()
        refreshFav()
        flash(if (on) "Adicionado aos favoritos" else "Removido dos favoritos", if (on) R.drawable.ic_pl_heart_on else R.drawable.ic_pl_heart)
    }

    // ---------- volume e brilho ----------
    private fun currentVolume(): Float {
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
    }

    private fun setVolume(v: Float) {
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (v * max).roundToInt(), 0)
        refreshMute()
        flash("${(v * 100).roundToInt()}%", if (v <= 0f) R.drawable.ic_pl_mute else R.drawable.ic_pl_volume, (v * 100).roundToInt())
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        return if (b >= 0f) b else 0.5f
    }

    private fun setBrightness(v: Float) {
        window.attributes = window.attributes.also { it.screenBrightness = v.coerceIn(0.02f, 1f) }
        flash("${(v * 100).roundToInt()}%", R.drawable.ic_pl_bright, (v * 100).roundToInt())
    }

    private fun toggleMute() {
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
        refreshMute()
    }

    private fun refreshMute() {
        muteBtn.setImageResource(if (am.isStreamMute(AudioManager.STREAM_MUSIC)) R.drawable.ic_pl_mute else R.drawable.ic_pl_volume)
    }

    // ---------- imagem sobre imagem ----------
    private fun canPip() = Build.VERSION.SDK_INT >= 26 && packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)

    private fun enterPip() {
        if (!canPip()) return
        closePanel()
        try { enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()) } catch (e: Exception) { /* PiP indisponível */ }
    }

    override fun onUserLeaveHint() {
        if (player?.isPlaying == true) enterPip()
    }

    override fun onPictureInPictureModeChanged(inPip: Boolean, c: Configuration) {
        super.onPictureInPictureModeChanged(inPip, c)
        if (inPip) {
            controls.visibility = View.GONE
            panel.visibility = View.GONE
            panelOpen = false
            hud.visibility = View.GONE
        } else {
            controlsOn = false
            showControls()
        }
    }

    // ---------- teclado / telecomando ----------
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val hidden = !controlsOn && !panelOpen
        when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_HEADSETHOOK -> { togglePlay(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY -> { player?.play(); return true }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> { player?.pause(); return true }
            KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_CHANNEL_UP -> { step(1); return true }
            KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_CHANNEL_DOWN -> { step(-1); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> if (hidden) { showControls(); playBtn.requestFocus(); return true }
            KeyEvent.KEYCODE_DPAD_UP -> if (hidden) { step(-1); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> if (hidden) { step(1); return true }
        }
        if (controlsOn) schedHide()
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (panelOpen) closePanel() else super.onBackPressed()
    }
}
