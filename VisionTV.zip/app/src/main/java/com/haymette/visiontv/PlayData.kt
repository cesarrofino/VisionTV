package com.haymette.visiontv

/**
 * Lista de reprodução partilhada entre a MainActivity e o leitor.
 * Evita enviar centenas de URLs por Intent (limite de ~1 MB → TransactionTooLargeException → app fecha).
 */
object PlayData {
    @Volatile var names: List<String> = emptyList()
    @Volatile var urls: List<String> = emptyList()
    @Volatile var groups: List<String> = emptyList()
    @Volatile var progs: List<String> = emptyList()
    @Volatile var refs: List<String> = emptyList()
    @Volatile var uas: List<String> = emptyList()
    @Volatile var fav: String = ""
    @Volatile var aspect: Int = 0
    @Volatile var index: Int = 0

    fun clear() {
        names = emptyList(); urls = emptyList(); groups = emptyList(); progs = emptyList()
        refs = emptyList(); uas = emptyList(); fav = ""; aspect = 0; index = 0
    }
}
