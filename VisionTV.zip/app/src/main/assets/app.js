'use strict';
/* VISION TV — Haymette Tech. Interface em JavaScript puro; funcionalidades nativas via window.Native. */
const N = window.Native, $ = s => document.querySelector(s), app = $('#app');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cbs = {}; let cid = 0;
window.__cb = (id, ok, t) => { const c = cbs[id]; delete cbs[id]; c && c(ok, t); };
const bridge = fn => new Promise((res, rej) => { const i = ++cid; cbs[i] = (ok, t) => ok ? res(t) : rej(new Error(t)); fn(i); });
const fetchText = u => bridge(i => N.fetchText(u, i));
const pickFile = () => bridge(i => N.pickFile(i));
const kv = { get(k, d) { try { const v = N.kvGet(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }, set(k, v) { return N.kvSet(k, JSON.stringify(v)); } };
const toast = m => { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.remove('show'), 2800); };

/* ---------- Ícones SVG (sprite em index.html) e marcas ---------- */
const ic = (n, c = '') => `<svg class="i ${c}" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-${n}"/></svg>`;
let gid = 0;
const mark = (s = 64) => { const g = 'lm' + (++gid); return `<svg class="logo" width="${s}" height="${s}" viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="${g}" x1="8" y1="6" x2="56" y2="58" gradientUnits="userSpaceOnUse"><stop stop-color="#6FE0FF"/><stop offset=".55" stop-color="#2B7BFF"/><stop offset="1" stop-color="#6A3CFF"/></linearGradient></defs><path d="M14 10.5c0-3 3.2-4.8 5.8-3.3l32.5 19.4c2.5 1.5 2.5 5.1 0 6.6L19.8 53.6c-2.6 1.5-5.8-.3-5.8-3.3z" fill="url(#${g})"/><path d="M14 10.5c0-3 3.2-4.8 5.8-3.3L40 19.3 14 36z" fill="#fff" opacity=".2"/></svg>`; };
const hmark = () => { const g = 'hm' + (++gid); return `<svg width="38" height="38" viewBox="0 0 38 38" aria-hidden="true"><defs><linearGradient id="${g}" x1="0" y1="0" x2="38" y2="38" gradientUnits="userSpaceOnUse"><stop stop-color="#5FB0FF"/><stop offset="1" stop-color="#1B3FD8"/></linearGradient></defs><rect width="38" height="38" rx="11" fill="url(#${g})"/><path d="M12 10v18M26 10v18M12 19h14" stroke="#fff" stroke-width="3.4" stroke-linecap="round" fill="none"/></svg>`; };
const AVC = [['#2BB5D4', '#1B7FA6'], ['#7C6CF0', '#4A3FC4'], ['#F2994A', '#D9622B'], ['#33C48D', '#1C8F66'], ['#EB5E87', '#BE2F5E'], ['#F2C94C', '#C9962A'], ['#5AA9F7', '#2F6FD0'], ['#9AA7B2', '#5D6B78']];
const ai = p => typeof p.av === 'number' ? p.av % 8 : ((p.name || 'A').charCodeAt(0) || 0) % 8;
const avatar = (p, c = '') => `<span class="av ${c}" style="--a:${AVC[ai(p)][0]};--b:${AVC[ai(p)][1]}">${esc(((p.name || '?').trim()[0] || '?').toUpperCase())}</span>`;

/* ---------- Classificação por idade ---------- */
const grp = a => a < 12 ? 'kids' : a < 18 ? 'teen' : 'adult';
const GL = { kids: 'Infantil (0–11)', teen: 'Adolescente (12–17)', adult: 'Adulto (18+)' };
const ALLOW = { kids: ['KIDS'], teen: ['KIDS', 'TEEN', 'GENERAL'], adult: ['KIDS', 'TEEN', 'GENERAL', 'ADULT', 'UNKNOWN'] };
function classify(g) {
  g = (g || '').toLowerCase(); if (!g) return 'UNKNOWN';
  if (/xxx|adult|adulto|18\+|erotic|porn/.test(g)) return 'ADULT';
  if (/kid|child|infant|crian|cartoon|animat|desenh|junior|baby/.test(g)) return 'KIDS';
  if (/sport|desport|music|m[uú]sic|document|educa|scien|ci[eê]ncia|nature|natureza/.test(g)) return 'TEEN';
  if (/news|not[ií]cias|entertain|entreten|general|geral|lifestyle|cultur|weather|comedy|famil|cooking|travel|outdoor|business|legislative|religio|classic|relax|auto|shop/.test(g)) return 'GENERAL';
  return 'UNKNOWN';
}
const okFor = (c, p = active) => !!p && ALLOW[grp(p.age)].includes(c.k);
const isSport = c => /sport|desport|futebol|soccer|football/i.test(c.g || '');
const tags = c => (c.g || '').split(';').map(s => s.trim()).filter(Boolean);

/* ---------- Estado ---------- */
let profiles = kv.get('profiles', []), active = null, sources = kv.get('sources', []), cache = null;
if (profiles.some(p => typeof p.av !== 'number')) { profiles.forEach(p => { p.av = ai(p); }); kv.set('profiles', profiles); }
const S = { tab: 'home', manage: false, cat: '', country: '', q: '', src: '', limit: 60, epg: {}, L: {}, busy: 0, lib: 'fav', sr: 'main' };
const saveSources = () => { kv.set('sources', sources); cache = null; };
const favKey = () => 'fav_' + active.id, histKey = () => 'hist_' + active.id;
const CRANK = { PT: 0, BR: 1 };
function chans() {
  if (cache && cache.p === active.id) return cache.l;
  const l = [], seen = new Set();
  for (const s of sources) if (s.on) for (const c of kv.get('ch_' + s.id, [])) {
    if (seen.has(c.u)) continue;
    c.s = s.id; if (!c.c && s.cc) c.c = s.cc;
    if (okFor(c)) { seen.add(c.u); l.push(c); }
  }
  const rk = c => (c.c in CRANK ? CRANK[c.c] : 2) * 2 + (logoUrl(c) ? 0 : 1);
  l.sort((a, b) => rk(a) - rk(b) || a.n.localeCompare(b.n, 'pt'));
  cache = { p: active.id, l }; return l;
}
const byUrl = us => { const m = new Map(chans().map(c => [c.u, c])); return us.map(u => m.get(u)).filter(Boolean); };
const favs = () => byUrl(kv.get(favKey(), []));
const hist = () => byUrl(kv.get(histKey(), []));
const isFav = c => kv.get(favKey(), []).includes(c.u);
const hostOf = u => { try { return new URL(u).host; } catch (e) { return u || ''; } };
const when = t => t ? new Date(t).toLocaleString('pt-PT', { dateStyle: 'short', timeStyle: 'short' }) : '—';

/* ---------- M3U / XMLTV ---------- */
function parseM3U(t) {
  const out = []; let cur = null;
  for (let l of t.split(/\r?\n/)) {
    l = l.trim(); if (!l) continue;
    if (l.startsWith('#EXTINF')) {
      const a = {}; l.replace(/([\w-]+)="([^"]*)"/g, (m, k, v) => { a[k.toLowerCase()] = v; return m; });
      const n = (l.slice(l.lastIndexOf(',') + 1).trim()) || a['tvg-name'] || '';
      cur = { n, l: a['tvg-logo'] || '', g: a['group-title'] || '', t: a['tvg-id'] || '', c: (a['tvg-country'] || (/\.([a-z]{2})(?:@|$)/i.exec(a['tvg-id'] || '') || [])[1] || '').toUpperCase(), k: classify(a['group-title']) };
    } else if (/^#EXTVLCOPT:/i.test(l) && cur) {
      const m = /^#EXTVLCOPT:([^=]+)=(.*)$/i.exec(l);
      if (m) { const k = m[1].trim().toLowerCase(); if (k === 'http-referrer' || k === 'http-referer') cur.r = m[2].trim(); else if (k === 'http-user-agent') cur.a = m[2].trim(); }
    } else if (l[0] !== '#' && cur) {
      if (/^https?:\/\//i.test(l) && cur.n) { cur.u = l; out.push(cur); }
      cur = null;
    }
  }
  return out;
}
function xmlTime(s) {
  const m = /^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)\s*([+-]\d{4})?/.exec(s || ''); if (!m) return 0;
  let t = Date.UTC(+m[1], m[2] - 1, +m[3], +m[4], +m[5], +m[6]);
  if (m[7]) t -= (m[7][0] === '-' ? -1 : 1) * (+m[7].slice(1, 3) * 60 + +m[7].slice(3, 5)) * 60000;
  return t;
}
function parseEPG(txt) {
  const doc = new DOMParser().parseFromString(txt, 'text/xml');
  if (doc.querySelector('parsererror')) throw new Error('XMLTV inválido');
  const now = Date.now(), out = {};
  doc.querySelectorAll('programme').forEach(p => {
    const s = xmlTime(p.getAttribute('start')), e = xmlTime(p.getAttribute('stop'));
    if (!s || !e || e < now - 6 * 3600e3 || s > now + 36 * 3600e3) return;
    const id = p.getAttribute('channel'); if (!id) return;
    (out[id] = out[id] || []).push([s, e, p.querySelector('title')?.textContent || '', p.querySelector('desc')?.textContent || '']);
  });
  return out;
}
const hh = t => new Date(t).toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });
function nowNext(c) {
  const l = c.t && S.epg[c.t]; if (!l) return null; const n = Date.now();
  const cur = l.find(p => p[0] <= n && n < p[1]); return cur ? { cur, next: l.find(p => p[0] >= cur[1]) } : null;
}
const np = c => { const x = nowNext(c); if (!x) return ''; const [s, e, t] = x.cur;
  return `<small class="np">${hh(s)}–${hh(e)} · ${esc(t)}</small><i class="bar"><u style="width:${Math.round((Date.now() - s) / (e - s) * 100)}%"></u></i>`; };

/* ---------- Calendário de futebol (TheSportsDB) ---------- */
const FX_LEAGUES = [[4344, 'Liga Portugal', /liga portugal|primeira liga/i], [4351, 'Brasileirão', /brasileir/i], [4480, 'Champions League', /champions/i]];
const fxOn = () => kv.get('fxl', [4344, 4351, 4480]);
const FX_API = 'https://www.thesportsdb.com/api/v1/json/3/';
const norm = t => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\b(hd|fhd|sd|tv|canal|channel)\b/g, '').replace(/[^a-z0-9]/g, '');
const fxTs = e => { const t = e.strTimestamp ? Date.parse(/[zZ+]/.test(e.strTimestamp.slice(10)) ? e.strTimestamp : e.strTimestamp + 'Z') : Date.parse(`${e.dateEvent}T${e.strTime || '00:00:00'}Z`); return isNaN(t) ? 0 : t; };
async function updateFixtures(force) {
  const old = kv.get('fx', { at: 0, list: [] });
  if (!force && Date.now() - old.at < 3 * 36e5 && old.list.length && old.list.every(f => 'hb' in f)) { S.fx = old.list; return; }
  const map = new Map(), now = Date.now();
  const add = (e, lg, ch) => {
    const ts = fxTs(e); if (!ts || ts < now - 2 * 36e5 || ts > now + 8 * 864e5) return;
    const id = e.idEvent || `${e.strHomeTeam}-${e.strAwayTeam}-${ts}`;
    const f = map.get(id) || { id, lg: lg || e.strLeague || 'Futebol', h: e.strHomeTeam || (e.strEvent || '').split(' vs ')[0], a: e.strAwayTeam || (e.strEvent || '').split(' vs ')[1] || '', ts, ch: [], hb: '', ab: '' };
    if (!f.hb && e.strHomeTeamBadge) f.hb = e.strHomeTeamBadge; if (!f.ab && e.strAwayTeamBadge) f.ab = e.strAwayTeamBadge;
    if (ch && !f.ch.includes(ch)) f.ch.push(ch); map.set(id, f);
  };
  const on = FX_LEAGUES.filter(l => fxOn().includes(l[0]));
  await Promise.all(on.map(([id, n]) => fetchText(`${FX_API}eventsnextleague.php?id=${id}`).then(t => (JSON.parse(t).events || []).forEach(e => add(e, n))).catch(() => {})));
  const jobs = [];
  for (let d = 0; d < 7; d++) {
    const day = new Date(now + d * 864e5).toISOString().slice(0, 10);
    jobs.push(fetchText(`${FX_API}eventstv.php?d=${day}&s=Soccer`).then(t => (JSON.parse(t).tvevents || []).forEach(e => {
      const lg = on.find(l => l[2].test(e.strLeague || '')); if (!lg) return;
      add(e, lg[1], e.strChannel);
    })).catch(() => {}));
  }
  await Promise.all(jobs);
  const list = [...map.values()].sort((a, b) => a.ts - b.ts).slice(0, 40);
  if (list.length) { kv.set('fx', { at: Date.now(), list }); S.fx = list; } else S.fx = old.list;
  if (active && S.tab !== 'tv' && $('#view') && !document.querySelector('.overlay,.modal')) view(true);
}
function fxChan(f) {
  const all = chans();
  for (const n of f.ch) { const k = norm(n); if (k.length < 3) continue; const c = all.find(x => { const y = norm(x.n); return y === k || y.includes(k) || k.includes(y) && y.length > 3; }); if (c) return c; }
  return null;
}
const fxWhen = ts => { const d = new Date(ts), t = new Date(), same = d.toDateString() === t.toDateString(), tm = new Date(t.getTime() + 864e5).toDateString() === d.toDateString();
  return (same ? 'Hoje' : tm ? 'Amanhã' : d.toLocaleDateString('pt-PT', { weekday: 'short', day: 'numeric', month: 'short' })) + ' · ' + hh(ts); };
function fxList(n) {
  const l = (S.fx || []).filter(f => f.ts > Date.now() - 2 * 36e5).slice(0, n); if (!l.length) return '';
  S.L.fx = [];
  return `<div class="fxl">${l.map(f => { const c = fxChan(f), live = f.ts <= Date.now(); if (c) S.L.fx.push(c);
    return `<div class="fx"><span class="crests s">${crest(f.hb, f.h)}${crest(f.ab, f.a)}</span><div class="fxm"><small>${esc(f.lg)}</small><b>${esc(f.h)}${f.a ? ' vs ' + esc(f.a) : ''}</b><span class="fxt">${live ? '<i class="liv">AO VIVO</i>' : esc(fxWhen(f.ts))}</span>`
    + `<small class="fxc">${ic('tv', 's')} ${f.ch.length ? esc(f.ch.join(' · ')) : 'Canal por confirmar'}</small></div>`
    + (c ? `<button class="btn sm" data-a="play" data-k="fx" data-u="${esc(c.u)}">${ic('play', 'f s')} Ver</button>` : '') + `</div>`; }).join('')}</div>`;
}
function fxHero(f) {
  const c = fxChan(f), live = f.ts <= Date.now(); S.L.fxh = c ? [c] : [];
  return `<div class="hero fxh"><div class="body"><span class="live"><i></i>${live ? 'EM DIRETO' : 'PRÓXIMO JOGO'}</span><h1>${esc(f.h)}${f.a ? '<br>vs ' + esc(f.a) : ''}</h1><p>${esc(f.lg)}</p>`
    + `<p class="when">${ic('clock', 's')} ${live ? 'A decorrer' : esc(fxWhen(f.ts))}</p><span class="tvc">${ic('tv', 's')} ${f.ch.length ? esc(f.ch.join(' · ')) : 'Canal por confirmar'}</span>`
    + (c ? `<button class="btn" data-a="play" data-k="fxh" data-u="${esc(c.u)}">Assistir agora ${ic('chev', 's')}</button>` : `<button class="btn dis" disabled>Canal por confirmar</button>`)
    + `</div><div class="crests">${crest(f.hb, f.h)}${crest(f.ab, f.a)}</div></div>`;
}
function fxCards(l) {
  S.L.fxd = []; return `<div class="hs">${l.map(f => { const c = fxChan(f); if (c) S.L.fxd.push(c);
    const inner = `<span class="thumb"><span class="crests">${crest(f.hb, f.h)}${crest(f.ab, f.a)}</span></span><b>${esc(f.h)}${f.a ? ' vs ' + esc(f.a) : ''}</b><small>${esc(f.lg)}</small><small class="tm">${esc(fxWhen(f.ts))}</small>`;
    return c ? `<button class="card fxd" data-a="play" data-k="fxd" data-u="${esc(c.u)}">${inner}</button>` : `<div class="card fxd">${inner}</div>`; }).join('')}</div>`;
}
const fxSection = () => { if (!kv.get('fxhome', true)) return ''; const h = fxList(5); return h ? `<section>${shd('Futebol · próximos jogos', 'sport')}${h}</section>` : ''; };

/* ---------- Diálogos (folhas inferiores) ---------- */
function dlg(html, collect, okL = 'OK', noL = 'Cancelar') {
  return new Promise(res => {
    const m = document.createElement('div'); m.className = 'modal';
    m.innerHTML = `<div class="box" role="dialog" aria-modal="true"><div class="grab"></div>${html}<p class="err" id="derr"></p><div class="acts">${noL ? `<button class="btn sec" data-x>${noL}</button>` : ''}<button class="btn" data-ok>${okL}</button></div></div>`;
    document.body.append(m);
    const done = v => { m.remove(); res(v); }; m._c = () => done(null);
    m.onclick = e => {
      if (e.target === m) return done(null);
      const r = e.target.closest('[data-ret]'); if (r) return done({ ret: r.dataset.ret });
      const sw = e.target.closest('.sw button'); if (sw) { m.querySelectorAll('.sw button').forEach(b => b.classList.toggle('on', b === sw)); return; }
      if (e.target.closest('[data-x]')) return done(null);
      if (e.target.closest('[data-ok]')) { try { const v = collect(m); if (v !== undefined) done(v); } catch (x) { m.querySelector('#derr').textContent = x.message; } }
    };
    const f = m.querySelector('input,select'); if (f) f.focus();
  });
}
const ask = (title, msg, okL = 'Confirmar') => dlg(`<h2>${esc(title)}</h2><p class="txt">${esc(msg)}</p>`, () => true, okL);
const askPin = msg => dlg(`<h2>${esc(msg)}</h2><label>PIN parental</label><input id="pin" type="password" inputmode="numeric" maxlength="8" placeholder="4 a 8 dígitos" autocomplete="off">`, m => {
  if (N.locked()) throw new Error('Demasiadas tentativas. Aguarde 1 minuto.');
  const v = m.querySelector('#pin').value; if (!/^\d{4,8}$/.test(v)) throw new Error('O PIN tem 4 a 8 dígitos');
  if (!N.pinCheck(v)) throw new Error('PIN incorreto'); return true; });
const newPin = () => dlg(`<h2>Definir PIN parental</h2><p class="txt">4 a 8 dígitos. Protege perfis adultos e alterações sensíveis.</p><label>Novo PIN</label><input id="p1" type="password" inputmode="numeric" maxlength="8"><label>Repetir PIN</label><input id="p2" type="password" inputmode="numeric" maxlength="8">`, m => {
  const a = m.querySelector('#p1').value, b = m.querySelector('#p2').value;
  if (!/^\d{4,8}$/.test(a)) throw new Error('O PIN tem 4 a 8 dígitos'); if (a !== b) throw new Error('Os PIN não coincidem');
  return N.pinSet(a); }, 'Guardar');
async function ensurePin() { if (N.pinExists()) return true; return !!(await newPin()); }

/* ---------- Boas-vindas ---------- */
const TERMS = `<h3>O que é</h3><p class="txt">O VISION TV é uma plataforma para organizar e assistir a canais de televisão através de fontes que você configura, com perfis familiares e controlo parental.</p>
<h3>Canais e fontes</h3><p class="txt">A aplicação organiza canais e fontes de transmissão. Não hospeda canais: vem pré-configurada com a lista pública mundial do projeto iptv-org (canais disponibilizados publicamente, sem conteúdo adulto) e permite adicionar as suas próprias listas em Definições › Fontes de Transmissão. A disponibilidade de cada canal depende do respetivo emissor.</p>
<h3>Perfis e idade</h3><p class="txt">Até 3 perfis locais. Cada perfil tem uma faixa etária (0–11, 12–17, 18+) que filtra os conteúdos. A classificação depende dos metadados da fonte (ex.: group-title); conteúdo sem classificação fiável é ocultado em perfis de menores. Nenhum filtro substitui a supervisão de um adulto.</p>
<h3>Privacidade</h3><p class="txt">Funciona sem conta e sem registo. Perfis, idades, favoritos e listas ficam apenas neste dispositivo. Não existem analytics nem rastreamento. É necessária Internet para reproduzir e atualizar fontes.</p>
<h3>Licença e avisos legais</h3><p class="txt">Utilize apenas transmissões e listas cujo acesso e utilização sejam autorizados. Os direitos de cada canal e transmissão pertencem aos respetivos titulares; o VISION TV não detém direitos sobre conteúdos de terceiros nem contorna DRM, autenticação ou restrições de acesso. A responsabilidade pelas fontes adicionadas é do utilizador.</p>
<h3>Criador</h3><p class="txt">Desenvolvido por Haymette Tech.</p>`;
const showTerms = accept => dlg(`<h2>Licença e termos de utilização</h2><div class="terms">${TERMS}</div>`, () => true, accept ? 'Aceitar e continuar' : 'Fechar', accept ? 'Cancelar' : '');
function welcome() {
  app.innerHTML = `<div class="splash">${mark(92)}<h1>VISION <em>TV</em></h1><p class="sub">Smart Entertainment</p>
  <p class="desc">Uma plataforma de entretenimento que reúne televisão em direto, desporto e muito mais num só lugar.</p>
  <div class="cards2"><button class="ic2 big" data-a="terms">${ic('doc')}<span class="grow"><b>Licença</b><small>Uso pessoal e não comercial. Todos os direitos reservados.</small></span>${ic('chev', 's')}</button><div class="ic2 v">${ic('info')}<small>Versão</small><b>${esc(N.version())}</b></div></div>
  <div class="by">Desenvolvido por<div class="co">${hmark()}<span><b>Haymette Tech</b><small>Inovação ao seu alcance</small></span></div><span class="hm">Obrigado por escolher o VISION TV ${ic('heart', 's f')}</span></div>
  <div class="steps"><u></u></div><button class="btn block" data-a="wnext">Seguinte ${ic('chev', 's')}</button></div>`;
}
async function wnext() {
  if (!kv.get('seen', false)) { if (!(await showTerms(true))) return; kv.set('seen', true); }
  profilesScreen();
}

/* ---------- Perfis ---------- */
function profilesScreen() {
  const last = kv.get('last', null);
  app.innerHTML = `<div class="who"><div class="hd"><span class="brand">${mark(30)}VISION <em>TV</em></span></div>
  <h1>Quem está a assistir?</h1><p class="lead">${S.manage ? 'Escolha um perfil para editar.' : 'Escolha um perfil ou adicione um novo.'}</p>
  <div class="profs">${profiles.map(p => `<button class="pf ${!S.manage && p.id === last ? 'last' : ''}" data-a="${S.manage ? 'edit' : 'pick'}" data-id="${p.id}">${avatar(p, 'lg2')}<span style="max-width:100%;min-width:0"><b>${esc(p.name)}</b><small>${p.age} anos</small></span>${S.manage ? `<span class="ed">${ic('edit')}</span>` : ''}</button>`).join('')}${profiles.length < 3 ? `<button class="pf add" data-a="new"><span class="plus">${ic('plus')}</span><b>Adicionar perfil</b></button>` : ''}</div>
  <div class="row">${profiles.length ? `<button class="btn sec" data-a="manage">${S.manage ? 'Concluído' : 'Gerir perfis'}</button>` : ''}${active ? '<button class="btn sec" data-a="back">Voltar</button>' : ''}</div>
  <div class="parent">${ic('shield')}<span><b>Perfis com controlo parental</b><small>Conteúdo adaptado à idade.</small></span></div></div>`;
}
function profileForm(p) {
  const cur = p ? ai(p) : profiles.length % 8;
  return dlg(`<h2>${p ? 'Editar perfil' : 'Novo perfil'}</h2><label>Nome</label><input id="pn" maxlength="20" autocomplete="off" value="${esc(p?.name || '')}"><label>Idade (0 a 100)</label><input id="pa" type="number" inputmode="numeric" min="0" max="100" value="${p ? p.age : ''}"><label>Cor do avatar</label><div class="sw">${AVC.map((c, i) => `<button type="button" class="${i === cur ? 'on' : ''}" data-c="${i}" style="--a:${c[0]};--b:${c[1]}" aria-label="Cor ${i + 1}">${ic('check')}</button>`).join('')}</div>${p ? `<button class="btn danger block" data-ret="del" style="margin-top:18px">${ic('trash', 's')} Eliminar perfil</button>` : ''}`, m => {
    const name = m.querySelector('#pn').value.trim().replace(/\s+/g, ' '), raw = m.querySelector('#pa').value, age = Number(raw);
    if (!name) throw new Error('Indique um nome'); if (!/^\d+$/.test(raw) || age < 0 || age > 100) throw new Error('Idade inválida (0 a 100)');
    if (profiles.some(x => x.id !== p?.id && x.name.toLowerCase() === name.toLowerCase())) throw new Error('Já existe um perfil com esse nome');
    return { name, age, av: +m.querySelector('.sw .on').dataset.c };
  }, 'Guardar');
}
async function createProfile() {
  if (profiles.length >= 3) return toast('Máximo de 3 perfis');
  if (!(await ensurePin())) return toast('É necessário definir um PIN parental');
  const v = await profileForm(null); if (!v || v.ret) return;
  profiles.push({ id: 'p' + Date.now(), created: Date.now(), ...v }); kv.set('profiles', profiles); profilesScreen();
}
async function editProfile(id) {
  const p = profiles.find(x => x.id === id); if (!p) return;
  if (!(await askPin('PIN parental para editar o perfil'))) return;
  const v = await profileForm(p); if (!v) return;
  if (v.ret === 'del') {
    if (await ask('Eliminar perfil', `O perfil "${p.name}" e os seus favoritos e histórico serão eliminados.`, 'Eliminar')) {
      profiles = profiles.filter(x => x.id !== id); kv.set('profiles', profiles); kv.set('fav_' + id, []); kv.set('hist_' + id, []);
    }
  } else { Object.assign(p, v); kv.set('profiles', profiles); }
  profilesScreen();
}
async function pickProfile(id) {
  const p = profiles.find(x => x.id === id); if (!p) return;
  if (p.age >= 18 && N.pinExists() && !(await askPin('PIN parental para entrar no perfil adulto'))) return;
  active = p; cache = null; kv.set('last', id); S.tab = 'home'; S.lastTab = null;
  autoUpdate(); shell();
  if (!S.chk) { S.chk = 1; setTimeout(() => checkUpdate(false).then(i => i && promptUpdate(i)), 4000); }
}

/* ---------- Estrutura e vistas ---------- */
const TABS = [['home', 'home', 'Início'], ['tv', 'tv', 'TV'], ['sport', 'ball', 'Desporto'], ['lists', 'layers', 'Listas'], ['lib', 'heart', 'Biblioteca']];
function shell() {
  app.innerHTML = `<header class="top glass"><span class="brand">${mark(28)}VISION <em>TV</em></span><span class="grow"></span><button class="ib" data-a="search" aria-label="Pesquisar">${ic('search')}</button><button class="ib" data-a="settings" aria-label="Definições">${ic('sliders')}</button><button class="ib chip-av" data-a="switch" aria-label="Trocar de perfil">${avatar(active)}</button></header><main id="view"></main><nav class="glass" aria-label="Navegação">${TABS.map(t => `<button data-a="tab" data-t="${t[0]}" aria-label="${t[2]}">${ic(t[1])}<span>${t[2]}</span></button>`).join('')}</nav>`;
  view();
}
function view(keep) {
  S.L = {}; document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.t === S.tab));
  const v = $('#view'); if (!v) return; const st = v.scrollTop, same = S.lastTab === S.tab; S.lastTab = S.tab;
  v.innerHTML = { home: vHome, tv: vTV, sport: vSport, lists: vLists, lib: vLib }[S.tab]();
  v.style.scrollBehavior = 'auto'; v.scrollTop = (keep || same) ? st : 0; v.style.scrollBehavior = '';
}
/* Logótipos: tvg-logo da lista → logótipo da base iptv-org (logos.json) → distintivo colorido com iniciais */
const LM = () => S.LM || (S.LM = kv.get('logomap', {}));
const lbase = c => (c.t || '').split('@')[0];
const isUrl = u => /^https?:\/\//i.test(u || '');
const logoUrl = c => isUrl(c.l) ? c.l : (LM()[lbase(c)] || '');
const initials = n => { const w = String(n || '?').replace(/[^\p{L}\p{N} ]/gu, ' ').trim().split(/\s+/).filter(Boolean); return ((w.length > 1 ? w[0][0] + w[1][0] : (w[0] || '?').slice(0, 2))).toUpperCase(); };
const hueOf = n => [...String(n || '?')].reduce((a, ch) => a + ch.charCodeAt(0), 0) % 360;
const crest = (u, n) => isUrl(u) ? `<img class="crest" loading="lazy" referrerpolicy="no-referrer" src="${esc(u)}" alt="" data-n="${esc(n || '?')}">` : `<span class="crest ph" style="--h:${hueOf(n)}">${esc(initials(n))}</span>`;
const badge = n => { const h = [...String(n || '?')].reduce((a, ch) => a + ch.charCodeAt(0), 0) % 360; return `<span class="lg ph" style="--h:${h}">${esc(initials(n))}</span>`; };
function logo(c) {
  const main = logoUrl(c); if (!main) return badge(c.n);
  const alt = [];
  if (/^http:/i.test(main)) alt.push(main.replace(/^http:/i, 'https:'));
  const m2 = LM()[lbase(c)]; if (m2 && m2 !== main) alt.push(m2);
  return `<img class="lg" loading="lazy" decoding="async" referrerpolicy="no-referrer" src="${esc(main)}" alt="" data-n="${esc(c.n || '?')}" data-alt="${esc(alt.map(encodeURIComponent).join(','))}">`;
}
document.addEventListener('error', e => {
  const t = e.target; if (t.tagName !== 'IMG') return;
  if (t.classList.contains('crest')) { t.outerHTML = crest('', t.dataset.n); return; }
  if (!t.classList.contains('lg')) return;
  const alt = (t.dataset.alt || '').split(',').filter(Boolean);
  if (alt.length) { const nx = decodeURIComponent(alt.shift()); t.dataset.alt = alt.join(','); t.src = nx; return; }
  t.outerHTML = badge(t.dataset.n);
}, true);
async function updateLogos(force) {
  if (S.logoBusy) return;
  if (!force && Object.keys(LM()).length && Date.now() - kv.get('logoat', 0) < 2592e5) return;
  const want = new Set();
  for (const s of sources) if (s.on) for (const c of kv.get('ch_' + s.id, [])) if (c.t) want.add(lbase(c));
  if (!want.size) return;
  S.logoBusy = true;
  try {
    const arr = JSON.parse(await fetchText('https://iptv-org.github.io/api/logos.json')), m = {};
    for (const x of arr) { if (!x || !want.has(x.channel) || !isUrl(x.url)) continue; if (!m[x.channel] || !x.feed) m[x.channel] = x.url; }
    if (Object.keys(m).length) { kv.set('logomap', m); kv.set('logoat', Date.now()); S.LM = m; cache = null; if (active && $('#view') && !document.querySelector('.overlay,.modal')) view(true); }
  } catch (e) { /* sem logos extra: mantém os da lista */ }
  S.logoBusy = false;
}
const empty = (icon, t, d, cta) => `<div class="empty"><span class="ico">${ic(icon)}</span><h3>${t}</h3><p>${d}</p>${cta ? `<button class="btn" data-a="${cta[0]}">${cta[1]}</button>` : ''}</div>`;
const shd = (t, tab) => `<div class="sh"><h2>${t}</h2>${tab ? `<button data-a="tab" data-t="${tab}">Ver todos ${ic('chev')}</button>` : ''}</div>`;
const sec = (t, b, tab) => b ? `<section>${shd(t, tab)}${b}</section>` : '';
const cards = (l, k) => { S.L[k] = l; return `<div class="hs">${l.map(c => `<button class="card" data-a="play" data-k="${k}" data-u="${esc(c.u)}"><span class="thumb">${logo(c)}</span><b>${esc(c.n)}</b><small>${esc(tags(c).join(' · ') || 'Canal')}</small></button>`).join('')}</div>`; };
const rows = (l, k) => { S.L[k] = l; return l.map(c => `<div class="ch"><button class="play" data-a="play" data-k="${k}" data-u="${esc(c.u)}">${logo(c)}<span class="grow"><b>${esc(c.n)}</b><small>${esc([tags(c).join(' · '), c.c].filter(Boolean).join('  ·  '))}</small>${np(c)}</span></button><button class="fv ${isFav(c) ? 'on' : ''}" data-a="fav" data-u="${esc(c.u)}" aria-label="Favorito">${ic('heart')}</button><button class="pl" data-a="play" data-k="${k}" data-u="${esc(c.u)}" aria-label="Reproduzir">${ic('play', 'f')}</button></div>`).join(''); };
const skel = () => `<div class="sk" style="height:190px;border-radius:24px;margin-top:10px"></div><div class="sh"><h2>A carregar canais</h2></div><div class="hs"><div class="sk"></div><div class="sk"></div><div class="sk"></div></div><div class="sk"></div><div class="sk"></div>`;

function hero(c, cont) {
  S.L.b = [c];
  return `<div class="hero"><div class="body"><span class="live"><i></i>AO VIVO</span><h1>${esc(c.n)}</h1><p>${esc(tags(c).join(' · ') || 'Televisão')}${c.c ? ' · ' + esc(c.c) : ''}</p>${np(c)}<button class="btn" data-a="play" data-k="b" data-u="${esc(c.u)}">${ic('play', 'f s')} ${cont ? 'Continuar' : 'Assistir agora'}</button></div><div class="mark">${logo(c)}</div></div>`;
}
function vHome() {
  if (!sources.length) return empty('radio', 'Ainda não há fontes', 'Adicione listas autorizadas em Definições › Fontes de Transmissão. O VISION TV não inclui canais próprios.', ['settings', 'Abrir definições']);
  const all = chans(), h = hist(), f = favs(), epgOn = Object.keys(S.epg).length > 0;
  if (!all.length) return S.busy ? skel() : empty('alert', 'Sem canais disponíveis', 'Nenhum canal permitido para este perfil nas fontes ativas, ou as fontes ainda não foram carregadas.', ['retry', 'Atualizar fontes']);
  const live = [...h, ...f].filter((c, i, a) => a.findIndex(x => x.u === c.u) === i).filter(c => nowNext(c));
  const sp = all.filter(isSport);
  const hc = h[0] ? [h[0], true] : [f[0] || sp[0] || all[0], false];
  const fxs = kv.get('fxhome', true) ? (S.fx || []).filter(f => f.ts > Date.now() - 2 * 36e5) : [], top = fxs.length ? fxHero(fxs[0]) : hero(hc[0], hc[1]);
  return top
    + sec('Destaques', fxs.length > 1 ? fxCards(fxs.slice(1, 9)) : '', 'sport')
    + (live.length ? sec('Programação de Hoje', rows(live.slice(0, 6), 'e'), 'tv') : sec('Canais em direto', rows(all.slice(0, 4), 'e'), 'tv'))
    + sec('Últimos canais', h.length > 1 ? cards(h.slice(1, 16), 'h') : '', 'lib')
    + sec('Favoritos', f.length ? cards(f.slice(0, 15), 'f') : '', 'lib')
    + sec('Desporto', sp.length ? cards(sp.slice(0, 15), 's') : '', 'sport')
    + sec('Canais populares', cards(all.slice(0, 20), 'a'), 'tv');
}
function tvFiltered() {
  let l = chans(); if (S.src) l = l.filter(c => c.s === S.src);
  if (S.cat) l = l.filter(c => tags(c).includes(S.cat)); if (S.country) l = l.filter(c => c.c === S.country);
  if (S.q) { const q = S.q.toLowerCase(); l = l.filter(c => c.n.toLowerCase().includes(q)); }
  return l;
}
function tvList() {
  const l = tvFiltered();
  return l.length ? rows(l.slice(0, S.limit), 'tv') + (l.length > S.limit ? `<button class="btn sec block" data-a="more">Mostrar mais (${l.length - S.limit})</button>` : '')
    : empty('search', 'Sem canais', sources.length ? 'Nenhum canal corresponde aos filtros ou ao perfil ativo.' : 'Adicione fontes em Definições.', sources.length ? null : ['settings', 'Abrir definições']);
}
function vTV() {
  let base = chans(); if (S.src) base = base.filter(c => c.s === S.src);
  const cnt = new Map(); base.forEach(c => tags(c).forEach(t => cnt.set(t, (cnt.get(t) || 0) + 1)));
  const cats = [...cnt].sort((a, b) => b[1] - a[1]).slice(0, 16).map(x => x[0]); if (S.cat && !cats.includes(S.cat)) cats.unshift(S.cat);
  const ctr = [...new Set(base.map(c => c.c).filter(Boolean))].sort();
  return `<div class="pg"><h1>TV em Direto</h1><p>${base.length} canais disponíveis para este perfil</p></div>
  <div class="find"><div class="sf">${ic('search')}<input id="tq" type="search" placeholder="Pesquisar" value="${esc(S.q)}" autocomplete="off"></div>${ctr.length ? `<select id="tk" aria-label="País"><option value="">País</option>${ctr.map(x => `<option ${x === S.country ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>` : ''}</div>
  <div class="chips"><button class="chip ${S.cat || S.country ? '' : 'on'}" data-a="cat" data-v="">Todos</button><button class="chip ${S.country === 'PT' ? 'on' : ''}" data-a="cty" data-v="PT">Portugal</button><button class="chip ${S.country === 'BR' ? 'on' : ''}" data-a="cty" data-v="BR">Brasil</button>${cats.map(x => `<button class="chip ${x === S.cat ? 'on' : ''}" data-a="cat" data-v="${esc(x)}">${esc(x)}</button>`).join('')}</div>
  ${S.src ? `<button class="btn sec sm" data-a="clearsrc" style="margin-bottom:12px">Lista: ${esc(sources.find(s => s.id === S.src)?.name || '')} ${ic('close', 's')}</button>` : ''}<div id="tlw">${tvList()}</div>`;
}
function vSport() {
  const l = chans().filter(isSport);
  return `<div class="pg"><h1>Desporto</h1><p>Canais desportivos das suas listas</p></div>${fxList(15) || `<div class="note">${ic('info')}<span>Calendário de jogos indisponível de momento. Verifique a ligação à Internet.</span></div>`}`
    + (l.length ? rows(l.slice(0, 200), 'sp') : empty('ball', 'Sem canais de desporto', 'Nenhum canal de desporto disponível para este perfil.'));
}
function vLists() {
  const head = `<div class="pg"><h1>Listas</h1><p>Fontes de transmissão neste dispositivo</p></div>`;
  if (!sources.length) return head + empty('layers', 'Nenhuma lista', 'Adicione fontes em Definições › Fontes de Transmissão.', ['settings', 'Abrir definições']);
  return head + `<div style="margin-top:14px">` + sources.map(s => `<div class="src"><div class="hd"><span class="ico">${ic('radio')}</span><span class="grow"><b>${esc(s.name)}</b>${s.on ? '' : '<span class="tag off">Pausada</span>'}<small>${esc(s.url ? hostOf(s.url) : 'Ficheiro local')} · ${s.count} canais</small></span></div><small style="margin-top:12px">Atualizada: ${when(s.updated)}${s.status ? ' · ' + esc(s.status) : ''}</small><div class="act"><button class="btn sm" data-a="viewsrc" data-id="${s.id}">${ic('tv', 's')} Ver canais</button><button class="btn sec sm" data-a="updl" data-id="${s.id}">${ic('refresh', 's')} Atualizar</button></div></div>`).join('') + `</div><button class="btn sec block" data-a="settings">${ic('sliders', 's')} Gerir fontes</button>`;
}
function vLib() {
  const f = favs(), h = hist();
  const head = `<div class="pg"><h1>Biblioteca</h1><p>Os seus canais guardados e recentes</p></div><div class="seg"><button class="${S.lib === 'fav' ? 'on' : ''}" data-a="libtab" data-v="fav">${ic('heart', 's')} Favoritos</button><button class="${S.lib === 'hist' ? 'on' : ''}" data-a="libtab" data-v="hist">${ic('history', 's')} Histórico</button></div>`;
  if (S.lib === 'fav') return head + (f.length ? rows(f, 'lf') : empty('heart', 'Sem favoritos', 'Toque no coração de um canal para o guardar aqui.'));
  return head + (h.length ? rows(h, 'lh') + `<button class="btn sec block" data-a="clrhist">${ic('trash', 's')} Limpar histórico</button>` : empty('history', 'Sem histórico', 'Os canais que assistir aparecem aqui.'));
}

/* ---------- Reprodução ---------- */
function play(k, u) {
  const l = S.L[k] || []; const i = l.findIndex(c => c.u === u); if (i < 0) return;
  const c = l[i];
  if (!okFor(c)) return toast('Conteúdo não permitido para este perfil');
  const from = Math.max(0, i - 60), items = l.slice(from, from + 150).filter(okFor).map(x => { const w = nowNext(x); return { n: x.n, u: x.u, g: tags(x).join(' · '), e: w ? `${hh(w.cur[0])}–${hh(w.cur[1])}  ${w.cur[2]}` : '', r: x.r || '', a: x.a || '' }; });
  const idx = items.findIndex(x => x.u === u);
  if (!N.play(JSON.stringify({ items, i: idx, fav: favKey(), aspect: kv.get('aspect', 0) }))) return toast('Não foi possível iniciar a reprodução');
  const hk = histKey(); kv.set(hk, [u, ...kv.get(hk, []).filter(x => x !== u)].slice(0, 30));
}
function toggleFav(u) {
  const k = favKey(), l = kv.get(k, []), on = !l.includes(u); kv.set(k, on ? [u, ...l] : l.filter(x => x !== u));
  toast(on ? 'Adicionado aos favoritos' : 'Removido dos favoritos');
  if (S.tab === 'lib' || S.tab === 'home') view(true); else document.querySelectorAll(`.fv[data-u="${CSS.escape(u)}"]`).forEach(b => b.classList.toggle('on', on));
}

/* ---------- Fontes ---------- */
async function storeSource(id, name, url, text) {
  const l = parseM3U(text); if (!l.length) throw new Error('Nenhum canal válido encontrado na lista');
  if (!kv.set('ch_' + id, l)) throw new Error('Lista demasiado grande para guardar');
  const s = sources.find(x => x.id === id); Object.assign(s, { name, url, count: l.length, updated: Date.now(), status: 'OK' }); saveSources();
}
async function addSourceUrl() {
  const v = await dlg(`<h2>Adicionar lista por URL</h2><p class="txt">Utilize apenas listas que tem autorização para aceder.</p><label>Nome</label><input id="sn" maxlength="40" autocomplete="off"><label>URL M3U/M3U8</label><input id="su" type="url" placeholder="https://..." autocomplete="off"><label>Origem autorizada</label><select id="sa"><option value="">Selecione…</option><option>Fonte pública / gratuita</option><option>Lista pessoal autorizada</option></select>`, m => {
    const n = m.querySelector('#sn').value.trim(), u = m.querySelector('#su').value.trim();
    if (!n) throw new Error('Indique um nome'); if (!/^https?:\/\/[^\s]+$/i.test(u)) throw new Error('URL inválido');
    if (!m.querySelector('#sa').value) throw new Error('Confirme a origem autorizada'); return { n, u }; }, 'Adicionar');
  if (!v) return; const id = 's' + Date.now(); toast('A descarregar lista…');
  try { sources.push({ id, name: v.n, url: v.u, on: true, count: 0, updated: 0, status: '' }); const t = await fetchText(v.u); await storeSource(id, v.n, v.u, t); toast('Lista adicionada'); }
  catch (e) { sources = sources.filter(s => s.id !== id); saveSources(); toast('Erro: ' + e.message); }
  settings('sources');
}
async function importFile() {
  try {
    const t = await pickFile(); if (!/#EXTM3U|#EXTINF/.test(t.slice(0, 4000))) throw new Error('Ficheiro M3U/M3U8 inválido');
    const v = await dlg(`<h2>Nome da lista</h2><label>Nome</label><input id="sn" maxlength="40" value="Lista importada">`, m => m.querySelector('#sn').value.trim() || undefined, 'Importar'); if (!v) return;
    const id = 's' + Date.now(); sources.push({ id, name: v, url: '', on: true, count: 0, updated: 0, status: '' });
    try { await storeSource(id, v, '', t); toast('Lista importada'); } catch (e) { sources = sources.filter(s => s.id !== id); saveSources(); throw e; }
  } catch (e) { if (e.message !== 'Cancelado') toast('Erro: ' + e.message); }
  settings('sources');
}
async function updateSource(s, quiet) {
  S.busy++;
  try { await updateSource0(s, quiet); } finally { S.busy--; if (!S.busy) { clearTimeout(S.lt); S.lt = setTimeout(() => updateLogos(false), 1500); } if (active && $('#view') && !document.querySelector('.overlay,.modal')) view(true); }
}
async function updateSource0(s, quiet) {
  if (!s.url) return quiet || toast('Listas de ficheiro não se atualizam por URL');
  try { await storeSource(s.id, s.name, s.url, await fetchText(s.url)); quiet || toast('Lista atualizada'); }
  catch (e) { s.status = 'Indisponível: ' + e.message; saveSources(); quiet || toast('Erro: ' + e.message); }
}
async function updateEPG(u, quiet) {
  try { S.epg = parseEPG(await fetchText(u)); kv.set('epg', S.epg); kv.set('epgat', Date.now()); quiet || toast('Guia atualizado'); }
  catch (e) { quiet || toast('Erro EPG: ' + e.message); }
}
function autoUpdate() {
  updateFixtures(false);
  setTimeout(() => updateLogos(false), 5000);
  sources.filter(s => s.on && s.url && Date.now() - s.updated > 864e5).forEach(s => updateSource(s, true));
  const u = kv.get('epgurl', ''); if (u && Date.now() - kv.get('epgat', 0) > 864e5) updateEPG(u, true);
}

/* ---------- Pesquisa ---------- */
function overlay(id, html) { let o = document.getElementById(id); if (!o) { o = document.createElement('div'); o.id = id; o.className = 'overlay'; document.body.append(o); } o.innerHTML = html; return o; }
function search() {
  overlay('so', `<div class="ov-h"><button class="ib" data-a="closeov" aria-label="Voltar">${ic('back')}</button><div class="find" style="margin:0;flex:1"><div class="sf">${ic('search')}<input id="sq" type="search" placeholder="Pesquisar canais ou categorias" autocomplete="off"></div></div></div><div class="ov-b" id="sr">${empty('search', 'Pesquisar', 'Escreva pelo menos 2 letras para encontrar canais.')}</div>`);
  const inp = $('#sq');
  inp.oninput = () => {
    const q = inp.value.trim().toLowerCase();
    S.L.q = q.length < 2 ? [] : chans().filter(c => c.n.toLowerCase().includes(q) || (c.g || '').toLowerCase().includes(q)).slice(0, 100);
    $('#sr').innerHTML = q.length < 2 ? empty('search', 'Pesquisar', 'Escreva pelo menos 2 letras para encontrar canais.') : S.L.q.length ? rows(S.L.q, 'q') : empty('search', 'Sem resultados', 'Tente outro nome ou categoria.');
  };
  inp.focus();
}

/* ---------- Definições ---------- */
async function openSettings(r) {
  if (grp(active.age) !== 'adult') { if (!N.pinExists()) return toast('Peça a um adulto para definir o PIN'); if (!(await askPin('PIN parental para abrir as definições'))) return; }
  settings(r || 'main');
}
const SET_T = { main: 'Definições', profile: 'Perfil e Controlo Parental', sources: 'Fontes de Transmissão', epg: 'Guia de Programação', fx: 'Calendário de Futebol', look: 'Aparência', play: 'Reprodução', data: 'Armazenamento e Dados', about: 'Sobre o VISION TV' };
const ASP = ['Ajustar', 'Cortar', 'Esticar'];
const sgrp = (t, items) => `<h4 class="sg">${t}</h4>` + items.map(x => `<button class="li" data-a="sgo" data-r="${x[0]}"><span class="ico">${ic(x[1])}</span><span class="grow"><b>${x[2]}</b><small>${x[3]}</small></span>${ic('chev', 'go')}</button>`).join('');
const setBody = {
  main: () => {
    const th = document.documentElement.dataset.theme === 'light' ? 'Tema claro' : 'Tema escuro', eu = kv.get('epgurl', '');
    const on = sources.filter(x => x.on), nch = on.reduce((a, x) => a + (x.count || 0), 0);
    const nfx = fxOn().length;
    return `<div class="me">${avatar(active, 'md')}<span class="grow"><b>${esc(active.name)}</b><small>${active.age} anos · ${GL[grp(active.age)]}</small></span><button class="btn sec sm" data-a="manageov">Gerir</button></div>`
      + sgrp('Família', [['profile', 'users', 'Perfil e Controlo Parental', 'Perfis, idades e PIN']])
      + sgrp('Conteúdo', [['sources', 'radio', 'Fontes de Transmissão', `${on.length}/${sources.length} listas ativas · ${nch.toLocaleString('pt-PT')} canais`],
        ['epg', 'cal', 'Guia de Programação', eu ? 'Ativo · ' + esc(hostOf(eu)) : 'Não configurado'],
        ['fx', 'ball', 'Calendário de Futebol', kv.get('fxhome', true) ? `${nfx} ${nfx === 1 ? 'competição' : 'competições'} · visível no Início` : 'Oculto no Início']])
      + sgrp('Aplicação', [['look', 'palette', 'Aparência', th], ['play', 'pbox', 'Reprodução', 'Proporção: ' + ASP[kv.get('aspect', 0)]], ['data', 'folder', 'Armazenamento e Dados', 'Histórico, favoritos e cache']])
      + sgrp('Informação', [['about', 'info', 'Sobre o VISION TV', `Versão ${esc(N.version())} · licença e créditos`]]);
  },
  profile: () => `<div class="me">${avatar(active, 'md')}<span class="grow"><b>${esc(active.name)}</b><small>${active.age} anos · ${GL[grp(active.age)]}</small></span></div>
    <div class="blk"><h3>Perfis</h3><p>Até 3 perfis locais, cada um com a sua faixa etária, favoritos e histórico.</p><div class="act"><button class="btn sm" data-a="manageov">${ic('users', 's')} Gerir perfis</button></div></div>
    <div class="blk"><h3>PIN parental</h3><p>${N.pinExists() ? 'O PIN protege perfis adultos, definições e edição de perfis.' : 'Ainda não existe PIN. Defina um para proteger perfis e definições.'}</p><div class="act"><button class="btn sec sm" data-a="chpin">${ic('lock', 's')} ${N.pinExists() ? 'Alterar PIN' : 'Definir PIN'}</button></div></div>
    <div class="note">${ic('shield')}<span>Perfis infantis só mostram conteúdo classificado como infantil. A validação repete-se antes de cada reprodução.</span></div>`,
  sources: () => {
    const on = sources.filter(x => x.on), nch = on.reduce((a, x) => a + (x.count || 0), 0), last = Math.max(0, ...sources.map(x => x.updated || 0));
    return `<div class="blk"><div class="kv"><span>Listas ativas</span><span>${on.length} de ${sources.length}</span></div><div class="kv"><span>Canais disponíveis</span><span>${nch.toLocaleString('pt-PT')}</span></div><div class="kv"><span>Última atualização</span><span>${when(last)}</span></div>
      <div class="act"><button class="btn sm" data-a="updall">${ic('refresh', 's')} Atualizar todas</button></div></div>`
      + `<h4 class="sg">Adicionar lista</h4><div class="act" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:6px"><button class="btn sec sm" data-a="addurl">${ic('link', 's')} Por URL M3U</button><button class="btn sec sm" data-a="impfile">${ic('folder', 's')} Importar ficheiro</button></div>`
      + `<h4 class="sg">As suas listas</h4>` + sources.map(s => `<div class="src"><div class="hd"><span class="ico">${ic('radio')}</span><span class="grow"><b>${esc(s.name)}</b>${s.on ? '' : '<span class="tag off">Pausada</span>'}${s.core ? '<span class="tag">Fixa</span>' : ''}${/^Indispon/.test(s.status || '') ? '<span class="tag bad">Erro</span>' : ''}<small>${(s.count || 0).toLocaleString('pt-PT')} canais · ${when(s.updated)}</small>${s.status && s.status !== 'OK' ? `<small>${esc(s.status)}</small>` : ''}</span></div><div class="act"><button class="btn sec sm" data-a="upd" data-id="${s.id}">${ic('refresh', 's')} Atualizar</button><button class="btn sec sm" data-a="tog" data-id="${s.id}">${s.on ? 'Pausar' : 'Ativar'}</button>${s.core ? '' : `<button class="btn danger sm" data-a="del" data-id="${s.id}">${ic('trash', 's')} Eliminar</button>`}</div></div>`).join('');
  },
  epg: () => { const u = kv.get('epgurl', ''); return `<div class="blk"><h3>Fonte XMLTV</h3><p>${u ? esc(hostOf(u)) : 'Sem guia configurado.'}</p>${u ? `<small style="margin-top:6px">Atualizado: ${when(kv.get('epgat', 0))}</small>` : ''}<div class="act"><button class="btn sm" data-a="epgset">${ic('link', 's')} Definir URL XMLTV</button>${u ? `<button class="btn sec sm" data-a="epgupd">${ic('refresh', 's')} Atualizar guia</button>` : ''}</div></div><div class="note">${ic('cal')}<span>O guia mostra o programa atual e a barra de progresso nos canais cujo identificador (tvg-id) exista no ficheiro XMLTV.</span></div>`; },
  fx: () => { const at = kv.get('fx', { at: 0 }).at, sw = on => `<i class="sw2 ${on ? 'on' : ''}"></i>`;
    return `<div class="note">${ic('ball')}<span>Próximos jogos e o canal que transmite. Dados da TheSportsDB; o canal pode estar por confirmar em alguns jogos.</span></div>`
      + `<h4 class="sg">Início</h4><button class="li" data-a="fxhome"><span class="grow"><b>Mostrar no Início</b><small>Jogos em destaque no topo</small></span>${sw(kv.get('fxhome', true))}</button>`
      + `<h4 class="sg">Competições</h4>` + FX_LEAGUES.map(l => `<button class="li" data-a="fxl" data-v="${l[0]}"><span class="grow"><b>${l[1]}</b></span>${sw(fxOn().includes(l[0]))}</button>`).join('')
      + `<div class="blk" style="margin-top:6px"><div class="kv"><span>Jogos em cache</span><span>${(S.fx || []).length}</span></div><div class="kv"><span>Atualizado</span><span>${when(at)}</span></div><div class="act"><button class="btn sm" data-a="fxupd">${ic('refresh', 's')} Atualizar calendário</button></div></div>`; },
  data: () => { const f = kv.get(favKey(), []).length, h = kv.get(histKey(), []).length;
    return `<div class="blk"><h3>Perfil ativo · ${esc(active.name)}</h3><div class="kv"><span>Favoritos</span><span>${f}</span></div><div class="kv"><span>Histórico</span><span>${h}</span></div><div class="act"><button class="btn sec sm" data-a="dhist">${ic('history', 's')} Limpar histórico</button><button class="btn danger sm" data-a="dfav">${ic('trash', 's')} Limpar favoritos</button></div></div>`
      + `<div class="blk"><h3>Cache</h3><div class="kv"><span>Logótipos</span><span>${Object.keys(LM()).length}</span></div><div class="kv"><span>Guia (EPG)</span><span>${Object.keys(S.epg).length} canais</span></div><div class="act"><button class="btn sec sm" data-a="rlogos">${ic('refresh', 's')} Atualizar logótipos</button><button class="btn sec sm" data-a="clrepg">Limpar guia</button></div></div>`; },
  look: () => { const th = document.documentElement.dataset.theme; return `<div class="blk"><h3>Tema</h3><div class="seg"><button class="${th !== 'light' ? 'on' : ''}" data-a="theme" data-v="dark">${ic('moon', 's')} Escuro</button><button class="${th === 'light' ? 'on' : ''}" data-a="theme" data-v="light">${ic('grid', 's')} Claro</button></div><p>A paleta petróleo e ciano é aplicada em toda a aplicação.</p></div>`; },
  play: () => { const a = kv.get('aspect', 0); return `<div class="blk"><h3>Proporção predefinida</h3><div class="seg">${ASP.map((x, i) => `<button class="${a === i ? 'on' : ''}" data-a="aspect" data-v="${i}">${x}</button>`).join('')}</div><p>Também pode alterar a proporção durante a reprodução.</p></div>
    <div class="blk"><h3>No leitor</h3><div class="kv"><span>Deslizar à esquerda</span><span>Brilho</span></div><div class="kv"><span>Deslizar à direita</span><span>Volume</span></div><div class="kv"><span>Canal anterior / seguinte</span><span>Botões ou teclas CH</span></div><div class="kv"><span>Imagem sobre imagem</span><span>Botão PiP ou Início</span></div></div>`; },
  about: () => `<div class="about">${mark(72)}<h2>VISION <em>TV</em></h2><small>Smart Entertainment</small></div>
    <div class="blk"><div class="kv"><span>Versão</span><span>${esc(N.version())} (build ${N.versionCode()})</span></div><div class="kv"><span>Desenvolvido por</span><span>Haymette Tech</span></div><p class="mut" id="ust" style="margin-top:10px">${N.updateRepo() ? 'Toque abaixo para procurar uma versão mais recente.' : 'Atualizações não configuradas neste build.'}</p><div class="act"><button class="btn sm" id="ubtn" data-a="chkupd" ${N.updateRepo() ? '' : 'disabled'}>${ic('refresh', 's')} Verificar atualização</button></div></div>
    <div class="blk"><h3>Aviso legal</h3><p>Utilize apenas transmissões autorizadas. Os direitos dos canais pertencem aos respetivos titulares. Os dados ficam apenas neste dispositivo; não há analytics.</p><div class="act"><button class="btn sec sm" data-a="terms">${ic('doc', 's')} Ver licença</button><button class="btn sec sm" data-a="intro">Rever apresentação</button></div></div>`
};
function settings(r) {
  S.sr = r = r || S.sr || 'main';
  overlay('st', `<div class="ov-h"><button class="ib" data-a="sback" aria-label="Voltar">${ic('back')}</button><h1>${SET_T[r]}</h1></div><div class="ov-b">${setBody[r]()}</div>`);
}

/* ---------- Atualizações da aplicação (GitHub Releases, APK assinado) ---------- */
async function checkUpdate(manual) {
  const repo = N.updateRepo(); if (!repo) return manual ? Promise.reject(new Error('não configurado')) : null;
  try {
    const j = JSON.parse(await fetchText(`https://api.github.com/repos/${repo}/releases/latest`));
    const m = /(\d+)$/.exec(j.tag_name || ''), a = (j.assets || []).find(x => /\.apk$/i.test(x.name || ''));
    if (!m || !a) throw new Error('release sem APK');
    return +m[1] > N.versionCode() ? { build: +m[1], name: j.name || j.tag_name, notes: j.body || '', url: a.browser_download_url, size: a.size || 0 } : false;
  } catch (e) { if (manual) throw e; return null; }
}
async function promptUpdate(i) {
  if (document.querySelector('.modal')) return;
  const r = await dlg(`<h2>Nova atualização disponível</h2><p class="txt">${esc(i.name)} (build ${i.build})</p>${i.notes ? `<p class="txt">${esc(i.notes.slice(0, 300))}</p>` : ''}${i.size ? `<p class="txt">${(i.size / 1048576).toFixed(1)} MB</p>` : ''}`, () => true, 'Atualizar agora', 'Mais tarde');
  if (r) runUpdate(i);
}
async function runUpdate(i) {
  settings('about'); const st = $('#ust'), btn = $('#ubtn'); btn.disabled = true; st.textContent = 'A descarregar… 0%';
  window.__prog = p => { st.textContent = `A descarregar… ${p}%`; };
  try {
    await bridge(id => N.downloadUpdate(i.url, id));
    btn.textContent = 'Instalar'; btn.dataset.a = 'instupd'; btn.disabled = false;
    const r = N.installUpdate();
    st.textContent = r === 'perm' ? 'Permita "instalar apps desconhecidas" para o VISION TV, volte e toque em Instalar.' : r === 'ok' ? 'Confirme a instalação no ecrã do sistema.' : 'APK não encontrado.';
  } catch (e) { st.textContent = 'Erro: ' + e.message; btn.disabled = false; }
}

/* ---------- Eventos ---------- */
const closeAll = () => { document.querySelectorAll('.overlay').forEach(o => o.remove()); S.sr = 'main'; };
document.addEventListener('click', async e => {
  const b = e.target.closest('[data-a]'); if (!b) return; const a = b.dataset.a, id = b.dataset.id;
  const src = () => sources.find(s => s.id === id);
  switch (a) {
    case 'tab': S.tab = b.dataset.t; S.limit = 60; view(); break;
    case 'play': play(b.dataset.k, b.dataset.u); break;
    case 'fav': toggleFav(b.dataset.u); break;
    case 'more': S.limit += 60; $('#tlw').innerHTML = tvList(); break;
    case 'cat': S.cat = b.dataset.v; if (!S.cat) S.country = ''; S.limit = 60; view(true); break;
    case 'cty': S.country = S.country === b.dataset.v ? '' : b.dataset.v; S.limit = 60; view(true); break;
    case 'clearsrc': S.src = ''; view(); break;
    case 'viewsrc': S.src = id; S.tab = 'tv'; view(); break;
    case 'libtab': S.lib = b.dataset.v; view(true); break;
    case 'clrhist': kv.set(histKey(), []); view(true); break;
    case 'retry': sources.filter(s => s.on).forEach(s => updateSource(s, true)); view(true); break;
    case 'updl': toast('A atualizar…'); updateSource(src()); break;
    case 'search': search(); break;
    case 'settings': openSettings(); break;
    case 'sgo': settings(b.dataset.r); break;
    case 'sback': if (S.sr !== 'main') settings('main'); else { closeAll(); view(true); } break;
    case 'closeov': closeAll(); view(true); break;
    case 'switch': if (grp(active.age) !== 'adult' && N.pinExists() && !(await askPin('PIN parental para trocar de perfil'))) break; active = null; S.manage = false; profilesScreen(); break;
    case 'back': pickProfile(kv.get('last', null)); break;
    case 'pick': pickProfile(id); break;
    case 'new': createProfile(); break;
    case 'edit': editProfile(id); break;
    case 'manage': S.manage = !S.manage; profilesScreen(); break;
    case 'manageov': closeAll(); active = null; S.manage = true; profilesScreen(); break;
    case 'terms': showTerms(false); break;
    case 'wnext': wnext(); break;
    case 'theme': document.documentElement.dataset.theme = b.dataset.v; kv.set('theme', b.dataset.v); settings('look'); break;
    case 'aspect': kv.set('aspect', +b.dataset.v); settings('play'); break;
    case 'chpin': if (N.pinExists() && !(await askPin('PIN atual'))) break; await newPin(); settings('profile'); break;
    case 'addurl': addSourceUrl(); break;
    case 'impfile': importFile(); break;
    case 'upd': toast('A atualizar…'); await updateSource(src()); settings('sources'); break;
    case 'tog': src().on = !src().on; saveSources(); settings('sources'); break;
    case 'del': if (src().core) break; if (await ask('Eliminar lista', `A lista "${src().name}" será removida deste dispositivo.`, 'Eliminar')) { sources = sources.filter(s => s.id !== id); kv.set('ch_' + id, []); saveSources(); } settings('sources'); break;
    case 'epgset': { const u = await dlg(`<h2>URL XMLTV</h2><label>Endereço do guia</label><input id="eu" type="url" placeholder="https://..." value="${esc(kv.get('epgurl', ''))}">`, m => { const v = m.querySelector('#eu').value.trim(); if (v && !/^https?:\/\/[^\s]+$/i.test(v)) throw new Error('URL inválido'); return v; }, 'Guardar'); if (u === null) break; kv.set('epgurl', u); if (u) { toast('A descarregar guia…'); await updateEPG(u); } else { S.epg = {}; kv.set('epg', {}); } settings('epg'); break; }
    case 'epgupd': toast('A atualizar guia…'); await updateEPG(kv.get('epgurl', '')); settings('epg'); break;
    case 'chkupd': { const st = $('#ust'); st.textContent = 'A verificar…'; try { const i = await checkUpdate(true); if (i === false) st.textContent = 'Já tem a versão mais recente.'; else { st.textContent = 'Nova versão disponível: build ' + i.build; promptUpdate(i); } } catch (x) { st.textContent = 'Não foi possível verificar: ' + x.message; } break; }
    case 'instupd': { const st = $('#ust'), r = N.installUpdate(); st.textContent = r === 'perm' ? 'Permita "instalar apps desconhecidas" para o VISION TV, volte e toque em Instalar.' : r === 'missing' ? 'APK não encontrado. Verifique novamente.' : 'A abrir o instalador…'; break; }
    case 'intro': closeAll(); welcome(); break;
    case 'updall': { toast('A atualizar listas…'); for (const x of sources.filter(y => y.on && y.url)) await updateSource(x, true); toast('Listas atualizadas'); settings('sources'); break; }
    case 'fxhome': kv.set('fxhome', !kv.get('fxhome', true)); settings('fx'); break;
    case 'fxl': { const v = +b.dataset.v, l = fxOn(), n = l.includes(v) ? l.filter(x => x !== v) : [...l, v]; kv.set('fxl', n); kv.set('fx', { at: 0, list: [] }); S.fx = []; settings('fx'); updateFixtures(true).then(() => S.sr === 'fx' && settings('fx')); break; }
    case 'fxupd': toast('A atualizar calendário…'); await updateFixtures(true); settings('fx'); break;
    case 'dhist': if (await ask('Limpar histórico', 'O histórico deste perfil será eliminado.', 'Limpar')) kv.set(histKey(), []); settings('data'); break;
    case 'dfav': if (await ask('Limpar favoritos', 'Os favoritos deste perfil serão eliminados.', 'Limpar')) kv.set(favKey(), []); settings('data'); break;
    case 'rlogos': toast('A atualizar logótipos…'); await updateLogos(true); settings('data'); break;
    case 'clrepg': S.epg = {}; kv.set('epg', {}); kv.set('epgat', 0); toast('Guia limpo'); settings('data'); break;
  }
});
document.addEventListener('input', e => {
  const t = e.target;
  if (t.id === 'tq') { S.q = t.value; S.limit = 60; clearTimeout(vTV.h); vTV.h = setTimeout(() => { const w = $('#tlw'); if (w) w.innerHTML = tvList(); }, 200); }
});
document.addEventListener('change', e => { const t = e.target; if (t.id === 'tk') { S.country = t.value; S.limit = 60; view(true); } });
window.goBack = () => {
  const m = [...document.querySelectorAll('.modal')].pop(); if (m) { m._c(); return true; }
  if (document.getElementById('st') && S.sr !== 'main') { settings('main'); return true; }
  const o = [...document.querySelectorAll('.overlay')].pop(); if (o) { o.remove(); if (!document.querySelector('.overlay')) S.sr = 'main'; if (active) view(true); return true; }
  if (active && S.tab !== 'home' && $('#view')) { S.tab = 'home'; view(); return true; }
  return false;
};
window.onResumeApp = () => { if (active && $('#view') && !document.querySelector('.overlay,.modal')) view(true); };
document.documentElement.dataset.theme = kv.get('theme', 'dark');
S.epg = kv.get('epg', {}); S.fx = kv.get('fx', { list: [] }).list;
{
  const CORE = [
    { id: 'iptvpt', name: 'Portugal (iptv-org)', url: 'https://iptv-org.github.io/iptv/countries/pt.m3u', cc: 'PT', on: true },
    { id: 'iptvbr', name: 'Brasil · canais públicos (iptv-org)', url: 'https://iptv-org.github.io/iptv/countries/br.m3u', cc: 'BR', on: true },
    { id: 'iptvorg', name: 'Canais públicos do mundo (iptv-org)', url: 'https://iptv-org.github.io/iptv/index.m3u', on: !sources.length }
  ];
  CORE.slice().reverse().forEach(d => {
    const s = sources.find(x => x.id === d.id);
    if (!s) sources.unshift({ ...d, core: true, count: 0, updated: 0, status: 'A aguardar primeira atualização' });
    else { s.core = true; if (d.cc) s.cc = d.cc; if (d.id !== 'iptvorg') s.on = true; }
  });
  saveSources();
}
kv.get('seen', false) ? profilesScreen() : welcome();
