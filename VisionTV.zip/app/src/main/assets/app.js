'use strict';
/* VISION TV — Haymette Tech. Interface em JavaScript puro; funcionalidades nativas via window.Native. */
const N = window.Native, $ = s => document.querySelector(s), app = $('#app');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cbs = {}; let cid = 0;
window.__cb = (id, ok, t) => { const c = cbs[id]; delete cbs[id]; c && c(ok, t); };
const bridge = fn => new Promise((res, rej) => { const i = ++cid; cbs[i] = (ok, t) => ok ? res(t) : rej(new Error(t)); fn(i); });
const fetchText = u => bridge(i => N.fetchText(u, i));
const pickFile = () => bridge(i => N.pickFile(i));
let favCache = null;
const KVM = new Map(), HOT = new Set(['nologo', 'fxhome', 'fxmap', 'aspect', 'qcap', 'theme', 'fxl']);
const kv = { get(k, d) { if (HOT.has(k) && KVM.has(k)) { const m = KVM.get(k); return m === undefined ? d : m; }
    try { const v = N.kvGet(k), r = v ? JSON.parse(v) : undefined; if (HOT.has(k)) KVM.set(k, r); return r === undefined ? d : r; } catch (e) { return d; } },
  set(k, v) { if (k.startsWith('fav_')) favCache = null; if (HOT.has(k)) KVM.set(k, v); return N.kvSet(k, JSON.stringify(v)); } };
/* Um único redesenho agrupado (evita dezenas de view() seguidos ao atualizar várias listas) */
let rvT = 0; const redraw = () => { clearTimeout(rvT); rvT = setTimeout(() => { if (active && $('#view') && !document.querySelector('.overlay,.modal')) view(true); }, 600); };
const toast = m => { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.remove('show'), 2800); };

/* ---------- Ícones SVG (sprite em index.html) e marcas ---------- */
const ic = (n, c = '') => `<svg class="i ${c}" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-${n}"/></svg>`;
let gid = 0;
const mark = (s = 64) => { const g = 'lm' + (++gid); return `<svg class="logo" width="${s}" height="${s}" viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="${g}" x1="8" y1="6" x2="56" y2="58" gradientUnits="userSpaceOnUse"><stop stop-color="#6FE0FF"/><stop offset=".55" stop-color="#2B7BFF"/><stop offset="1" stop-color="#6A3CFF"/></linearGradient></defs><path d="M14 10.5c0-3 3.2-4.8 5.8-3.3l32.5 19.4c2.5 1.5 2.5 5.1 0 6.6L19.8 53.6c-2.6 1.5-5.8-.3-5.8-3.3z" fill="url(#${g})"/><path d="M14 10.5c0-3 3.2-4.8 5.8-3.3L40 19.3 14 36z" fill="#fff" opacity=".2"/></svg>`; };
const hmark = () => { const g = 'hm' + (++gid); return `<svg width="38" height="38" viewBox="0 0 38 38" aria-hidden="true"><defs><linearGradient id="${g}" x1="0" y1="0" x2="38" y2="38" gradientUnits="userSpaceOnUse"><stop stop-color="#5FB0FF"/><stop offset="1" stop-color="#1B3FD8"/></linearGradient></defs><rect width="38" height="38" rx="11" fill="url(#${g})"/><path d="M12 10v18M26 10v18M12 19h14" stroke="#fff" stroke-width="3.4" stroke-linecap="round" fill="none"/></svg>`; };
const AVC = [['#2BB5D4', '#1B7FA6'], ['#7C6CF0', '#4A3FC4'], ['#F2994A', '#D9622B'], ['#33C48D', '#1C8F66'], ['#EB5E87', '#BE2F5E']];
const AVN = ['Homem', 'Mulher', 'Criança (4 anos)', 'Adolescente (rapaz)', 'Adolescente (rapariga)'];
const AVS = (() => {
  const SK = '#B97A56', SH = '#8F5A3C', HR = '#1F140F', HL = '#4B3125', LIP = '#8E4440';
  const svg = b => `<svg viewBox="0 0 64 64" aria-hidden="true">${b}</svg>`;
  const eye = (x, y, w, ry, ir, lash) => `<ellipse cx="${x}" cy="${y}" rx="${w}" ry="${ry}" fill="#fff"/><circle cx="${x}" cy="${y + .1}" r="${ir}" fill="#2B1A12"/><circle cx="${x + .7}" cy="${y - .6}" r=".55" fill="#fff"/><path d="M${x - w - .2} ${y - .2}q${w + .2} ${-ry * 2.3} ${2 * w + .4} 0" stroke="${HR}" stroke-width="${lash ? 1.5 : 1.1}" fill="none" stroke-linecap="round"/>${lash ? `<path d="M${x + w + .2} ${y - .4}l1.4 -1" stroke="${HR}" stroke-width="1" stroke-linecap="round"/>` : ''}`;
  const eyes = (y, dx, w, ry, ir, lash) => eye(32 - dx, y, w, ry, ir, lash) + eye(32 + dx, y, w, ry, ir, lash);
  const brows = (y, dx, w, t, c = HR) => `<path d="M${32 - dx - w} ${y + .5}q${w} ${-1.8} ${2 * w} 0" stroke="${c}" stroke-width="${t}" fill="none" stroke-linecap="round"/><path d="M${32 + dx - w} ${y}q${w} ${-1.8} ${2 * w} .5" stroke="${c}" stroke-width="${t}" fill="none" stroke-linecap="round"/>`;
  const nose = y => `<path d="M33.6 ${y - 6}q1.6 4 .2 6.2" stroke="${SH}" stroke-width="1" fill="none" stroke-linecap="round" opacity=".55"/><path d="M29.8 ${y + .4}q2.2 2 4.4 0" stroke="${SH}" stroke-width="1.2" fill="none" stroke-linecap="round"/>`;
  const mouth = (y, w, c) => `<path d="M${32 - w} ${y}q${w} ${w * .55} ${2 * w} 0q${-w} ${w * .95} ${-2 * w} 0z" fill="${c}"/><path d="M${32 - w} ${y}q${w} ${w * .35} ${2 * w} 0" stroke="#00000040" stroke-width=".7" fill="none"/>`;
  const ears = (y, dx, c = SK) => `<ellipse cx="${32 - dx}" cy="${y}" rx="2.4" ry="3.4" fill="${c}"/><ellipse cx="${32 + dx}" cy="${y}" rx="2.4" ry="3.4" fill="${c}"/><ellipse cx="${32 - dx}" cy="${y + .3}" rx="1" ry="1.8" fill="${SH}" opacity=".5"/><ellipse cx="${32 + dx}" cy="${y + .3}" rx="1" ry="1.8" fill="${SH}" opacity=".5"/>`;
  const neck = (w = 6) => `<path d="M${32 - w} 38h${2 * w}v13c0 3-${w / 1.5} 5-${w} 5s-${w} -2-${w} -5z" fill="${SK}"/><path d="M${32 - w} 38h${2 * w}v6c-${w / 2} 3.4-${w * 1.5} 3.4-${2 * w} 0z" fill="#000" opacity=".2"/>`;
  const blush = (y, dx, r = 3) => `<circle cx="${32 - dx}" cy="${y}" r="${r}" fill="#E4806F" opacity=".28"/><circle cx="${32 + dx}" cy="${y}" r="${r}" fill="#E4806F" opacity=".28"/>`;
  const shade = d => `<path d="${d}" fill="${SH}" opacity=".22"/>`;
  return [
    /* homem */ svg(`${neck(6.2)}<path d="M5 64c0-9 8-14 21-15l6 8 6-8c13 1 21 6 21 15z" fill="#2F5FB0"/><path d="M26 49l6 8-9 2zM38 49l-6 8 9 2z" fill="#EAF0FA"/>${ears(29, 12.6)}<path d="M32 12.5c-9.5 0-13.4 6.5-13.4 15 0 5 .9 9 3 12.4 2.4 4 6.2 6.4 10.4 6.4s8-2.400 10.400-6.400c2.100-3.400 3-7.400 3-12.400 0-8.500-3.900-15-13.400-15z" fill="${SK}"/>${shade('M45.4 28c0 8-2.600 14-8 17.400 6-1.200 11-6.400 11-17.400z')}<path d="M22.500 34c.4 6.500 4.300 11.500 9.500 11.500s9.100-5 9.500-11.500c-2.200 4.600-5 6-9.500 6s-7.300-1.400-9.500-6z" fill="${HR}" opacity=".12"/>${blush(34, 8.5, 2.6)}${eyes(28.500, 5.400, 2.700, 1.700, 1.500)}${brows(24.400, 5.400, 2.800, 1.600)}${nose(35)}${mouth(39.800, 3.400, LIP)}<path d="M18.600 27.500c-1.800-11.500 4.200-17.500 13.400-17.500s15.200 6 13.400 17.500c-.8-4-2.200-7.200-4.600-8.800-4.600 2.200-12.400 2.200-17.200 0-2.400 1.600-3.800 4.800-5 8.800z" fill="${HR}"/><path d="M24 16c4-2.500 11-2.500 16 0" stroke="${HL}" stroke-width="1.200" fill="none" stroke-linecap="round" opacity=".8"/>`),
    /* mulher */ svg(`<path d="M14.500 30c0-13.500 7-19.500 17.500-19.500S49.500 16.500 49.500 30v19c0 4-3 6-6.500 6H21c-3.500 0-6.500-2-6.500-6z" fill="#2C1A12"/>${neck(5.400)}<path d="M7 64c0-10 8-14 20-15l5 7 5-7c12 1 20 5 20 15z" fill="#7B4FD0"/><path d="M27 49l5 7 5-7" stroke="#F2C94C" stroke-width="1" fill="none" stroke-linecap="round"/><path d="M15.500 36c-1.500 8-.800 14 2.500 19.500l6-1c-2.600-6-3-12-1.800-19z" fill="#2C1A12"/><path d="M48.500 36c1.500 8 .8 14-2.500 19.500l-6-1c2.600-6 3-12 1.800-19z" fill="#2C1A12"/><path d="M32 12.500c-8.500 0-12 6-12 14.500 0 5 1.200 9 3.400 12.200 2 3.200 5 5.800 8.600 5.800s6.600-2.600 8.600-5.800c2.200-3.200 3.400-7.200 3.400-12.200 0-8.500-3.500-14.500-12-14.500z" fill="${SK}"/>${shade('M43.600 28c0 8-2.400 14-7.600 17.400 5.600-1.200 10-6.400 10-17.400z')}${blush(34.500, 8, 2.700)}${eyes(28.500, 5, 2.700, 1.800, 1.550, 1)}${brows(24.300, 5, 2.700, 1, '#2C1A12')}${nose(35)}${mouth(40, 3.200, '#B5485F')}<path d="M20 28.500c0-10 4.500-16 12-16 8 0 12 6 12 16-1.600-3.600-3.800-7-5.800-9.600-4 4.200-10.500 7-18.200 9.600z" fill="#2C1A12"/><path d="M25 17.500c3-2 8-2.600 12-1" stroke="#5A3A2A" stroke-width="1.200" fill="none" stroke-linecap="round"/><circle cx="20.800" cy="35" r="1.500" fill="#F2C94C"/><circle cx="43.200" cy="35" r="1.500" fill="#F2C94C"/>`),
    /* criança de 4 anos */ svg(`<g fill="${HR}"><circle cx="21.500" cy="21" r="5.500"/><circle cx="28" cy="16.500" r="6"/><circle cx="36" cy="16.500" r="6"/><circle cx="42.500" cy="21" r="5.500"/><circle cx="18.500" cy="28" r="4"/><circle cx="45.500" cy="28" r="4"/></g><path d="M27.500 44h9v9c0 2-2 3.500-4.500 3.500s-4.500-1.500-4.500-3.500z" fill="${SK}"/><path d="M27.500 44h9v4c-2 2.200-7 2.200-9 0z" fill="#000" opacity=".2"/><path d="M12 64c0-8 6-12.500 20-12.500S52 56 52 64z" fill="#F2A03D"/><path d="M26.500 52c1.500 3.500 9.500 3.500 11 0" stroke="#D9822B" stroke-width="1.600" fill="none" stroke-linecap="round"/><circle cx="32" cy="59" r="2.600" fill="#fff" opacity=".85"/><ellipse cx="17.800" cy="33" rx="2.600" ry="3.400" fill="#C98660"/><ellipse cx="46.200" cy="33" rx="2.600" ry="3.400" fill="#C98660"/><path d="M32 15.500c-10.500 0-15 6.500-15 15.500s5 16.500 15 16.500S47 40 47 31s-4.500-15.500-15-15.500z" fill="#C98660"/><path d="M20 27.500c3.500-5 8-7 12-7s8.500 2 12 7c-4-2.200-8-3.200-12-3.200s-8 1-12 3.200z" fill="${HR}"/>${blush(38, 8.500, 3.200)}${eyes(32.500, 5.600, 3.100, 2.600, 2.100)}${brows(27.200, 5.600, 2.800, 1.500)}<path d="M30.600 36.800q1.400 1.200 2.800 0" stroke="${SH}" stroke-width="1.100" fill="none" stroke-linecap="round"/><path d="M27.500 40.500q4.500 4.500 9 0q-4.500 1.400-9 0z" fill="#8E3A3A"/><path d="M29 41q3 1.300 6 0v.9q-3 1.100-6 0z" fill="#fff"/>`),
    /* adolescente rapaz */ svg(`<path d="M10 60c0-9 6-14 13-15l9 7 9-7c7 1 13 6 13 15z" fill="#1C8F66"/>${neck(5.600)}<path d="M7 64c0-10 8-14 18-15l7 8 7-8c10 1 18 5 18 15z" fill="#2DB57A"/><path d="M27 51v8M37 51v8" stroke="#EAFBF3" stroke-width="1.200" stroke-linecap="round"/>${ears(29.500, 11.400)}<path d="M32 13c-8.500 0-12.400 6-12.400 14.500 0 5 1 8.500 3 11.500 2.200 3.800 5.400 6 9.400 6s7.200-2.200 9.400-6c2-3 3-6.500 3-11.500C44.400 19 40.500 13 32 13z" fill="${SK}"/>${shade('M44 28c0 7.500-2.400 13-7.400 16.400 5.600-1.200 10-5.600 10-16.400z')}${eyes(29, 5.200, 2.600, 1.700, 1.500)}${brows(25, 5.200, 2.700, 1.400)}${nose(35.500)}${mouth(40.200, 3, LIP)}<path d="M19.600 28c-2.600-12 3-18.500 12.400-18.500 10 0 15.400 7 12.400 18.500-.8-4.600-2.400-7.400-4.800-8.600-3.200 2.200-6 2.400-8 1.200-3 1.200-6.400.4-8.200-1.200-2.200 1.800-3.600 4.600-3.800 8.600z" fill="${HR}"/><path d="M23 13l2-5 3.500 4 3.500-5 3.500 5 3.500-4 2 5z" fill="${HR}"/><path d="M26 15c3-1.500 9-1.500 12 0" stroke="${HL}" stroke-width="1.100" fill="none" stroke-linecap="round"/>`),
    /* adolescente rapariga */ svg(`<path d="M42.500 15c10-2.500 15 6.500 12.500 17-1 4-2.800 8-5.800 11 .6-6 .2-10-3.700-14z" fill="#2C1A12"/>${neck(5.200)}<path d="M7 64c0-10 8-14 19-15 3 3.200 9 3.200 12 0 11 1 19 5 19 15z" fill="#F0589A"/>${ears(29.500, 10.800)}<path d="M32 13c-8 0-11.800 6-11.800 14.500 0 4.800 1 8.600 3 11.600 2 3.400 5.200 6 8.800 6s6.800-2.600 8.800-6c2-3 3-6.800 3-11.600C43.800 19 40 13 32 13z" fill="${SK}"/>${shade('M43.500 28c0 7.500-2.400 13-7.200 16.400 5.400-1.200 9.600-5.600 9.600-16.400z')}${blush(35, 7.800, 2.600)}${eyes(29, 5, 2.700, 1.850, 1.550, 1)}${brows(24.800, 5, 2.600, 1, '#2C1A12')}${nose(35.500)}${mouth(40.200, 3.100, '#C2415A')}<path d="M19.800 28.500c-1.200-11 4.800-17 12.200-17 7.800 0 12.800 5.500 12.200 17-2.200-4-4.200-8-6.200-10.500-4.400 4.600-10.600 8.200-18.200 10.500z" fill="#2C1A12"/><path d="M26 16.500c3-1.800 7-2.200 11-1" stroke="#5A3A2A" stroke-width="1.100" fill="none" stroke-linecap="round"/><circle cx="43" cy="17" r="3" fill="#F2C94C"/><circle cx="43" cy="17" r="1.200" fill="#F7E08A"/>`)
  ];
})();
const ai = p => typeof p.av === 'number' ? p.av % 5 : ((p.name || 'A').charCodeAt(0) || 0) % 5;
const avatar = (p, c = '') => `<span class="av ${c}" style="--a:${AVC[ai(p)][0]};--b:${AVC[ai(p)][1]}">${AVS[ai(p)]}</span>`;

/* ---------- Classificação por idade ---------- */
const grp = a => a < 12 ? 'kids' : a < 18 ? 'teen' : 'adult';
const GL = { kids: 'Perfil infantil', teen: 'Perfil adolescente', adult: 'Perfil adulto' };
const ALLOW = { kids: ['KIDS'], teen: ['KIDS', 'TEEN', 'GENERAL'], adult: ['KIDS', 'TEEN', 'GENERAL', 'ADULT', 'UNKNOWN'] };
function classify(g) {
  g = (g || '').toLowerCase(); if (!g) return 'UNKNOWN';
  if (/xxx|adult|adulto|18\+|erotic|porn/.test(g)) return 'ADULT';
  if (/kid|child|infant|crian|cartoon|animat|desenh|junior|baby/.test(g)) return 'KIDS';
  if (/sport|desport|music|m[uú]sic|document|educa|scien|ci[eê]ncia|nature|natureza/.test(g)) return 'TEEN';
  if (/news|not[ií]cias|entertain|entreten|general|geral|lifestyle|cultur|weather|comedy|famil|cooking|travel|outdoor|business|legislative|religio|classic|relax|auto|shop/.test(g)) return 'GENERAL';
  return 'UNKNOWN';
}
const okFor = (c, p = active) => !!p && ALLOW[grp(p.age)].includes(c.k);
const isSport = c => /sport|desport|futebol|soccer|football/i.test(c.g || '');
const tags = c => (c.g || '').split(';').map(s => s.trim()).filter(Boolean);
const isFut = c => isSport(c) || /futebol|football|soccer|sport ?tv|espn|premiere|band ?sports|fox sports|dazn|caz[eé]|tnt sports|eleven|combate|\bge\b|\bgol\b/i.test(c.n || '');
const isMus = c => /music|m[uú]sic/i.test(c.g || '') || /m[uú]sic|music|sertanej|pagode|funk|samba|forr[oó]|gospel|kizomba|semba|\bmtv\b|vh1|trace|hits|multishow|som livre/i.test(c.n || '');
const isNov = c => /novela/i.test((c.n || '') + ' ' + (c.g || '')) || (/series|s[eé]ries/i.test(c.g || '') && ['BR', 'PT', 'AO', 'MZ', 'CV'].includes(c.c));
const KINDS = { fut: ['Futebol', isFut], mus: ['Música', isMus], nov: ['Novelas', isNov] };

/* ---------- Estado ---------- */
let profiles = kv.get('profiles', []), active = null, sources = kv.get('sources', []), cache = null;
if (profiles.some(p => typeof p.av !== 'number')) { profiles.forEach(p => { p.av = ai(p); }); kv.set('profiles', profiles); }
const S = { tab: 'home', manage: false, cat: '', kind: '', country: '', q: '', src: '', limit: 60, epg: {}, L: {}, busy: 0, lib: 'fav', sr: 'main' };
const saveSources = () => { kv.set('sources', sources); cache = null; };
const favKey = () => 'fav_' + active.id, histKey = () => 'hist_' + active.id;
const CRANK = { PT: 0, BR: 1 };
let dead = new Set(Object.keys(kv.get('dead', {})));
const HIDE_CH = /sport\s*-?\s*tv\s*\+?\s*-?\s*[1-6]\b/i; /* SportTV+ 1 a 6: canais pagos, não abrem em listas públicas */
function chans() {
  if (cache && cache.p === active.id) return cache.l;
  const sig = sources.filter(x => x.on).map(x => x.id + ':' + (x.updated || 0) + ':' + (x.count || 0)).join(',') + '|' + kv.get('deadv', 0) + '|' + grp(active.age) + '|v3';
  const sv = kv.get('cc_' + active.id, null);
  if (sv && sv.sig === sig && Array.isArray(sv.l)) { cache = { p: active.id, l: sv.l }; return sv.l; }
  const l = [], seen = new Set(), byKey = new Map();
  for (const s of sources) if (s.on) for (const c of kv.get('ch_' + s.id, [])) {
    if (seen.has(c.u)) continue;
    if (HIDE_CH.test(c.n || '') || dead.has(c.u)) continue;
    c.s = s.id; if (!c.c && s.cc) c.c = s.cc;
    if (!okFor(c)) continue;
    seen.add(c.u);
    const key = (c.c || '') + '|' + norm(String(c.n).replace(/[\(\[][^\)\]]*[\)\]]/g, ''));
    const ex = key.length > 4 ? byKey.get(key) : null;
    if (ex) { if (ex.alt.length < 3) ex.alt.push(c.u); if (!ex.l && c.l) ex.l = c.l; continue; }
    c.alt = []; if (key.length > 4) byKey.set(key, c); l.push(c);
  }
  const rk = c => (c.c in CRANK ? CRANK[c.c] : 2) * 2 + (logoUrl(c) ? 0 : 1);
  l.sort((a, b) => rk(a) - rk(b) || a.n.localeCompare(b.n, 'pt'));
  cache = { p: active.id, l }; kv.set('cc_' + active.id, { sig, l }); return l;
}
const byUrl = us => { const m = new Map(); chans().forEach(c => { m.set(c.u, c); (c.alt || []).forEach(a => m.has(a) || m.set(a, c)); }); return [...new Set(us.map(u => m.get(u)).filter(Boolean))]; };
const favs = () => byUrl(kv.get(favKey(), []));
const hist = () => byUrl(kv.get(histKey(), []));
const isFav = c => { if (!favCache || favCache.k !== favKey()) favCache = { k: favKey(), s: new Set(kv.get(favKey(), [])) }; return favCache.s.has(c.u); };
const hostOf = u => { try { return new URL(u).host; } catch (e) { return u || ''; } };
const when = t => t ? new Date(t).toLocaleString('pt-PT', { dateStyle: 'short', timeStyle: 'short' }) : '—';

/* ---------- M3U / XMLTV ---------- */
function parseM3U(t) {
  const out = []; let cur = null;
  for (let l of t.split(/\r?\n/)) {
    l = l.trim(); if (!l) continue;
    if (/^#EXTM3U/i.test(l)) { const m = /(?:url-tvg|x-tvg-url)="([^"]+)"/i.exec(l); if (m) out.tvg = m[1]; continue; }
    if (l.startsWith('#EXTINF')) {
      const a = {}; l.replace(/([\w-]+)="([^"]*)"/g, (m, k, v) => { a[k.toLowerCase()] = v; return m; });
      const n = (l.slice(l.lastIndexOf(',') + 1).trim()) || a['tvg-name'] || '';
      cur = { n, l: a['tvg-logo'] || '', g: a['group-title'] || '', t: a['tvg-id'] || '', c: (a['tvg-country'] || (/\.([a-z]{2})(?:@|$)/i.exec(a['tvg-id'] || '') || [])[1] || '').toUpperCase(), k: classify(a['group-title']) };
    } else if (/^#EXTVLCOPT:/i.test(l) && cur) {
      const m = /^#EXTVLCOPT:([^=]+)=(.*)$/i.exec(l);
      if (m) { const k = m[1].trim().toLowerCase(); if (k === 'http-referrer' || k === 'http-referer') cur.r = m[2].trim(); else if (k === 'http-user-agent') cur.a = m[2].trim(); }
    } else if (l[0] !== '#' && cur) {
      if (/^https?:\/\//i.test(l) && cur.n) { cur.u = l; out.push(cur); }
      cur = null;
    }
  }
  return out;
}
function xmlTime(s) {
  const m = /^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)\s*([+-]\d{4})?/.exec(s || ''); if (!m) return 0;
  let t = Date.UTC(+m[1], m[2] - 1, +m[3], +m[4], +m[5], +m[6]);
  if (m[7]) t -= (m[7][0] === '-' ? -1 : 1) * (+m[7].slice(1, 3) * 60 + +m[7].slice(3, 5)) * 60000;
  return t;
}
function parseEPG(txt, want) {
  const doc = new DOMParser().parseFromString(txt, 'text/xml');
  if (doc.querySelector('parsererror')) throw new Error('XMLTV inválido');
  const now = Date.now(), out = {};
  doc.querySelectorAll('programme').forEach(p => {
    const s = xmlTime(p.getAttribute('start')), e = xmlTime(p.getAttribute('stop'));
    if (!s || !e || e < now - 6 * 3600e3 || s > now + 36 * 3600e3) return;
    const id = p.getAttribute('channel'); if (!id || (want && want.size && !want.has(id))) return;
    (out[id] = out[id] || []).push([s, e, p.querySelector('title')?.textContent || '', p.querySelector('desc')?.textContent || '']);
  });
  return out;
}
const hh = t => new Date(t).toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });
function nowNext(c) {
  const l = c.t && S.epg[c.t]; if (!l) return null; const n = Date.now();
  const cur = l.find(p => p[0] <= n && n < p[1]); return cur ? { cur, next: l.find(p => p[0] >= cur[1]) } : null;
}
const np = c => { const x = nowNext(c); if (!x) return ''; const [s, e, t] = x.cur;
  return `<small class="np">${hh(s)}–${hh(e)} · ${esc(t)}</small><i class="bar"><u style="width:${Math.round((Date.now() - s) / (e - s) * 100)}%"></u></i>`; };

/* ---------- Calendário de futebol (TheSportsDB) ---------- */
const FX_LEAGUES = [[4344, 'Liga Portugal', /liga portugal|primeira liga/i, 'por.1'], [4351, 'Brasileirão', /brasileir/i, 'bra.1'], [4480, 'Champions League', /champions/i, 'uefa.champions'],
  [4481, 'Europa League', /europa league/i, 'uefa.europa'], [4328, 'Premier League', /premier league/i, 'eng.1'], [4335, 'La Liga', /la liga/i, 'esp.1'], [4332, 'Serie A', /serie a/i, 'ita.1'], [4331, 'Bundesliga', /bundesliga/i, 'ger.1'], [4334, 'Ligue 1', /ligue 1/i, 'fra.1']];
const fxOn = () => kv.get('fxl', [4344, 4351, 4480]);
const FX_API = 'https://www.thesportsdb.com/api/v1/json/3/';
const ESPN = 'https://site.api.espn.com/apis/site/v2/sports/soccer/';
const norm = t => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\b(hd|fhd|sd|tv|canal|channel)\b/g, '').replace(/[^a-z0-9]/g, '');
const ymd = t => new Date(t).toISOString().slice(0, 10).replace(/-/g, '');
const fxTs = e => { const t = e.strTimestamp ? Date.parse(/[zZ+]/.test(e.strTimestamp.slice(10)) ? e.strTimestamp : e.strTimestamp + 'Z') : Date.parse(`${e.dateEvent}T${e.strTime || '00:00:00'}Z`); return isNaN(t) ? 0 : t; };
const FX_LIVE = 9e6; /* um jogo conta como "ao vivo" até 2h30 depois do início */
const tnorm = t => norm(String(t || '').toLowerCase().replace(/\b(fc|cf|sc|ac|as|cd|afc|sad|ud|sl|cp|sp|lisbon|lisboa)\b/g, ' '));
const sameTeam = (a, b) => { const x = tnorm(a), y = tnorm(b); return x.length > 2 && y.length > 2 && (x === y || x.includes(y) || y.includes(x)); };
const refreshFx = () => {
  if (document.getElementById('st') && S.sr === 'fx') { settings('fx'); return; }
  if (active && S.tab !== 'tv' && $('#view') && !document.querySelector('.overlay,.modal')) view(true);
};
async function updateFixtures(force) {
  if (S.playing) return;
  const old = kv.get('fx3', { at: 0, list: [] });
  const fresh = old.list.filter(f => f.ts > Date.now() - FX_LIVE);
  if (!force && Date.now() - old.at < 30 * 6e4 && fresh.length) { S.fx = fresh; return; }
  if (S.fxBusy && Date.now() - S.fxTry < 90000) { if (force) S.fxAgain = 1; return; }
  S.fxBusy = 1; S.fxTry = Date.now(); S.fxOk = 0; S.fxErr = '';
  refreshFx();
  try { await fxFetch(old); } catch (e) { S.fx = old.list; }
  S.fxBusy = 0;
  if (S.fxAgain) { S.fxAgain = 0; return updateFixtures(true); }
  refreshFx();
}
async function fxFetch(old) {
  const list = [], now = Date.now();
  const find = (h, a, ts) => list.find(f => Math.abs(f.ts - ts) < 6 * 36e5 && sameTeam(f.h, h) && (!a || !f.a || sameTeam(f.a, a)));
  const on = FX_LEAGUES.filter(l => fxOn().includes(l[0]));
  const espnGet = async l => { /* tenta intervalo; se falhar, tenta dia a dia (resposta menor) e o domínio alternativo */
    const q = d => `${l[3]}/scoreboard?dates=${d}&limit=100`;
    const hosts = [ESPN, 'https://site.web.api.espn.com/apis/site/v2/sports/soccer/'];
    for (const h of hosts) { try { return JSON.parse(await fetchText(h + q(`${ymd(now - 864e5)}-${ymd(now + 8 * 864e5)}`))).events || []; } catch (e) { S.fxErr = S.fxErr || e.message; } }
    const days = await Promise.all([...Array(9).keys()].map(d => fetchText(ESPN + q(ymd(now + (d - 1) * 864e5))).then(t => JSON.parse(t).events || []).catch(() => null)));
    if (days.every(x => x === null)) throw new Error(S.fxErr || 'Sem resposta da ESPN');
    return days.flat().filter(Boolean);
  };
  const jobs = on.map(l => espnGet(l).then(ev => {
    S.fxOk++;
    ev.forEach(e => {
      const ts = Date.parse(e.date), st = e.status?.type?.state; if (!ts || st === 'post' || ts < now - 3 * 36e5 || ts > now + 8 * 864e5) return;
      const cs = e.competitions?.[0]?.competitors || [], h = cs.find(x => x.homeAway === 'home') || cs[0], a = cs.find(x => x.homeAway === 'away') || cs[1]; if (!h || !a) return;
      const hn = h.team?.displayName || h.team?.name || '', an = a.team?.displayName || a.team?.name || ''; if (!hn) return;
      if (find(hn, an, ts)) return;
      list.push({ id: 'e' + e.id, lg: l[1], h: hn, a: an, ts, ch: [], hb: h.team?.logo || h.team?.logos?.[0]?.href || '', ab: a.team?.logo || a.team?.logos?.[0]?.href || '' });
    });
  }).catch(e => { S.fxErr = S.fxErr || e.message; }));
  on.forEach(l => jobs.push(fetchText(`${FX_API}eventsnextleague.php?id=${l[0]}`).then(t => {
    const evs = JSON.parse(t).events || []; S.fxOk++;
    evs.forEach(e => {
      const ts = fxTs(e); if (!ts || ts < now - 3 * 36e5 || ts > now + 8 * 864e5) return;
      if (find(e.strHomeTeam, e.strAwayTeam, ts)) return;
      list.push({ id: 'n' + e.idEvent, lg: l[1], h: e.strHomeTeam, a: e.strAwayTeam || '', ts, ch: [], hb: e.strHomeTeamBadge || '', ab: e.strAwayTeamBadge || '' });
    });
  }).catch(e => { S.fxErr = S.fxErr || e.message; })));
  for (let d = 0; d < 7; d++) {
    const day = new Date(now + d * 864e5).toISOString().slice(0, 10);
    jobs.push(fetchText(`${FX_API}eventstv.php?d=${day}&s=Soccer`).then(t => {
      const tv = JSON.parse(t).tvevents || [];
      tv.forEach(e => {
        const lg = on.find(l => l[2].test(e.strLeague || '')); if (!lg) return;
        const ts = fxTs(e); if (!ts || ts < now - 3 * 36e5 || ts > now + 8 * 864e5) return;
        const h = e.strHomeTeam || (e.strEvent || '').split(' vs ')[0], a = e.strAwayTeam || (e.strEvent || '').split(' vs ')[1] || '';
        let f = find(h, a, ts);
        if (!f) { f = { id: 't' + (e.idEvent || ts + h), lg: lg[1], h, a, ts, ch: [], hb: e.strHomeTeamBadge || '', ab: e.strAwayTeamBadge || '' }; list.push(f); }
        if (e.strChannel && !f.ch.includes(e.strChannel)) f.ch.push(e.strChannel);
        if (!f.hb && e.strHomeTeamBadge) f.hb = e.strHomeTeamBadge; if (!f.ab && e.strAwayTeamBadge) f.ab = e.strAwayTeamBadge;
      });
    }).catch(() => {}));
  }
  try { await Promise.race([Promise.all(jobs), new Promise(r => setTimeout(r, 25000))]); } catch (e) {}
  try {
  const TB = kv.get('tbadge', {});
  const need = [...new Set(list.flatMap(f => [[f.h, f.hb], [f.a, f.ab]].filter(x => x[0] && !x[1]).map(x => x[0])))].filter(n => !(norm(n) in TB)).slice(0, 30);
  await Promise.all(need.map(n => fetchText(`${FX_API}searchteams.php?t=${encodeURIComponent(n)}`).then(t => { const tm = (JSON.parse(t).teams || []).find(x => x.strSport === 'Soccer'); TB[norm(n)] = tm?.strBadge || tm?.strTeamBadge || ''; }).catch(() => {})));
  kv.set('tbadge', TB);
  list.forEach(f => { if (!f.hb) f.hb = TB[norm(f.h)] || ''; if (!f.ab) f.ab = TB[norm(f.a)] || ''; });
  list.sort((a, b) => a.ts - b.ts); const out = list.slice(0, 60);
  if (out.length) { kv.set('fx3', { at: Date.now(), list: out }); S.fx = out; } else S.fx = old.list;
  } catch (e) { S.fx = old.list; }
}
const FX_DEF = { 'Liga Portugal': /sport ?tv|dazn|benfica ?tv|sporting ?tv|porto canal|rtp/i, 'Brasileirão': /premiere|globo|sportv|caz[eé]|band ?sports|record/i, 'Champions League': /sport ?tv|tnt|caz[eé]|sbt|rtp|dazn/i, 'Europa League': /sport ?tv|tnt|caz[eé]|dazn/i };
const rawN = t => String(t || '').toLowerCase().replace(/[^a-z0-9]/g, '');
let FXI = null;
function fxIndex(all) {
  if (FXI && FXI.all === all) return FXI;
  const exact = new Map(), nm = [];
  for (const x of all) { const r = rawN(x.n); if (!exact.has(r)) exact.set(r, x); const r2 = r.replace(/(hd|fhd|sd|4k)$/, ''); if (!exact.has(r2)) exact.set(r2, x); nm.push([norm(x.n), x]); }
  return FXI = { all, exact, nm, memo: new Map() };
}
function fxChan(f) {
  const all = chans(), I = fxIndex(all), mk = f.ch.join('|') + '#' + f.lg + '#' + JSON.stringify(kv.get('fxmap', {})[f.lg] || '');
  if (I.memo.has(mk)) return I.memo.get(mk);
  const done = c => (I.memo.set(mk, c), c);
  for (const n of f.ch) { const k = rawN(n); if (k.length < 3) continue; const c = I.exact.get(k); if (c) return done(c); }
  for (const n of f.ch) { const k = norm(n); if (k.length < 3) continue; const c = I.nm.find(([y]) => y === k || y.includes(k) || k.includes(y) && y.length > 3); if (c) return done(c[1]); }
  const m = kv.get('fxmap', {})[f.lg]; if (m) { const c = all.find(x => x.u === m || (x.alt || []).includes(m)); if (c) return done(c); }
  return done(null); /* só mostra «Ver» quando o canal existe nas listas (ou foi escolhido por si); nada de adivinhar */
}
const fxWhen = ts => { const d = new Date(ts), t = new Date(), same = d.toDateString() === t.toDateString(), tm = new Date(t.getTime() + 864e5).toDateString() === d.toDateString();
  return (same ? 'Hoje' : tm ? 'Amanhã' : d.toLocaleDateString('pt-PT', { weekday: 'short', day: 'numeric', month: 'short' })) + ' · ' + hh(ts); };
const fxDay = ts => { const d = new Date(ts), t = new Date(), k = x => x.toDateString();
  return k(d) === k(t) ? 'Hoje' : k(d) === k(new Date(t.getTime() + 864e5)) ? 'Amanhã' : d.toLocaleDateString('pt-PT', { weekday: 'long', day: 'numeric', month: 'long' }); };

async function fxPick(lg) {
  const all = chans(), sp = all.filter(isFut);
  const draw = q => { const k = norm(q || ''); const l = (k ? all.filter(c => norm(c.n).includes(k)) : (sp.length ? sp : all)).slice(0, 80);
    const box = document.querySelector('.modal #fl'); if (box) box.innerHTML = l.length ? l.map(c => `<button class="btn sec sm" style="display:block;width:100%;text-align:left;margin:4px 0" data-ret="${esc(c.u)}">${esc(c.n)}</button>`).join('') : '<p class="txt">Nenhum canal encontrado.</p>'; };
  const p = dlg(`<h2>Canal para ${esc(lg)}</h2><p class="txt">Escolha o canal onde costuma ver esta competição. Fica guardado para os próximos jogos.</p><input id="fq" type="search" placeholder="Pesquisar canal"><div id="fl" style="max-height:44vh;overflow:auto;margin-top:8px"></div>`, () => null, 'Fechar', '');
  draw(''); const q = document.querySelector('.modal #fq'); if (q) q.oninput = () => draw(q.value);
  const r = await p;
  if (r && r.ret) { const m = kv.get('fxmap', {}); m[lg] = r.ret; kv.set('fxmap', m); toast('Canal guardado para ' + lg); view(true); }
}
function fxList(n, group) {
  const l = (S.fx || []).filter(f => f.ts > Date.now() - FX_LIVE).slice(0, n); if (!l.length) return '';
  S.L.fx = [];
  let lastDay = '';
  return `<div class="fxl">${l.map(f => { const c = fxChan(f), live = f.ts <= Date.now(); if (c) S.L.fx.push(c);
    const dh = group && !live && fxDay(f.ts) !== lastDay ? (lastDay = fxDay(f.ts), `<h4 class="fxday">${esc(lastDay)}</h4>`) : '';
    return dh + `<div class="fx"><span class="crests s">${crest(f.hb, f.h)}${crest(f.ab, f.a)}</span><div class="fxm"><small>${esc(f.lg)}</small><b>${esc(f.h)}${f.a ? ' vs ' + esc(f.a) : ''}</b><span class="fxt">${live ? '<i class="liv">AO VIVO</i>' : esc(fxWhen(f.ts))}</span>`
    + `<small class="fxc">${ic('tv', 's')} ${f.ch.length ? esc(f.ch.join(' · ')) : 'Canal por confirmar'}</small></div>`
    + (c ? `<button class="btn sm" data-a="play" data-k="fx" data-u="${esc(c.u)}">${ic('play', 'f s')} Ver</button>` : `<button class="btn sec sm" data-a="fxpick" data-lg="${esc(f.lg)}">Escolher canal</button>`) + `</div>`; }).join('')}</div>`;
}
function fxHero(f) {
  const c = fxChan(f), live = f.ts <= Date.now(); S.L.fxh = c ? [c] : [];
  return `<div class="hero fxh"><span class="stad" aria-hidden="true"></span><div class="body"><span class="live"><i></i>${live ? 'EM DIRETO' : 'PRÓXIMO JOGO'}</span><h1>${esc(f.h)}${f.a ? '<br>vs ' + esc(f.a) : ''}</h1><p>${esc(f.lg)}</p>`
    + `<p class="when">${ic('clock', 's')} ${live ? 'A decorrer' : esc(fxWhen(f.ts))}</p><span class="tvc">${ic('tv', 's')} ${f.ch.length ? esc(f.ch.join(' · ')) : 'Canal por confirmar'}</span>`
    + (c ? `<button class="btn" data-a="play" data-k="fxh" data-u="${esc(c.u)}">Assistir agora ${ic('chev', 's')}</button>` : `<button class="btn" data-a="fxpick" data-lg="${esc(f.lg)}">Escolher canal</button>`)
    + `</div><div class="crests">${crest(f.hb, f.h)}${crest(f.ab, f.a)}</div></div>`;
}
function fxCards(l) {
  S.L.fxd = []; return `<div class="hs">${l.map(f => { const c = fxChan(f); if (c) S.L.fxd.push(c);
    const inner = `<span class="pfg"><span class="crests">${crest(f.hb, f.h)}${crest(f.ab, f.a)}</span></span><span class="pt"><b>${esc(f.h)}${f.a ? ' vs ' + esc(f.a) : ''}</b><small>${esc(f.lg)}</small><small class="tm">${esc(fxWhen(f.ts))}</small></span>`;
    return c ? `<button class="card pic fxd" data-a="play" data-k="fxd" data-u="${esc(c.u)}">${inner}</button>` : `<div class="card pic fxd">${inner}</div>`; }).join('')}</div>`;
}
const fxSection = () => { if (!kv.get('fxhome', true)) return ''; const h = fxList(5); return h ? `<section>${shd('Futebol · próximos jogos', 'sport')}${h}</section>` : ''; };

/* ---------- Diálogos (folhas inferiores) ---------- */
function dlg(html, collect, okL = 'OK', noL = 'Cancelar') {
  return new Promise(res => {
    const m = document.createElement('div'); m.className = 'modal';
    m.innerHTML = `<div class="box" role="dialog" aria-modal="true"><div class="grab"></div>${html}<p class="err" id="derr"></p><div class="acts">${noL ? `<button class="btn sec" data-x>${noL}</button>` : ''}<button class="btn" data-ok>${okL}</button></div></div>`;
    document.body.append(m);
    const done = v => { m.remove(); res(v); }; m._c = () => done(null);
    m.onclick = e => {
      if (e.target === m) return done(null);
      const r = e.target.closest('[data-ret]'); if (r) return done({ ret: r.dataset.ret });
      const sw = e.target.closest('.sw button'); if (sw) { m.querySelectorAll('.sw button').forEach(b => b.classList.toggle('on', b === sw)); return; }
      if (e.target.closest('[data-x]')) return done(null);
      if (e.target.closest('[data-ok]')) { try { const v = collect(m); if (v !== undefined) done(v); } catch (x) { m.querySelector('#derr').textContent = x.message; } }
    };
    const f = m.querySelector('input,select'); if (f) f.focus();
  });
}
const ask = (title, msg, okL = 'Confirmar') => dlg(`<h2>${esc(title)}</h2><p class="txt">${esc(msg)}</p>`, () => true, okL);
const hasPin = id => { try { return !!N.ppExists(id); } catch (e) { return false; } };
const askPin = (msg, id) => dlg(`<h2>${esc(msg)}</h2><label>PIN do perfil</label><input id="pin" type="password" inputmode="numeric" maxlength="8" placeholder="4 a 8 dígitos" autocomplete="off">`, m => {
  if (N.locked()) throw new Error('Demasiadas tentativas. Aguarde 1 minuto.');
  const v = m.querySelector('#pin').value; if (!/^\d{4,8}$/.test(v)) throw new Error('O PIN tem 4 a 8 dígitos');
  if (!N.ppCheck(id, v)) throw new Error('PIN incorreto'); return true; });
const newPin = id => dlg(`<h2>Definir PIN do perfil</h2><p class="txt">4 a 8 dígitos. Só quem souber o PIN consegue entrar neste perfil.</p><label>Novo PIN</label><input id="p1" type="password" inputmode="numeric" maxlength="8"><label>Repetir PIN</label><input id="p2" type="password" inputmode="numeric" maxlength="8">`, m => {
  const a = m.querySelector('#p1').value, b = m.querySelector('#p2').value;
  if (!/^\d{4,8}$/.test(a)) throw new Error('O PIN tem 4 a 8 dígitos'); if (a !== b) throw new Error('Os PIN não coincidem');
  return N.ppSet(id, a); }, 'Guardar');

/* ---------- Boas-vindas ---------- */
const TERMS = `<h3>O que é</h3><p class="txt">O VISION TV é uma plataforma para organizar e assistir a canais de televisão através de fontes que você configura, com perfis familiares e controlo parental.</p>
<h3>Canais e fontes</h3><p class="txt">A aplicação organiza canais e fontes de transmissão. Não hospeda canais: vem pré-configurada com a lista pública mundial do projeto iptv-org (canais disponibilizados publicamente, sem conteúdo adulto) e permite adicionar as suas próprias listas em Definições › Fontes de Transmissão. A disponibilidade de cada canal depende do respetivo emissor.</p>
<h3>Perfis e idade</h3><p class="txt">Até 3 perfis locais. Cada perfil tem uma faixa etária (0–11, 12–17, 18+) que filtra os conteúdos. A classificação depende dos metadados da fonte (ex.: group-title); conteúdo sem classificação fiável é ocultado em perfis de menores. Nenhum filtro substitui a supervisão de um adulto.</p>
<h3>Privacidade</h3><p class="txt">Funciona sem conta e sem registo. Perfis, idades, favoritos e listas ficam apenas neste dispositivo. Não existem analytics nem rastreamento. É necessária Internet para reproduzir e atualizar fontes.</p>
<h3>Licença e avisos legais</h3><p class="txt">Utilize apenas transmissões e listas cujo acesso e utilização sejam autorizados. Os direitos de cada canal e transmissão pertencem aos respetivos titulares; o VISION TV não detém direitos sobre conteúdos de terceiros nem contorna DRM, autenticação ou restrições de acesso. A responsabilidade pelas fontes adicionadas é do utilizador.</p>
<h3>Criador</h3><p class="txt">Desenvolvido por Haymette Tech.</p>`;
const showTerms = accept => dlg(`<h2>Licença e termos de utilização</h2><div class="terms">${TERMS}</div>`, () => true, accept ? 'Aceitar e continuar' : 'Fechar', accept ? 'Cancelar' : '');
function welcome() {
  app.innerHTML = `<div class="wel"><div class="wbg" aria-hidden="true"></div>
  <div class="wc"><div class="wm">VISION <em>TV</em></div><h1 class="wt">Bem-vindo ao nosso<br>VISION TV</h1>
  <p class="wd">Com esta aplicação pode ver televisão em direto, acompanhar o desporto e guardar os seus canais favoritos, tudo num só lugar.</p>
  <button class="btn wbtn" data-a="wnext">Começar ${ic('chev', 's')}</button>
  <button class="wlink" data-a="terms">Licença e termos de utilização</button></div>
  <small class="wv">Versão ${esc(N.version())}</small></div>`;
}
async function wnext() {
  if (!kv.get('seen', false)) { if (!(await showTerms(true))) return; kv.set('seen', true); }
  profilesScreen();
}

/* ---------- Perfis ---------- */
function profilesScreen() {
  const last = kv.get('last', null);
  app.innerHTML = `<div class="who"><div class="hd"><span class="brand">VISION <em>TV</em></span></div>
  <h1>Quem está a assistir?</h1><p class="lead">${S.manage ? 'Escolha um perfil para editar.' : 'Escolha um perfil ou adicione um novo.'}</p>
  <div class="profs">${profiles.map(p => `<button class="pf ${!S.manage && p.id === last ? 'last' : ''}" data-a="${S.manage ? 'edit' : 'pick'}" data-id="${p.id}">${avatar(p, 'lg2')}<span style="max-width:100%;min-width:0"><b>${esc(p.name)}</b></span>${hasPin(p.id) ? `<span class="lk">${ic('lock', 's')}</span>` : ''}${S.manage ? `<span class="ed">${ic('edit')}</span>` : ''}</button>`).join('')}${profiles.length < 3 ? `<button class="pf add" data-a="new"><span class="plus">${ic('plus')}</span><b>Adicionar perfil</b></button>` : ''}</div>
  <div class="row">${profiles.length ? `<button class="btn sec" data-a="manage">${S.manage ? 'Concluído' : 'Gerir perfis'}</button>` : ''}${active ? '<button class="btn sec" data-a="back">Voltar</button>' : ''}</div>
</div>`;
}
function profileForm(p) {
  const cur = p ? ai(p) : profiles.length % 5, hp = p && hasPin(p.id);
  return dlg(`<h2>${p ? 'Editar perfil' : 'Novo perfil'}</h2><label>Nome</label><input id="pn" maxlength="20" autocomplete="off" value="${esc(p?.name || '')}"><label>Idade (0 a 100)</label><input id="pa" type="number" inputmode="numeric" min="0" max="100" value="${p ? p.age : ''}"><small style="margin-top:6px">Usada apenas para adaptar o conteúdo. Não é mostrada.</small><label>Avatar</label><div class="sw">${AVC.map((c, i) => `<button type="button" class="${i === cur ? 'on' : ''}" data-c="${i}" style="--a:${c[0]};--b:${c[1]}" aria-label="${AVN[i]}">${AVS[i]}</button>`).join('')}</div>
    <label>PIN do perfil (opcional)</label><input id="pp" type="password" inputmode="numeric" maxlength="8" autocomplete="off" placeholder="${hp ? 'Novo PIN (vazio mantém o atual)' : 'Deixe vazio para não usar PIN'}">
    ${hp ? '<label>Estado do PIN</label><select id="pm"><option value="keep">Manter PIN</option><option value="remove">Remover PIN</option></select>' : ''}
    ${p ? `<button class="btn danger block" data-ret="del" style="margin-top:18px">${ic('trash', 's')} Eliminar perfil</button>` : ''}`, m => {
    const name = m.querySelector('#pn').value.trim().replace(/\s+/g, ' '), raw = m.querySelector('#pa').value, age = Number(raw), pin = m.querySelector('#pp').value.trim();
    if (!name) throw new Error('Indique um nome'); if (!/^\d+$/.test(raw) || age < 0 || age > 100) throw new Error('Idade inválida (0 a 100)');
    if (pin && !/^\d{4,8}$/.test(pin)) throw new Error('O PIN tem 4 a 8 dígitos');
    if (profiles.some(x => x.id !== p?.id && x.name.toLowerCase() === name.toLowerCase())) throw new Error('Já existe um perfil com esse nome');
    return { name, age, av: +m.querySelector('.sw .on').dataset.c, pin, rm: m.querySelector('#pm')?.value === 'remove' };
  }, 'Guardar');
}
async function createProfile() {
  if (profiles.length >= 3) return toast('Máximo de 3 perfis');
  const v = await profileForm(null); if (!v || v.ret) return;
  const { pin, rm, ...p } = v, id = 'p' + Date.now();
  profiles.push({ id, created: Date.now(), ...p }); kv.set('profiles', profiles);
  if (pin) N.ppSet(id, pin);
  profilesScreen();
}
async function editProfile(id) {
  const p = profiles.find(x => x.id === id); if (!p) return;
  if (hasPin(id) && !(await askPin('PIN do perfil para o editar', id))) return;
  const v = await profileForm(p); if (!v) return;
  if (v.ret === 'del') {
    if (await ask('Eliminar perfil', `O perfil "${p.name}" e os seus favoritos e histórico serão eliminados.`, 'Eliminar')) {
      profiles = profiles.filter(x => x.id !== id); kv.set('profiles', profiles); kv.set('fav_' + id, []); kv.set('hist_' + id, []); N.ppClear(id);
    }
  } else {
    const { pin, rm, ...rest } = v; Object.assign(p, rest); kv.set('profiles', profiles);
    if (rm) N.ppClear(id); else if (pin) N.ppSet(id, pin);
  }
  profilesScreen();
}
async function pickProfile(id) {
  const p = profiles.find(x => x.id === id); if (!p) return;
  if (hasPin(id) && !(await askPin('PIN do perfil', id))) return;
  active = p; cache = null; kv.set('last', id); S.tab = 'home'; S.lastTab = null;
  autoUpdate(); shell();
  if (!S.chk) { S.chk = 1; setTimeout(() => checkUpdate(false).then(i => i && promptUpdate(i)), 4000); }
}

/* ---------- Estrutura e vistas ---------- */
const TABS = [['home', 'home', 'Início'], ['tv', 'tv', 'TV'], ['sport', 'ball', 'Desporto'], ['lib', 'heart', 'Biblioteca']];
function shell() {
  app.innerHTML = `<header class="top"><span class="brand">VISION <em>TV</em></span><span class="grow"></span><button class="ib" data-a="search" aria-label="Pesquisar">${ic('search')}</button><button class="ib" data-a="settings" aria-label="Definições">${ic('sliders')}</button></header><main id="view"></main><nav class="glass" aria-label="Navegação">${TABS.map(t => `<button data-a="tab" data-t="${t[0]}" aria-label="${t[2]}">${ic(t[1])}<span>${t[2]}</span></button>`).join('')}</nav>`;
  view();
}
function view(keep) {
  S.L = {}; document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.t === S.tab));
  const v = $('#view'); if (!v) return; const st = v.scrollTop, same = S.lastTab === S.tab; S.lastTab = S.tab; v.classList.toggle('na', !!keep || same);
  v.innerHTML = { home: vHome, tv: vTV, sport: vSport, lib: vLib }[S.tab]();
  v.style.scrollBehavior = 'auto'; v.scrollTop = (keep || same) ? st : 0; v.style.scrollBehavior = '';
}
/* Logótipos: tvg-logo da lista → logótipo da base iptv-org (logos.json) → distintivo colorido com iniciais */
const LM = () => S.LM || (S.LM = kv.get('logomap', {}));
const lbase = c => (c.t || '').split('@')[0];
const isUrl = u => /^https?:\/\//i.test(u || '');
const logoUrl = c => isUrl(c.l) ? c.l : (LM()[lbase(c)] || '');
const initials = n => { const w = String(n || '?').replace(/[^\p{L}\p{N} ]/gu, ' ').trim().split(/\s+/).filter(Boolean); return ((w.length > 1 ? w[0][0] + w[1][0] : (w[0] || '?').slice(0, 2))).toUpperCase(); };
const hueOf = n => [...String(n || '?')].reduce((a, ch) => a + ch.charCodeAt(0), 0) % 360;
const crest = (u, n) => isUrl(u) ? `<img class="crest" loading="lazy" referrerpolicy="no-referrer" src="${esc(u)}" alt="" data-n="${esc(n || '?')}">` : `<span class="crest ph" style="--h:${hueOf(n)}">${esc(initials(n))}</span>`;
const badge = n => { const h = [...String(n || '?')].reduce((a, ch) => a + ch.charCodeAt(0), 0) % 360; return `<span class="lg ph" style="--h:${h}">${esc(initials(n))}</span>`; };
function logo(c) {
  const main = kv.get('nologo', false) ? '' : logoUrl(c); if (!main) return badge(c.n);
  const alt = [];
  if (/^http:/i.test(main)) alt.push(main.replace(/^http:/i, 'https:'));
  const m2 = LM()[lbase(c)]; if (m2 && m2 !== main) alt.push(m2);
  return `<img class="lg" loading="lazy" decoding="async" referrerpolicy="no-referrer" src="${esc(main)}" alt="" data-n="${esc(c.n || '?')}" data-alt="${esc(alt.map(encodeURIComponent).join(','))}">`;
}
document.addEventListener('error', e => {
  const t = e.target; if (t.tagName !== 'IMG') return;
  if (t.classList.contains('cbg')) {
    const al = (t.dataset.alt || '').split(',').filter(Boolean);
    if (al.length) { const nx = decodeURIComponent(al.shift()); t.dataset.alt = al.join(','); t.src = nx; } else t.remove();
    return;
  }
  if (t.classList.contains('crest')) { t.outerHTML = crest('', t.dataset.n); return; }
  if (!t.classList.contains('lg')) return;
  const alt = (t.dataset.alt || '').split(',').filter(Boolean);
  if (alt.length) { const nx = decodeURIComponent(alt.shift()); t.dataset.alt = alt.join(','); t.src = nx; return; }
  t.outerHTML = badge(t.dataset.n);
}, true);
async function updateLogos(force) {
  if (S.logoBusy) return;
  if (!force && Object.keys(LM()).length && Date.now() - kv.get('logoat', 0) < 2592e5) return;
  const want = new Set();
  for (const s of sources) if (s.on) for (const c of kv.get('ch_' + s.id, [])) if (c.t) want.add(lbase(c));
  if (!want.size) return;
  S.logoBusy = true;
  try {
    const arr = JSON.parse(await fetchText('https://iptv-org.github.io/api/logos.json')), m = {};
    for (const x of arr) { if (!x || !want.has(x.channel) || !isUrl(x.url)) continue; if (!m[x.channel] || !x.feed) m[x.channel] = x.url; }
    if (Object.keys(m).length) { kv.set('logomap', m); kv.set('logoat', Date.now()); S.LM = m; cache = null; redraw(); }
  } catch (e) { /* sem logos extra: mantém os da lista */ }
  S.logoBusy = false;
}
const empty = (icon, t, d, cta) => `<div class="empty"><span class="ico">${ic(icon)}</span><h3>${t}</h3><p>${d}</p>${cta ? `<button class="btn" data-a="${cta[0]}">${cta[1]}</button>` : ''}</div>`;
const shd = (t, tab) => `<div class="sh"><h2>${t}</h2>${tab ? `<button data-a="tab" data-t="${tab}">Ver todos ${ic('chev')}</button>` : ''}</div>`;
const sec = (t, b, tab) => b ? `<section>${shd(t, tab)}${b}</section>` : '';
const logoChain = c => {
  if (kv.get('nologo', false)) return [];
  const m = logoUrl(c), m2 = LM()[lbase(c)], l = [], add = u => { if (isUrl(u) && !l.includes(u)) l.push(u); };
  if (/^http:/i.test(m)) add(m.replace(/^http:/i, 'https:'));
  add(m); if (/^http:/i.test(m2 || '')) add(m2.replace(/^http:/i, 'https:')); add(m2);
  return l;
};
const bgImg = (c, x = '') => { const l = logoChain(c); if (!l.length) return '';
  return `<img class="cbg ${x}" ${x.includes('hb') ? '' : 'loading="lazy" '}decoding="async" referrerpolicy="no-referrer" src="${esc(l[0])}" alt="" data-alt="${esc(l.slice(1).map(encodeURIComponent).join(','))}">`; };
const cards = (l, k) => { if (!l.length) return ''; S.L[k] = l; return `<div class="hs">${l.map(c => `<button class="card pic" data-a="play" data-k="${k}" data-u="${esc(c.u)}" style="--h:${hueOf(c.n)}">${bgImg(c)}<span class="pfg">${logo(c)}</span><span class="pt"><b>${esc(c.n)}</b><small>${esc(tags(c).join(' · ') || 'Canal')}</small></span></button>`).join('')}</div>`; };
const chNum = (i, w) => String(i + 1).padStart(w, '0');
const rows = (l, k, tot) => { S.L[k] = l; const w = Math.max(2, String(tot || l.length).length); return l.map((c, i) => `<div class="ch"><button class="play" data-a="play" data-k="${k}" data-u="${esc(c.u)}"><span class="num">${chNum(i, w)}</span>${logo(c)}<span class="grow"><b>${esc(c.n)}</b><small>${esc([tags(c).join(' · '), c.c].filter(Boolean).join('  ·  '))}</small>${np(c)}</span></button><button class="fv ${isFav(c) ? 'on' : ''}" data-a="fav" data-u="${esc(c.u)}" aria-label="Favorito">${ic('heart')}</button><button class="pl" data-a="play" data-k="${k}" data-u="${esc(c.u)}" aria-label="Reproduzir">${ic('play', 'f')}</button></div>`).join(''); };
const prRows = (l, k) => { S.L[k] = l; return l.map(c => { const x = nowNext(c);
  const sub = x ? `${c.n} · ${hh(x.cur[0])} – ${hh(x.cur[1])}` : [tags(c).join(' · '), c.c].filter(Boolean).join(' · ');
  return `<div class="ch pr" style="--h:${hueOf(c.n)}"><button class="play" data-a="play" data-k="${k}" data-u="${esc(c.u)}"><span class="ptile">${bgImg(c)}${logo(c)}</span><span class="grow"><span class="live s"><i></i>AO VIVO</span><b>${esc(x ? x.cur[2] : c.n)}</b><small>${esc(sub)}</small></span></button><button class="fv ${isFav(c) ? 'on' : ''}" data-a="fav" data-u="${esc(c.u)}" aria-label="Favorito">${ic('heart')}</button><button class="pl" data-a="play" data-k="${k}" data-u="${esc(c.u)}" aria-label="Reproduzir">${ic('play', 'f')}</button></div>`; }).join(''); };
const skel = () => `<div class="sk" style="height:190px;border-radius:24px;margin-top:10px"></div><div class="sh"><h2>A carregar canais</h2></div><div class="hs"><div class="sk"></div><div class="sk"></div><div class="sk"></div></div><div class="sk"></div><div class="sk"></div>`;

function hero(c, cont) {
  S.L.b = [c];
  return `<div class="hero" style="--h:${hueOf(c.n)}">${bgImg(c, 'hb')}<div class="body"><span class="live"><i></i>AO VIVO</span><h1>${esc(c.n)}</h1><p>${esc(tags(c).join(' · ') || 'Televisão')}${c.c ? ' · ' + esc(c.c) : ''}</p>${np(c)}<button class="btn" data-a="play" data-k="b" data-u="${esc(c.u)}">${ic('play', 'f s')} ${cont ? 'Continuar' : 'Assistir agora'}</button></div><div class="mark">${logo(c)}</div></div>`;
}
function vHome() {
  if (!sources.length) return empty('radio', 'Ainda não há fontes', 'Adicione listas autorizadas em Definições › Fontes de Transmissão. O VISION TV não inclui canais próprios.', ['settings', 'Abrir definições']);
  const all = chans(), h = hist(), f = favs(), epgOn = Object.keys(S.epg).length > 0;
  if (!all.length) return S.busy ? skel() : empty('alert', 'Sem canais disponíveis', 'Nenhum canal permitido para este perfil nas fontes ativas, ou as fontes ainda não foram carregadas.', ['retry', 'Atualizar fontes']);
  const live = [...new Map([...h, ...f].map(c => [c.u, c])).values()].filter(c => nowNext(c));
  const sp = all.filter(isSport);
  const feat = []; { const seen = new Set(), skip = (h[0] || {}).u; for (const c of [...f, ...sp, ...all]) { if (feat.length >= 8) break; if (seen.has(c.u)) continue; seen.add(c.u); if (c.u !== skip && logoUrl(c)) feat.push(c); } }
  const hc = h[0] ? [h[0], true] : [f[0] || sp[0] || all[0], false];
  const fxs = kv.get('fxhome', true) ? (S.fx || []).filter(f => f.ts > Date.now() - FX_LIVE) : [], top = fxs.length ? fxHero(fxs[0]) : hero(hc[0], hc[1]);
  return top
    + sec('Destaques', fxs.length > 1 ? fxCards(fxs.slice(1, 9)) : cards(feat, 'ft'), fxs.length > 1 ? 'sport' : 'tv')
    + (live.length ? sec('Programação de Hoje', prRows(live.slice(0, 6), 'e'), 'tv') : sec('Canais em direto', prRows(all.slice(0, 4), 'e'), 'tv'))
    + sec('Últimos canais', h.length > 1 ? cards(h.slice(1, 11), 'h') : '', 'lib')
    + sec('Favoritos', f.length ? cards(f.slice(0, 10), 'f') : '', 'lib')
    + sec('Desporto', sp.length ? cards(sp.slice(0, 10), 's') : '', 'sport')
    + sec('Canais populares', cards(all.slice(0, 12), 'a'), 'tv');
}
function tvFiltered() {
  let l = chans(); if (S.src) l = l.filter(c => c.s === S.src);
  if (S.cat) l = l.filter(c => tags(c).includes(S.cat)); if (S.country) l = l.filter(c => c.c === S.country);
  if (S.kind && KINDS[S.kind]) { const R = { BR: 0, AO: 1, MZ: 1, PT: 1, CV: 1 }; l = l.filter(KINDS[S.kind][1]).map((c, i) => [c, i]).sort((a, b) => (R[a[0].c] ?? 2) - (R[b[0].c] ?? 2) || a[1] - b[1]).map(x => x[0]); }
  if (S.q) { const q = S.q.toLowerCase(); l = l.filter(c => c.n.toLowerCase().includes(q)); }
  return l;
}
function tvList() {
  const l = tvFiltered();
  return l.length ? rows(l.slice(0, S.limit), 'tv', l.length) + (l.length > S.limit ? `<button class="btn sec block" data-a="more">Mostrar mais (${l.length - S.limit})</button>` : '')
    : empty('search', 'Sem canais', sources.length ? 'Nenhum canal corresponde aos filtros ou ao perfil ativo.' : 'Adicione fontes em Definições.', sources.length ? null : ['settings', 'Abrir definições']);
}
function vTV() {
  let base = chans(); if (S.src) base = base.filter(c => c.s === S.src);
  const cnt = new Map(); base.forEach(c => tags(c).forEach(t => cnt.set(t, (cnt.get(t) || 0) + 1)));
  const cats = [...cnt].sort((a, b) => b[1] - a[1]).slice(0, 16).map(x => x[0]); if (S.cat && !cats.includes(S.cat)) cats.unshift(S.cat);
  const ctr = [...new Set(base.map(c => c.c).filter(Boolean))].sort();
  return `<div class="pg"><h1>TV em Direto</h1><p>${base.length} canais disponíveis para este perfil</p></div>
  <div class="find"><div class="sf">${ic('search')}<input id="tq" type="search" placeholder="Pesquisar" value="${esc(S.q)}" autocomplete="off"></div>${ctr.length ? `<select id="tk" aria-label="País"><option value="">País</option>${ctr.map(x => `<option ${x === S.country ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>` : ''}</div>
  <div class="chips"><button class="chip ${S.cat || S.country || S.kind ? '' : 'on'}" data-a="cat" data-v="">Todos</button><button class="chip ${S.country === 'PT' ? 'on' : ''}" data-a="cty" data-v="PT">Portugal</button><button class="chip ${S.country === 'BR' ? 'on' : ''}" data-a="cty" data-v="BR">Brasil</button><button class="chip ${S.country === 'AO' ? 'on' : ''}" data-a="cty" data-v="AO">Angola</button><button class="chip ${S.country === 'MZ' ? 'on' : ''}" data-a="cty" data-v="MZ">Moçambique</button>${Object.entries(KINDS).map(([k, v]) => `<button class="chip ${S.kind === k ? 'on' : ''}" data-a="kind" data-v="${k}">${v[0]}</button>`).join('')}${cats.map(x => `<button class="chip ${x === S.cat ? 'on' : ''}" data-a="cat" data-v="${esc(x)}">${esc(x)}</button>`).join('')}</div>
  ${S.src ? `<button class="btn sec sm" data-a="clearsrc" style="margin-bottom:12px">Lista: ${esc(sources.find(s => s.id === S.src)?.name || '')} ${ic('close', 's')}</button>` : ''}<div id="tlw">${tvList()}</div>`;
}
function fxNote() {
  if (S.fxBusy) return `<div class="note">${ic('clock')}<span>A carregar o calendário de jogos…</span></div>`;
  const msg = S.fxOk === 0 ? 'Calendário de jogos indisponível de momento. Verifique a ligação à Internet e toque em «Tentar novamente».' + (S.fxErr ? ` (${esc(S.fxErr)})` : '') : 'Sem jogos agendados nos próximos dias para as competições escolhidas.';
  return `<div class="note">${ic('info')}<span>${msg}</span></div><button class="btn sec sm" data-a="fxupd" style="margin:-4px 0 12px">${ic('refresh', 's')} Tentar novamente</button>`;
}
function vSport() {
  const l = chans().filter(isSport);
  return `<div class="pg"><h1>Desporto</h1><p>Canais desportivos das suas listas</p></div>${fxList(15, true) || fxNote()}`
    + (l.length ? rows(l.slice(0, 200), 'sp') : empty('ball', 'Sem canais de desporto', 'Nenhum canal de desporto disponível para este perfil.'));
}
function vLib() {
  const f = favs(), h = hist();
  const head = `<div class="pg"><h1>Biblioteca</h1><p>Os seus canais guardados e recentes</p></div><div class="seg"><button class="${S.lib === 'fav' ? 'on' : ''}" data-a="libtab" data-v="fav">${ic('heart', 's')} Favoritos</button><button class="${S.lib === 'hist' ? 'on' : ''}" data-a="libtab" data-v="hist">${ic('history', 's')} Histórico</button></div>`;
  if (S.lib === 'fav') return head + (f.length ? rows(f, 'lf') : empty('heart', 'Sem favoritos', 'Toque no coração de um canal para o guardar aqui.'));
  return head + (h.length ? rows(h, 'lh') + `<button class="btn sec block" data-a="clrhist">${ic('trash', 's')} Limpar histórico</button>` : empty('history', 'Sem histórico', 'Os canais que assistir aparecem aqui.'));
}

/* ---------- Reprodução ---------- */
function play(k, u) {
  const l = S.L[k] || []; const i = l.findIndex(c => c.u === u); if (i < 0) return;
  const c = l[i];
  if (!okFor(c)) return toast('Conteúdo não permitido para este perfil');
  const from = Math.max(0, i - 60), items = l.slice(from, from + 150).filter(x => okFor(x)).map(x => { const w = nowNext(x); return { n: x.n, u: x.u, g: tags(x).join(' · '), e: w ? `${hh(w.cur[0])}–${hh(w.cur[1])}  ${w.cur[2]}` : '', r: x.r || '', a: x.a || '', z: (x.alt || []).join('|') }; });
  const idx = items.findIndex(x => x.u === u);
  if (idx < 0) return toast('Canal indisponível');
  S.playing = 1; /* enquanto o leitor está aberto, a interface não faz trabalho de fundo (rede/CPU ficam para o vídeo) */
  if (!N.play(JSON.stringify({ items, i: idx, fav: favKey(), aspect: kv.get('aspect', 0) }))) { S.playing = 0; return toast('Não foi possível iniciar a reprodução'); }
  const hk = histKey(); kv.set(hk, [u, ...kv.get(hk, []).filter(x => x !== u)].slice(0, 30));
}
function toggleFav(u) {
  const k = favKey(), l = kv.get(k, []), on = !l.includes(u); kv.set(k, on ? [u, ...l] : l.filter(x => x !== u));
  toast(on ? 'Adicionado aos favoritos' : 'Removido dos favoritos');
  if (S.tab === 'lib' || S.tab === 'home') view(true); else document.querySelectorAll(`.fv[data-u="${CSS.escape(u)}"]`).forEach(b => b.classList.toggle('on', on));
}

/* ---------- Fontes ---------- */
async function storeSource(id, name, url, text) {
  const l = parseM3U(text); if (!l.length) throw new Error('Nenhum canal válido encontrado na lista');
  if (!kv.set('ch_' + id, l)) throw new Error('Lista demasiado grande para guardar');
  const s = sources.find(x => x.id === id); Object.assign(s, { name, url, count: l.length, updated: Date.now(), status: 'OK', tvg: l.tvg || '' }); saveSources();
}
async function addSourceUrl() {
  const v = await dlg(`<h2>Adicionar lista por URL</h2><p class="txt">Utilize apenas listas que tem autorização para aceder.</p><label>Nome</label><input id="sn" maxlength="40" autocomplete="off"><label>URL M3U/M3U8</label><input id="su" type="url" placeholder="https://..." autocomplete="off"><label>Origem autorizada</label><select id="sa"><option value="">Selecione…</option><option>Fonte pública / gratuita</option><option>Lista pessoal autorizada</option></select>`, m => {
    const n = m.querySelector('#sn').value.trim(), u = m.querySelector('#su').value.trim();
    if (!n) throw new Error('Indique um nome'); if (!/^https?:\/\/[^\s]+$/i.test(u)) throw new Error('URL inválido');
    if (!m.querySelector('#sa').value) throw new Error('Confirme a origem autorizada'); return { n, u }; }, 'Adicionar');
  if (!v) return; const id = 's' + Date.now(); toast('A descarregar lista…');
  try { sources.push({ id, name: v.n, url: v.u, on: true, count: 0, updated: 0, status: '' }); const t = await fetchText(v.u); await storeSource(id, v.n, v.u, t); toast('Lista adicionada'); }
  catch (e) { sources = sources.filter(s => s.id !== id); saveSources(); toast('Erro: ' + e.message); }
  settings('sources');
}
async function importFile() {
  try {
    const t = await pickFile(); if (!/#EXTM3U|#EXTINF/.test(t.slice(0, 4000))) throw new Error('Ficheiro M3U/M3U8 inválido');
    const v = await dlg(`<h2>Nome da lista</h2><label>Nome</label><input id="sn" maxlength="40" value="Lista importada">`, m => m.querySelector('#sn').value.trim() || undefined, 'Importar'); if (!v) return;
    const id = 's' + Date.now(); sources.push({ id, name: v, url: '', on: true, count: 0, updated: 0, status: '' });
    try { await storeSource(id, v, '', t); toast('Lista importada'); } catch (e) { sources = sources.filter(s => s.id !== id); saveSources(); throw e; }
  } catch (e) { if (e.message !== 'Cancelado') toast('Erro: ' + e.message); }
  settings('sources');
}

/* Verificação de canais: esconde os que não abrem (neste dispositivo/ligação). Repete a cada 3 dias. */
let scanning = false;
const probeCh = c => bridge(i => N.probe(c.u, c.r || '', c.a || '', i)).then(t => t === '1', () => false);
async function pool(items, n, fn) { let i = 0; await Promise.all([...Array(Math.min(n, items.length))].map(async () => { while (i < items.length) { while (S.playing) await new Promise(r => setTimeout(r, 1500)); const it = items[i++]; await fn(it); } })); }
async function scanChannels(manual) {
  if (scanning) return 0; scanning = true;
  try {
    const now = Date.now(), chk = kv.get('chk', {}), dm = kv.get('dead', {}), seenU = new Set(), cand = [];
    for (const s of sources) if (s.on) for (const c of kv.get('ch_' + s.id, [])) {
      if (!c.u || seenU.has(c.u) || HIDE_CH.test(c.n || '') || !okFor(c) || !/m3u8/i.test(c.u)) continue;
      seenU.add(c.u);
      if (chk[c.u] && now - chk[c.u] < (manual ? 36e5 : 3 * 864e5)) continue;
      cand.push(c);
    }
    cand.sort((a, b) => (a.c in CRANK ? CRANK[a.c] : 2) - (b.c in CRANK ? CRANK[b.c] : 2));
    const batch = cand.slice(0, 400); if (!batch.length) return 0;
    if (manual) toast(`A verificar ${batch.length} canais…`);
    const bad = [];
    await pool(batch, 4, async c => { if (!(await probeCh(c))) bad.push(c); });
    if (batch.length >= 20 && bad.length > batch.length * 0.95) { if (manual) toast('Sem ligação à internet — nada foi alterado'); return 0; }
    const bad2 = []; /* segunda tentativa: só fica escondido se falhar duas vezes */
    await pool(bad, 4, async c => { if (!(await probeCh(c))) bad2.push(c); });
    const badSet = new Set(bad2.map(c => c.u));
    batch.forEach(c => { chk[c.u] = now; if (badSet.has(c.u)) dm[c.u] = now; else delete dm[c.u]; });
    kv.set('chk', chk); kv.set('dead', dm); kv.set('deadv', Date.now()); dead = new Set(Object.keys(dm)); cache = null; if (bad2.length) redraw();
    return bad2.length;
  } catch (e) { return 0; } finally { scanning = false; }
}

/* O leitor regista cada canal que abriu ou falhou; um canal que falha em 2 sessões seguidas fica escondido. */
function processPlayLog() {
  const raw = kv.get('playlog', []); if (!Array.isArray(raw) || !raw.length) return;
  kv.set('playlog', []);
  const fl = kv.get('fails', {}), dm = kv.get('dead', {}); let ch = false;
  raw.forEach(x => { const ok = x[0] === '1', u = String(x).slice(2);
    if (ok) { delete fl[u]; if (dm[u]) { delete dm[u]; ch = true; } }
    else { fl[u] = (fl[u] || 0) + 1; if (fl[u] >= 2 && !dm[u]) { dm[u] = Date.now(); ch = true; } } });
  kv.set('fails', fl);
  if (ch) { kv.set('dead', dm); kv.set('deadv', Date.now()); dead = new Set(Object.keys(dm)); cache = null; redraw(); }
}
document.addEventListener('visibilitychange', () => { if (!document.hidden) processPlayLog(); });
window.addEventListener('focus', processPlayLog);
async function updateSource(s, quiet) {
  S.busy++;
  try { await updateSource0(s, quiet); } finally { S.busy--; if (!S.busy) { clearTimeout(S.lt); S.lt = setTimeout(() => updateLogos(false), 1500); } redraw(); }
}
async function updateSource0(s, quiet) {
  if (!s.url) return quiet || toast('Listas de ficheiro não se atualizam por URL');
  try { await storeSource(s.id, s.name, s.url, await fetchText(s.url)); quiet || toast('Lista atualizada'); }
  catch (e) { s.status = 'Indisponível: ' + e.message; saveSources(); quiet || toast('Erro: ' + e.message); }
}
const epgUrl = () => { const m = kv.get('epgurl', ''); if (m) return m; const x = sources.find(y => y.on && y.tvg); return x ? x.tvg.split(/[,\s]+/)[0] : ''; };
async function updateEPG(u, quiet) {
  try { S.epg = parseEPG(await fetchText(u), active ? new Set(chans().map(c => c.t).filter(Boolean)) : null); kv.set('epg', S.epg); kv.set('epgat', Date.now()); quiet || toast('Guia atualizado'); }
  catch (e) { quiet || toast('Erro EPG: ' + e.message); }
}
function autoUpdate() {
  updateFixtures(false);
  setTimeout(() => updateLogos(false), 5000);
  sources.filter(s => s.on && s.url && Date.now() - s.updated > 864e5).forEach(s => updateSource(s, true));
  const u = epgUrl(); if (u && Date.now() - kv.get('epgat', 0) > 864e5) updateEPG(u, true);
}

/* ---------- Pesquisa ---------- */
function overlay(id, html) { let o = document.getElementById(id); if (!o) { o = document.createElement('div'); o.id = id; o.className = 'overlay'; document.body.append(o); } o.innerHTML = html; return o; }
function search() {
  overlay('so', `<div class="ov-h"><button class="ib" data-a="closeov" aria-label="Voltar">${ic('back')}</button><div class="find" style="margin:0;flex:1"><div class="sf">${ic('search')}<input id="sq" type="search" placeholder="Pesquisar canais ou categorias" autocomplete="off"></div></div></div><div class="ov-b" id="sr">${empty('search', 'Pesquisar', 'Escreva pelo menos 2 letras para encontrar canais.')}</div>`);
  const inp = $('#sq');
  inp.oninput = () => {
    const q = inp.value.trim().toLowerCase();
    S.L.q = q.length < 2 ? [] : chans().filter(c => c.n.toLowerCase().includes(q) || (c.g || '').toLowerCase().includes(q)).slice(0, 100);
    $('#sr').innerHTML = q.length < 2 ? empty('search', 'Pesquisar', 'Escreva pelo menos 2 letras para encontrar canais.') : S.L.q.length ? rows(S.L.q, 'q') : empty('search', 'Sem resultados', 'Tente outro nome ou categoria.');
  };
  inp.focus();
}

/* ---------- Definições ---------- */
function openSettings(r) { settings(r || 'main'); }
const SET_T = { main: 'Definições', profile: 'Perfil e Controlo Parental', sources: 'Fontes de Transmissão', epg: 'Guia de Programação', fx: 'Calendário de Futebol', look: 'Aparência', play: 'Reprodução', data: 'Armazenamento e Dados', about: 'Sobre o VISION TV' };
const ASP = ['Ajustar', 'Cortar', 'Esticar'];
const sgrp = (t, items) => `<h4 class="sg">${t}</h4>` + items.map(x => `<button class="li" data-a="sgo" data-r="${x[0]}"><span class="ico">${ic(x[1])}</span><span class="grow"><b>${x[2]}</b><small>${x[3]}</small></span>${ic('chev', 'go')}</button>`).join('');
const setBody = {
  main: () => {
    const th = document.documentElement.dataset.theme === 'light' ? 'Tema claro' : 'Tema escuro', eu = epgUrl();
    const on = sources.filter(x => x.on), nch = on.reduce((a, x) => a + (x.count || 0), 0);
    const nfx = fxOn().length;
    return `<div class="me">${avatar(active, 'md')}<span class="grow"><b>${esc(active.name)}</b><small>${GL[grp(active.age)]}</small></span><button class="btn sec sm" data-a="manageov">Gerir</button></div>`
      + sgrp('Família', [['switch', 'user', 'Mudar de perfil', 'Escolher outro perfil'], ['profile', 'users', 'Perfil e Controlo Parental', 'Perfis e PIN opcional']])
      + sgrp('Conteúdo', [['sources', 'radio', 'Fontes de Transmissão', `${on.length}/${sources.length} listas ativas · ${nch.toLocaleString('pt-PT')} canais`],
        ['epg', 'cal', 'Guia de Programação', eu ? 'Ativo · ' + esc(hostOf(eu)) : 'Não configurado'],
        ['fx', 'ball', 'Calendário de Futebol', kv.get('fxhome', true) ? `${nfx} ${nfx === 1 ? 'competição' : 'competições'} · visível no Início` : 'Oculto no Início']])
      + sgrp('Aplicação', [['look', 'palette', 'Aparência', th], ['play', 'pbox', 'Reprodução', 'Proporção: ' + ASP[kv.get('aspect', 0)]], ['data', 'folder', 'Armazenamento e Dados', 'Histórico, favoritos e cache']])
      + sgrp('Informação', [['about', 'info', 'Sobre o VISION TV', `Versão ${esc(N.version())} · licença e créditos`]]);
  },
  profile: () => `<div class="me">${avatar(active, 'md')}<span class="grow"><b>${esc(active.name)}</b><small>${GL[grp(active.age)]}</small></span></div>
    <div class="blk"><h3>Perfis</h3><p>Até 3 perfis locais, cada um com a sua faixa etária, favoritos e histórico.</p><div class="act"><button class="btn sm" data-a="manageov">${ic('users', 's')} Gerir perfis</button></div></div>
    <div class="blk"><h3>PIN do perfil</h3><p>${hasPin(active.id) ? 'Este perfil está protegido por PIN.' : 'Opcional. Sem PIN, qualquer pessoa pode entrar neste perfil.'}</p><div class="act"><button class="btn sec sm" data-a="chpin">${ic('lock', 's')} ${hasPin(active.id) ? 'Alterar PIN' : 'Definir PIN'}</button>${hasPin(active.id) ? `<button class="btn danger sm" data-a="rmpin">Remover PIN</button>` : ''}</div></div>
    <div class="note">${ic('shield')}<span>O conteúdo é adaptado à idade de cada perfil. A validação repete-se antes de cada reprodução. O PIN é opcional e definido por si, perfil a perfil.</span></div>`,
  sources: () => {
    const on = sources.filter(x => x.on), nch = on.reduce((a, x) => a + (x.count || 0), 0), last = Math.max(0, ...sources.map(x => x.updated || 0));
    return `<div class="blk"><div class="kv"><span>Listas ativas</span><span>${on.length} de ${sources.length}</span></div><div class="kv"><span>Canais disponíveis</span><span>${nch.toLocaleString('pt-PT')}</span></div><div class="kv"><span>Última atualização</span><span>${when(last)}</span></div>
      <div class="act"><button class="btn sm" data-a="updall">${ic('refresh', 's')} Atualizar todas</button> <button class="btn sm" data-a="scan">${ic('refresh', 's')} Verificar canais</button> <button class="btn sec sm" data-a="unscan">Mostrar todos</button></div></div>`
      + `<h4 class="sg">Adicionar lista</h4><div class="act" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:6px"><button class="btn sec sm" data-a="addurl">${ic('link', 's')} Por URL M3U</button><button class="btn sec sm" data-a="impfile">${ic('folder', 's')} Importar ficheiro</button></div>`
      + `<h4 class="sg">As suas listas</h4>` + sources.map(s => `<div class="src"><div class="hd"><span class="ico">${ic('radio')}</span><span class="grow"><b>${esc(s.name)}</b>${s.on ? '' : '<span class="tag off">Pausada</span>'}${s.core ? '<span class="tag">Fixa</span>' : ''}${/^Indispon/.test(s.status || '') ? '<span class="tag bad">Erro</span>' : ''}<small>${(s.count || 0).toLocaleString('pt-PT')} canais · ${when(s.updated)}</small>${s.status && s.status !== 'OK' ? `<small>${esc(s.status)}</small>` : ''}</span></div><div class="act"><button class="btn sec sm" data-a="upd" data-id="${s.id}">${ic('refresh', 's')} Atualizar</button><button class="btn sec sm" data-a="tog" data-id="${s.id}">${s.on ? 'Pausar' : 'Ativar'}</button>${s.core ? '' : `<button class="btn danger sm" data-a="del" data-id="${s.id}">${ic('trash', 's')} Eliminar</button>`}</div></div>`).join('');
  },
  epg: () => { const u = epgUrl(); return `<div class="blk"><h3>Fonte XMLTV</h3><p>${u ? esc(hostOf(u)) : 'Sem guia configurado.'}</p>${u ? `<small style="margin-top:6px">Atualizado: ${when(kv.get('epgat', 0))}</small>` : ''}<div class="act"><button class="btn sm" data-a="epgset">${ic('link', 's')} Definir URL XMLTV</button>${u ? `<button class="btn sec sm" data-a="epgupd">${ic('refresh', 's')} Atualizar guia</button>` : ''}</div></div><div class="note">${ic('cal')}<span>O guia mostra o programa atual e a barra de progresso nos canais cujo identificador (tvg-id) exista no ficheiro XMLTV.</span></div>`; },
  fx: () => { const at = kv.get('fx3', { at: 0 }).at, sw = on => `<i class="sw2 ${on ? 'on' : ''}"></i>`;
    return `<div class="note">${ic('ball')}<span>Próximos jogos e o canal que transmite. Jogos da ESPN e TheSportsDB; o canal pode estar por confirmar em alguns jogos.</span></div>`
      + `<h4 class="sg">Início</h4><button class="li" data-a="fxhome"><span class="grow"><b>Mostrar no Início</b><small>Jogos em destaque no topo</small></span>${sw(kv.get('fxhome', true))}</button>`
      + `<h4 class="sg">Competições</h4>` + FX_LEAGUES.map(l => `<button class="li" data-a="fxl" data-v="${l[0]}"><span class="grow"><b>${l[1]}</b></span>${sw(fxOn().includes(l[0]))}</button>`).join('')
      + `<div class="blk" style="margin-top:6px"><div class="kv"><span>Jogos em cache</span><span>${(S.fx || []).length}</span></div><div class="kv"><span>Atualizado</span><span>${when(at)}</span></div><div class="act"><button class="btn sm" data-a="fxupd">${ic('refresh', 's')} Atualizar calendário</button><button class="btn sec sm" data-a="fxclear">Repor canais escolhidos</button></div></div>`; },
  data: () => { const f = kv.get(favKey(), []).length, h = kv.get(histKey(), []).length;
    return `<div class="blk"><h3>Perfil ativo · ${esc(active.name)}</h3><div class="kv"><span>Favoritos</span><span>${f}</span></div><div class="kv"><span>Histórico</span><span>${h}</span></div><div class="act"><button class="btn sec sm" data-a="dhist">${ic('history', 's')} Limpar histórico</button><button class="btn danger sm" data-a="dfav">${ic('trash', 's')} Limpar favoritos</button></div></div>`
      + `<div class="blk"><h3>Cache</h3><div class="kv"><span>Logótipos</span><span>${Object.keys(LM()).length}</span></div><div class="kv"><span>Guia (EPG)</span><span>${Object.keys(S.epg).length} canais</span></div><div class="act"><button class="btn sec sm" data-a="rlogos">${ic('refresh', 's')} Atualizar logótipos</button><button class="btn sec sm" data-a="clrepg">Limpar guia</button></div></div>`; },
  look: () => { const th = document.documentElement.dataset.theme; return `<div class="blk"><h3>Tema</h3><div class="seg"><button class="${th !== 'light' ? 'on' : ''}" data-a="theme" data-v="dark">${ic('moon', 's')} Escuro</button><button class="${th === 'light' ? 'on' : ''}" data-a="theme" data-v="light">${ic('grid', 's')} Claro</button></div><p>A paleta petróleo e ciano é aplicada em toda a aplicação.</p></div>`; },
  play: () => { const a = kv.get('aspect', 0), q = kv.get('qcap', 480); return `<div class="blk"><h3>Qualidade de vídeo</h3><div class="seg">${[[480, 'Poupança'], [720, 'HD 720p'], [0, 'Máxima'], [-1, 'Só áudio']].map(x => `<button class="${q === x[0] ? 'on' : ''}" data-a="qcap" data-v="${x[0]}">${x[1]}</button>`).join('')}</div><p>Poupança limita o vídeo a 480p e gasta muito menos Internet. Pode mudar a qualidade durante a reprodução, tocando na etiqueta de qualidade.</p></div>
    <div class="blk"><h3>Imagens</h3><button class="li" data-a="nologo"><span class="grow"><b>Não carregar logótipos</b><small>Poupa dados; mostra iniciais no lugar</small></span><i class="sw2 ${kv.get('nologo', false) ? 'on' : ''}"></i></button></div>
    <div class="blk"><h3>Proporção predefinida</h3><div class="seg">${ASP.map((x, i) => `<button class="${a === i ? 'on' : ''}" data-a="aspect" data-v="${i}">${x}</button>`).join('')}</div><p>Também pode alterar a proporção durante a reprodução.</p></div>
    <div class="blk"><h3>No leitor</h3><div class="kv"><span>Deslizar à esquerda</span><span>Brilho</span></div><div class="kv"><span>Deslizar à direita</span><span>Volume</span></div><div class="kv"><span>Canal anterior / seguinte</span><span>Botões ou teclas CH</span></div><div class="kv"><span>Imagem sobre imagem</span><span>Botão PiP ou Início</span></div></div>`; },
  about: () => `<div class="about">${mark(72)}<h2>VISION <em>TV</em></h2><small>Smart Entertainment</small></div>
    <div class="blk"><div class="kv"><span>Versão</span><span>${esc(N.version())} (build ${N.versionCode()})</span></div><div class="kv"><span>Desenvolvido por</span><span>Haymette Tech</span></div><p class="mut" id="ust" style="margin-top:10px">${N.updateRepo() ? 'Toque abaixo para procurar uma versão mais recente.' : 'Atualizações não configuradas neste build.'}</p><div class="act"><button class="btn sm" id="ubtn" data-a="chkupd" ${N.updateRepo() ? '' : 'disabled'}>${ic('refresh', 's')} Verificar atualização</button></div></div>
    <div class="blk"><h3>Aviso legal</h3><p>Utilize apenas transmissões autorizadas. Os direitos dos canais pertencem aos respetivos titulares. Os dados ficam apenas neste dispositivo; não há analytics.</p><div class="act"><button class="btn sec sm" data-a="terms">${ic('doc', 's')} Ver licença</button><button class="btn sec sm" data-a="intro">Rever apresentação</button></div></div>`
};
function settings(r) {
  S.sr = r = r || S.sr || 'main';
  overlay('st', `<div class="ov-h"><button class="ib" data-a="sback" aria-label="Voltar">${ic('back')}</button><h1>${SET_T[r]}</h1></div><div class="ov-b">${setBody[r]()}</div>`);
}

/* ---------- Atualizações da aplicação (GitHub Releases, APK assinado) ---------- */
async function checkUpdate(manual) {
  const repo = N.updateRepo(); if (!repo) return manual ? Promise.reject(new Error('não configurado')) : null;
  try {
    const j = JSON.parse(await fetchText(`https://api.github.com/repos/${repo}/releases/latest`));
    const m = /(\d+)$/.exec(j.tag_name || ''), a = (j.assets || []).find(x => /\.apk$/i.test(x.name || ''));
    if (!m || !a) throw new Error('release sem APK');
    return +m[1] > N.versionCode() ? { build: +m[1], name: j.name || j.tag_name, notes: j.body || '', url: a.browser_download_url, size: a.size || 0 } : false;
  } catch (e) { if (manual) throw e; return null; }
}
async function promptUpdate(i) {
  if (document.querySelector('.modal')) return;
  const r = await dlg(`<h2>Nova atualização disponível</h2><p class="txt">${esc(i.name)} (build ${i.build})</p>${i.notes ? `<p class="txt">${esc(i.notes.slice(0, 300))}</p>` : ''}${i.size ? `<p class="txt">${(i.size / 1048576).toFixed(1)} MB</p>` : ''}`, () => true, 'Atualizar agora', 'Mais tarde');
  if (r) runUpdate(i);
}
async function runUpdate(i) {
  settings('about'); const st = $('#ust'), btn = $('#ubtn'); btn.disabled = true; st.textContent = 'A descarregar… 0%';
  window.__prog = p => { st.textContent = `A descarregar… ${p}%`; };
  try {
    await bridge(id => N.downloadUpdate(i.url, id));
    btn.textContent = 'Instalar'; btn.dataset.a = 'instupd'; btn.disabled = false;
    const r = N.installUpdate();
    st.textContent = r === 'perm' ? 'Permita "instalar apps desconhecidas" para o VISION TV, volte e toque em Instalar.' : r === 'ok' ? 'Confirme a instalação no ecrã do sistema.' : 'APK não encontrado.';
  } catch (e) { st.textContent = 'Erro: ' + e.message; btn.disabled = false; }
}

/* ---------- Eventos ---------- */
const closeAll = () => { document.querySelectorAll('.overlay').forEach(o => o.remove()); S.sr = 'main'; };
document.addEventListener('click', async e => {
  const b = e.target.closest('[data-a]'); if (!b) return; const a = b.dataset.a, id = b.dataset.id;
  const src = () => sources.find(s => s.id === id);
  switch (a) {
    case 'tab': S.tab = b.dataset.t; S.limit = 60; view(); if (S.tab === 'sport' && !(S.fx || []).length && !S.fxBusy && Date.now() - (S.fxTry || 0) > 12e4) updateFixtures(true); break;
    case 'play': play(b.dataset.k, b.dataset.u); break;
    case 'fxpick': fxPick(b.dataset.lg); break;
    case 'fxclear': kv.set('fxmap', {}); toast('Escolhas de canais repostas'); settings('fx'); break;
    case 'fav': toggleFav(b.dataset.u); break;
    case 'more': S.limit += 60; $('#tlw').innerHTML = tvList(); break;
    case 'cat': S.cat = b.dataset.v; if (!S.cat) { S.country = ''; S.kind = ''; } S.limit = 60; view(true); break;
    case 'kind': S.kind = S.kind === b.dataset.v ? '' : b.dataset.v; S.limit = 60; view(true); break;
    case 'cty': S.country = S.country === b.dataset.v ? '' : b.dataset.v; S.limit = 60; view(true); break;
    case 'clearsrc': S.src = ''; view(); break;
    case 'viewsrc': S.src = id; S.tab = 'tv'; view(); break;
    case 'libtab': S.lib = b.dataset.v; view(true); break;
    case 'clrhist': kv.set(histKey(), []); view(true); break;
    case 'retry': sources.filter(s => s.on).forEach(s => updateSource(s, true)); view(true); break;
    case 'updl': toast('A atualizar…'); updateSource(src()); break;
    case 'search': search(); break;
    case 'settings': openSettings(); break;
    case 'sgo': if (b.dataset.r === 'switch') { closeAll(); active = null; S.manage = false; profilesScreen(); } else settings(b.dataset.r); break;
    case 'sback': if (S.sr !== 'main') settings('main'); else { closeAll(); view(true); } break;
    case 'closeov': closeAll(); view(true); break;
    case 'back': pickProfile(kv.get('last', null)); break;
    case 'pick': pickProfile(id); break;
    case 'new': createProfile(); break;
    case 'edit': editProfile(id); break;
    case 'manage': S.manage = !S.manage; profilesScreen(); break;
    case 'manageov': closeAll(); active = null; S.manage = true; profilesScreen(); break;
    case 'terms': showTerms(false); break;
    case 'wnext': wnext(); break;
    case 'theme': document.documentElement.dataset.theme = b.dataset.v; kv.set('theme', b.dataset.v); settings('look'); break;
    case 'qcap': kv.set('qcap', +b.dataset.v); settings('play'); break;
    case 'nologo': kv.set('nologo', !kv.get('nologo', false)); settings('play'); break;
    case 'aspect': kv.set('aspect', +b.dataset.v); settings('play'); break;
    case 'chpin': if (hasPin(active.id) && !(await askPin('PIN atual', active.id))) break; await newPin(active.id); settings('profile'); break;
    case 'rmpin': if (await askPin('PIN atual', active.id)) { N.ppClear(active.id); toast('PIN removido'); } settings('profile'); break;
    case 'addurl': addSourceUrl(); break;
    case 'impfile': importFile(); break;
    case 'upd': toast('A atualizar…'); await updateSource(src()); settings('sources'); break;
    case 'tog': src().on = !src().on; saveSources(); settings('sources'); break;
    case 'del': if (src().core) break; if (await ask('Eliminar lista', `A lista "${src().name}" será removida deste dispositivo.`, 'Eliminar')) { sources = sources.filter(s => s.id !== id); kv.set('ch_' + id, []); saveSources(); } settings('sources'); break;
    case 'epgset': { const u = await dlg(`<h2>URL XMLTV</h2><label>Endereço do guia</label><input id="eu" type="url" placeholder="https://..." value="${esc(kv.get('epgurl', ''))}">`, m => { const v = m.querySelector('#eu').value.trim(); if (v && !/^https?:\/\/[^\s]+$/i.test(v)) throw new Error('URL inválido'); return v; }, 'Guardar'); if (u === null) break; kv.set('epgurl', u); if (u) { toast('A descarregar guia…'); await updateEPG(u); } else { S.epg = {}; kv.set('epg', {}); } settings('epg'); break; }
    case 'epgupd': toast('A atualizar guia…'); await updateEPG(epgUrl()); settings('epg'); break;
    case 'chkupd': { const st = $('#ust'); st.textContent = 'A verificar…'; try { const i = await checkUpdate(true); if (i === false) st.textContent = 'Já tem a versão mais recente.'; else { st.textContent = 'Nova versão disponível: build ' + i.build; promptUpdate(i); } } catch (x) { st.textContent = 'Não foi possível verificar: ' + x.message; } break; }
    case 'instupd': { const st = $('#ust'), r = N.installUpdate(); st.textContent = r === 'perm' ? 'Permita "instalar apps desconhecidas" para o VISION TV, volte e toque em Instalar.' : r === 'missing' ? 'APK não encontrado. Verifique novamente.' : 'A abrir o instalador…'; break; }
    case 'intro': closeAll(); welcome(); break;
    case 'scan': { const n = await scanChannels(true); toast(n ? `${n} canais sem sinal foram escondidos` : 'Verificação concluída'); settings('sources'); break; }
    case 'unscan': kv.set('dead', {}); kv.set('chk', {}); kv.set('fails', {}); kv.set('deadv', Date.now()); dead = new Set(); cache = null; toast('Todos os canais voltaram a aparecer'); settings('sources'); break;
    case 'updall': { toast('A atualizar listas…'); for (const x of sources.filter(y => y.on && y.url)) await updateSource(x, true); toast('Listas atualizadas'); settings('sources'); scanChannels(false); break; }
    case 'fxhome': kv.set('fxhome', !kv.get('fxhome', true)); settings('fx'); break;
    case 'fxl': { const v = +b.dataset.v, l = fxOn(), n = l.includes(v) ? l.filter(x => x !== v) : [...l, v]; kv.set('fxl', n); kv.set('fx3', { at: 0, list: [] }); S.fx = []; settings('fx'); updateFixtures(true).then(() => S.sr === 'fx' && settings('fx')); break; }
    case 'fxupd': toast('A atualizar calendário…'); await updateFixtures(true); if (document.getElementById('st')) settings('fx'); break;
    case 'dhist': if (await ask('Limpar histórico', 'O histórico deste perfil será eliminado.', 'Limpar')) kv.set(histKey(), []); settings('data'); break;
    case 'dfav': if (await ask('Limpar favoritos', 'Os favoritos deste perfil serão eliminados.', 'Limpar')) kv.set(favKey(), []); settings('data'); break;
    case 'rlogos': toast('A atualizar logótipos…'); await updateLogos(true); settings('data'); break;
    case 'clrepg': S.epg = {}; kv.set('epg', {}); kv.set('epgat', 0); toast('Guia limpo'); settings('data'); break;
  }
});
document.addEventListener('input', e => {
  const t = e.target;
  if (t.id === 'tq') { S.q = t.value; S.limit = 60; clearTimeout(vTV.h); vTV.h = setTimeout(() => { const w = $('#tlw'); if (w) w.innerHTML = tvList(); }, 200); }
});
document.addEventListener('change', e => { const t = e.target; if (t.id === 'tk') { S.country = t.value; S.limit = 60; view(true); } });
window.goBack = () => {
  const m = [...document.querySelectorAll('.modal')].pop(); if (m) { m._c(); return true; }
  if (document.getElementById('st') && S.sr !== 'main') { settings('main'); return true; }
  const o = [...document.querySelectorAll('.overlay')].pop(); if (o) { o.remove(); if (!document.querySelector('.overlay')) S.sr = 'main'; if (active) view(true); return true; }
  if (active && S.tab !== 'home' && $('#view')) { S.tab = 'home'; view(); return true; }
  return false;
};
window.onResumeApp = () => { S.playing = 0; if (active) updateFixtures(false); if (active && $('#view') && !document.querySelector('.overlay,.modal')) view(true); };
document.documentElement.dataset.theme = kv.get('theme', 'dark');
S.epg = kv.get('epg', {}); S.fx = kv.get('fx3', { list: [] }).list;
{
  const CORE = [
    { id: 'iptvpt', name: 'Portugal (iptv-org)', url: 'https://iptv-org.github.io/iptv/countries/pt.m3u', cc: 'PT', on: true },
    { id: 'iptvbr', name: 'Brasil · canais públicos (iptv-org)', url: 'https://iptv-org.github.io/iptv/countries/br.m3u', cc: 'BR', on: true },
    { id: 'iptvpor', name: 'Canais em português (iptv-org)', url: 'https://iptv-org.github.io/iptv/languages/por.m3u', on: true },
    { id: 'freebr', name: 'Brasil · Free-TV', url: 'https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_brazil.m3u8', cc: 'BR', on: true },
    { id: 'freept', name: 'Portugal · Free-TV', url: 'https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_portugal.m3u8', cc: 'PT', on: true },
    { id: 'iptvao', name: 'Angola (iptv-org)', url: 'https://iptv-org.github.io/iptv/countries/ao.m3u', cc: 'AO', on: true },
    { id: 'iptvmz', name: 'Moçambique (iptv-org)', url: 'https://iptv-org.github.io/iptv/countries/mz.m3u', cc: 'MZ', on: true },
    { id: 'iptvcv', name: 'Cabo Verde (iptv-org)', url: 'https://iptv-org.github.io/iptv/countries/cv.m3u', cc: 'CV', on: true },
    { id: 'iptvsports', name: 'Desporto e futebol (iptv-org)', url: 'https://iptv-org.github.io/iptv/categories/sports.m3u', on: true },
    { id: 'iptvmusic', name: 'Música (iptv-org)', url: 'https://iptv-org.github.io/iptv/categories/music.m3u', on: true },
    { id: 'iptvseries', name: 'Séries e novelas (iptv-org)', url: 'https://iptv-org.github.io/iptv/categories/series.m3u', on: true },
    { id: 'iptvza', name: 'África do Sul (iptv-org)', url: 'https://iptv-org.github.io/iptv/countries/za.m3u', cc: 'ZA', on: true },
    { id: 'iptvus', name: 'Estados Unidos (iptv-org)', url: 'https://iptv-org.github.io/iptv/countries/us.m3u', cc: 'US', on: true },
    { id: 'iptvgb', name: 'Reino Unido (iptv-org)', url: 'https://iptv-org.github.io/iptv/countries/uk.m3u', cc: 'GB', on: true },
    { id: 'iptvfr', name: 'França (iptv-org)', url: 'https://iptv-org.github.io/iptv/countries/fr.m3u', cc: 'FR', on: true },
    { id: 'iptvmovies', name: 'Filmes (iptv-org)', url: 'https://iptv-org.github.io/iptv/categories/movies.m3u', on: true },
    { id: 'iptvnews', name: 'Notícias (iptv-org)', url: 'https://iptv-org.github.io/iptv/categories/news.m3u', on: true },
    { id: 'iptvkids', name: 'Infantil (iptv-org)', url: 'https://iptv-org.github.io/iptv/categories/kids.m3u', on: true },
    { id: 'iptvent', name: 'Entretenimento (iptv-org)', url: 'https://iptv-org.github.io/iptv/categories/entertainment.m3u', on: true },
    { id: 'iptvorg', name: 'Canais públicos do mundo (iptv-org)', url: 'https://iptv-org.github.io/iptv/index.m3u', on: !sources.length }
  ];
  CORE.slice().reverse().forEach(d => {
    const s = sources.find(x => x.id === d.id);
    if (!s) sources.unshift({ ...d, core: true, count: 0, updated: 0, status: 'A aguardar primeira atualização' });
    else { s.core = true; if (d.cc) s.cc = d.cc; if (!['iptvorg', 'iptvpor', 'freebr', 'freept', 'iptvao', 'iptvmz', 'iptvcv'].includes(d.id)) s.on = true; }
  });
  if (!kv.get('mig2', false)) {
    sources.forEach(x => { if (['iptvpt', 'iptvbr', 'iptvpor', 'freebr', 'freept', 'plutobr', 'samsungbr', 'plexbr'].includes(x.id)) { x.on = true; x.updated = 0; } if (x.id === 'iptvorg') x.on = false; });
    kv.set('mig2', true); kv.set('fx3', { at: 0, list: [] });
  }
  if (!kv.get('mig3', false)) { /* i.mjh.nz (Plex/Pluto/Samsung) foi retirado: remover das fontes guardadas */
    ['plexbr', 'plutobr', 'samsungbr'].forEach(id => kv.set('ch_' + id, []));
    sources = sources.filter(x => !['plexbr', 'plutobr', 'samsungbr'].includes(x.id)); kv.set('mig3', true);
  }
  saveSources();
  processPlayLog();
  setTimeout(() => scanChannels(false), 45000);
}
setInterval(() => { /* mantém "ao vivo" e a lista de jogos atualizados sem recarregar tudo */
  if (!active || S.playing) return; updateFixtures(false);
  const sig = (S.fx || []).filter(f => f.ts > Date.now() - FX_LIVE).slice(0, 15).map(f => f.id + (f.ts <= Date.now() ? 'L' : '')).join();
  if (sig !== S.fxSig) { S.fxSig = sig; if (S.tab !== 'tv') refreshFx(); }
}, 60000);
kv.get('seen', false) ? profilesScreen() : welcome();
