'use strict';
/* VISION TV — Haymette Tech. Pure JavaScript UI; native features via window.Native. */
const N = window.Native, $ = s => document.querySelector(s), app = $('#app');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cbs = {}; let cid = 0;
window.__cb = (id, ok, t) => { const c = cbs[id]; delete cbs[id]; c && c(ok, t); };
const bridge = fn => new Promise((res, rej) => { const i = ++cid; cbs[i] = (ok, t) => ok ? res(t) : rej(new Error(t)); fn(i); });
const fetchText = u => bridge(i => N.fetchText(u, i));
const pickFile = () => bridge(i => N.pickFile(i));
const kv = { get(k, d) { try { const v = N.kvGet(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }, set(k, v) { return N.kvSet(k, JSON.stringify(v)); } };
const toast = m => { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.remove('show'), 2800); };

/* ---------- Age classification ---------- */
const grp = a => a < 12 ? 'kids' : a < 18 ? 'teen' : 'adult';
const GL = { kids: 'Infantil (0–11)', teen: 'Adolescente (12–17)', adult: 'Adulto (18+)' };
const ALLOW = { kids: ['KIDS'], teen: ['KIDS', 'TEEN', 'GENERAL'], adult: ['KIDS', 'TEEN', 'GENERAL', 'ADULT', 'UNKNOWN'] };
function classify(g) {
  g = (g || '').toLowerCase(); if (!g) return 'UNKNOWN';
  if (/xxx|adult|adulto|18\+|erotic|porn/.test(g)) return 'ADULT';
  if (/kid|child|infant|crian|cartoon|animat|desenh|junior|baby/.test(g)) return 'KIDS';
  if (/sport|desport|music|m[uú]sic|document|educa|scien|ci[eê]ncia|nature|natureza/.test(g)) return 'TEEN';
  if (/news|not[ií]cias|entertain|entreten|general|geral|lifestyle|cultur|weather|comedy|famil|cooking|travel|outdoor|business|legislative|religio|classic|relax|auto|shop/.test(g)) return 'GENERAL';
  return 'UNKNOWN';
}
const okFor = (c, p = active) => !!p && ALLOW[grp(p.age)].includes(c.k);
const isSport = c => /sport|desport|futebol|soccer|football/i.test(c.g || '');

/* ---------- State ---------- */
let profiles = kv.get('profiles', []), active = null, sources = kv.get('sources', []), cache = null;
const S = { tab: 'home', manage: false, cat: '', country: '', q: '', src: '', limit: 150, epg: {}, L: {} };
const saveSources = () => { kv.set('sources', sources); cache = null; };
const favKey = () => 'fav_' + active.id, histKey = () => 'hist_' + active.id;
function chans() {
  if (cache && cache.p === active.id) return cache.l;
  const l = [];
  for (const s of sources) if (s.on) for (const c of kv.get('ch_' + s.id, [])) { c.s = s.id; if (okFor(c)) l.push(c); }
  cache = { p: active.id, l }; return l;
}
const byUrl = us => { const m = new Map(chans().map(c => [c.u, c])); return us.map(u => m.get(u)).filter(Boolean); };
const favs = () => byUrl(kv.get(favKey(), []));
const hist = () => byUrl(kv.get(histKey(), []));
const isFav = c => kv.get(favKey(), []).includes(c.u);

/* ---------- M3U / XMLTV ---------- */
function parseM3U(t) {
  const out = []; let cur = null;
  for (let l of t.split(/\r?\n/)) {
    l = l.trim(); if (!l) continue;
    if (l.startsWith('#EXTINF')) {
      const a = {}; l.replace(/([\w-]+)="([^"]*)"/g, (m, k, v) => { a[k.toLowerCase()] = v; return m; });
      const n = (l.slice(l.lastIndexOf(',') + 1).trim()) || a['tvg-name'] || '';
      cur = { n, l: a['tvg-logo'] || '', g: a['group-title'] || '', t: a['tvg-id'] || '', c: (a['tvg-country'] || (/\.([a-z]{2})(?:@|$)/i.exec(a['tvg-id'] || '') || [])[1] || '').toUpperCase(), k: classify(a['group-title']) };
    } else if (l[0] !== '#' && cur) {
      if (/^https?:\/\//i.test(l) && cur.n) { cur.u = l; out.push(cur); }
      cur = null;
    }
  }
  return out;
}
function xmlTime(s) {
  const m = /^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)\s*([+-]\d{4})?/.exec(s || ''); if (!m) return 0;
  let t = Date.UTC(+m[1], m[2] - 1, +m[3], +m[4], +m[5], +m[6]);
  if (m[7]) t -= (m[7][0] === '-' ? -1 : 1) * (+m[7].slice(1, 3) * 60 + +m[7].slice(3, 5)) * 60000;
  return t;
}
function parseEPG(txt) {
  const doc = new DOMParser().parseFromString(txt, 'text/xml');
  if (doc.querySelector('parsererror')) throw new Error('XMLTV inválido');
  const now = Date.now(), out = {};
  doc.querySelectorAll('programme').forEach(p => {
    const s = xmlTime(p.getAttribute('start')), e = xmlTime(p.getAttribute('stop'));
    if (!s || !e || e < now - 6 * 3600e3 || s > now + 36 * 3600e3) return;
    const id = p.getAttribute('channel'); if (!id) return;
    (out[id] = out[id] || []).push([s, e, p.querySelector('title')?.textContent || '', p.querySelector('desc')?.textContent || '']);
  });
  return out;
}
const hh = t => new Date(t).toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });
function nowNext(c) {
  const l = c.t && S.epg[c.t]; if (!l) return null; const n = Date.now();
  const cur = l.find(p => p[0] <= n && n < p[1]); return cur ? { cur, next: l.find(p => p[0] >= cur[1]) } : null;
}
const np = c => { const x = nowNext(c); if (!x) return ''; const [s, e, t] = x.cur;
  return `<small class="np">${hh(s)}–${hh(e)} ${esc(t)}</small><i class="bar"><u style="width:${Math.round((Date.now() - s) / (e - s) * 100)}%"></u></i>`; };

/* ---------- Dialogs ---------- */
function dlg(html, collect, okL = 'OK', noL = 'Cancelar') {
  return new Promise(res => {
    const m = document.createElement('div'); m.className = 'modal';
    m.innerHTML = `<div class="glass box">${html}<p class="err" id="derr"></p><div class="row"><button class="btn sec" data-x>${noL}</button><button class="btn" data-ok>${okL}</button></div></div>`;
    document.body.append(m);
    const done = v => { m.remove(); res(v); }; m._c = () => done(null);
    m.onclick = e => {
      if (e.target.closest('[data-x]')) done(null);
      else if (e.target.closest('[data-ok]')) { try { const v = collect(m); if (v !== undefined) done(v); } catch (x) { m.querySelector('#derr').textContent = x.message; } }
    };
    (m.querySelector('input,select') || m.querySelector('[data-ok]')).focus();
  });
}
const askPin = msg => dlg(`<h2>${esc(msg)}</h2><input id="pin" type="password" inputmode="numeric" maxlength="8" placeholder="PIN parental" autocomplete="off">`, m => {
  if (N.locked()) throw new Error('Demasiadas tentativas. Aguarde 1 minuto.');
  const v = m.querySelector('#pin').value; if (!/^\d{4,8}$/.test(v)) throw new Error('O PIN tem 4 a 8 dígitos');
  if (!N.pinCheck(v)) throw new Error('PIN incorreto'); return true; });
const newPin = () => dlg(`<h2>Definir PIN parental</h2><p class="mut">4 a 8 dígitos. Protege perfis adultos e alterações sensíveis.</p><input id="p1" type="password" inputmode="numeric" maxlength="8" placeholder="Novo PIN"><input id="p2" type="password" inputmode="numeric" maxlength="8" placeholder="Repetir PIN" style="margin-top:8px">`, m => {
  const a = m.querySelector('#p1').value, b = m.querySelector('#p2').value;
  if (!/^\d{4,8}$/.test(a)) throw new Error('O PIN tem 4 a 8 dígitos'); if (a !== b) throw new Error('Os PIN não coincidem');
  return N.pinSet(a); });
async function ensurePin() { if (N.pinExists()) return true; return !!(await newPin()); }

/* ---------- Welcome ---------- */
function welcome() {
  app.innerHTML = `<div class="wel glass"><h1>VISION <span style="color:var(--cyan)">TV</span></h1><p class="mut">Smart Entertainment</p>
  <div class="scroll" id="sc"><h2>O que é</h2><p>O VISION TV é uma plataforma para organizar e assistir a canais de televisão através de fontes que você configura, com perfis familiares e controlo parental.</p>
  <h2>Canais e fontes</h2><p>A aplicação organiza canais e fontes de transmissão. Não hospeda canais: vem pré-configurada com a lista pública mundial do projeto iptv-org (canais disponibilizados publicamente, sem conteúdo adulto) e permite adicionar as suas próprias listas em Definições › Fontes de transmissão. A disponibilidade de cada canal depende do respetivo emissor.</p>
  <h2>Perfis e idade</h2><p>Até 3 perfis locais. Cada perfil tem uma faixa etária (0–11, 12–17, 18+) que filtra os conteúdos. A classificação depende dos metadados da fonte (ex.: group-title); conteúdo sem classificação fiável é ocultado em perfis de menores. Nenhum filtro substitui a supervisão de um adulto.</p>
  <h2>Privacidade</h2><p>Funciona sem conta e sem registo. Perfis, idades, favoritos e listas ficam apenas neste dispositivo. Não existem analytics nem rastreamento. É necessária Internet para reproduzir e atualizar fontes.</p>
  <h2>Licença e avisos legais</h2><p>Utilize apenas transmissões e listas cujo acesso e utilização sejam autorizados. Os direitos de cada canal e transmissão pertencem aos respetivos titulares; o VISION TV não detém direitos sobre conteúdos de terceiros nem contorna DRM, autenticação ou restrições de acesso. A responsabilidade pelas fontes adicionadas é do utilizador.</p>
  <h2>Criador</h2><p>Desenvolvido por Haymette Tech.</p><p class="mut">Versão ${esc(N.version())}</p><p class="mut">— Fim —</p></div>
  <div class="row"><span class="mut grow" id="hint">Percorra até ao fim para continuar</span><button class="btn" id="nx" disabled>Seguinte</button></div></div>`;
  const sc = $('#sc'), nx = $('#nx');
  const chk = () => { if (sc.scrollTop + sc.clientHeight >= sc.scrollHeight - 6 && nx.disabled) { nx.disabled = false; nx.classList.add('pulse'); $('#hint').textContent = 'Pode continuar'; } };
  sc.onscroll = chk; setTimeout(chk, 300);
  nx.onclick = () => { kv.set('seen', true); profilesScreen(); };
}

/* ---------- Profiles ---------- */
const AVATARS = ['🦊', '🐼', '🦁', '🐙', '🚀', '🎬', '🦄', '🐬'];
function profilesScreen() {
  const last = kv.get('last', null);
  app.innerHTML = `<div class="center glass"><h1>Quem está a assistir?</h1>${S.manage ? '<p class="mut">Escolha um perfil para editar.</p>' : ''}<div class="prof">${profiles.map(p => `<button class="pf ${p.id === last ? 'last' : ''}" data-a="${S.manage ? 'edit' : 'pick'}" data-id="${p.id}"><span class="av">${p.av}</span><b>${esc(p.name)}</b><small>${p.age} anos · ${GL[grp(p.age)].split(' ')[0]}</small></button>`).join('')}${profiles.length < 3 ? '<button class="pf add" data-a="new"><span class="av">＋</span>Adicionar perfil</button>' : ''}</div>${profiles.length >= 3 ? '<p class="mut">Limite máximo de 3 perfis atingido.</p>' : ''}${profiles.length ? `<button class="btn sec" data-a="manage">${S.manage ? 'Concluído' : 'Gerir perfis'}</button>` : ''}${active ? '<button class="btn sec" data-a="back" style="margin-left:8px">Voltar</button>' : ''}</div>`;
}
function profileForm(p) {
  return dlg(`<h2>${p ? 'Editar perfil' : 'Novo perfil'}</h2><label>Nome</label><input id="pn" maxlength="20" value="${esc(p?.name || '')}"><label>Idade (0 a 100)</label><input id="pa" type="number" min="0" max="100" value="${p ? p.age : ''}"><label>Avatar</label><select id="pv">${AVATARS.map(a => `<option ${p?.av === a ? 'selected' : ''}>${a}</option>`).join('')}</select>${p ? '<button class="btn danger" id="pd" style="margin-top:14px;width:100%">Eliminar perfil</button>' : ''}`, m => {
    if (m._del) return { del: true };
    const name = m.querySelector('#pn').value.trim().replace(/\s+/g, ' '), raw = m.querySelector('#pa').value, age = Number(raw);
    if (!name) throw new Error('Indique um nome'); if (!/^\d+$/.test(raw) || age < 0 || age > 100) throw new Error('Idade inválida (0 a 100)');
    if (profiles.some(x => x.id !== p?.id && x.name.toLowerCase() === name.toLowerCase())) throw new Error('Já existe um perfil com esse nome');
    return { name, age, av: m.querySelector('#pv').value };
  });
}
document.addEventListener('click', e => { const d = e.target.closest('#pd'); if (d) { const m = d.closest('.modal'); m._del = true; m.querySelector('[data-ok]').click(); } }, true);
async function createProfile() {
  if (profiles.length >= 3) return toast('Máximo de 3 perfis');
  if (!(await ensurePin())) return toast('É necessário definir um PIN parental');
  const v = await profileForm(null); if (!v) return;
  profiles.push({ id: 'p' + Date.now(), created: Date.now(), ...v }); kv.set('profiles', profiles); profilesScreen();
}
async function editProfile(id) {
  const p = profiles.find(x => x.id === id); if (!p) return;
  if (!(await askPin('PIN parental para editar o perfil'))) return;
  const v = await profileForm(p); if (!v) return;
  if (v.del) { if (confirm('Eliminar este perfil e os seus dados?')) { profiles = profiles.filter(x => x.id !== id); kv.set('profiles', profiles); kv.set('fav_' + id, []); kv.set('hist_' + id, []); } }
  else { Object.assign(p, v); kv.set('profiles', profiles); }
  profilesScreen();
}
async function pickProfile(id) {
  const p = profiles.find(x => x.id === id); if (!p) return;
  if (p.age >= 18 && N.pinExists() && !(await askPin('PIN parental para entrar no perfil adulto'))) return;
  active = p; cache = null; kv.set('last', id); S.tab = 'home'; shell(); if (sources.some(s => !s.updated)) toast('A carregar canais públicos… pode demorar um pouco'); autoUpdate(); if (!S.chk) { S.chk = 1; setTimeout(() => checkUpdate(false).then(i => i && promptUpdate(i)), 4000); }
}

/* ---------- Shell & views ---------- */
const TABS = [['home', '🏠', 'Início'], ['tv', '📺', 'TV'], ['sport', '⚽', 'Desporto'], ['lists', '📋', 'Listas'], ['lib', '⭐', 'Biblioteca']];
function shell() {
  app.innerHTML = `<header class="glass"><b class="logo">VISION <span>TV</span></b><span class="grow"></span><button data-a="search" aria-label="Pesquisar">🔍</button><button data-a="settings" aria-label="Definições">⚙️</button><button data-a="switch" aria-label="Trocar de perfil">${active.av}</button></header><main id="view"></main><nav class="glass">${TABS.map(t => `<button data-a="tab" data-t="${t[0]}"><span>${t[1]}</span>${t[2]}</button>`).join('')}</nav>`;
  view();
}
function view() {
  S.L = {}; document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.t === S.tab));
  const v = $('#view'); v.innerHTML = { home: vHome, tv: vTV, sport: vSport, lists: vLists, lib: vLib }[S.tab](); 
}
const logo = c => c.l && /^https?:\/\//i.test(c.l) ? `<img class="lg" loading="lazy" src="${esc(c.l)}" alt="" data-i="${esc((c.n || '?')[0].toUpperCase())}">` : `<span class="lg">${esc((c.n || '?')[0].toUpperCase())}</span>`;
document.addEventListener('error', e => { const t = e.target; if (t.tagName === 'IMG' && t.dataset.i) { const s = document.createElement('span'); s.className = 'lg'; s.textContent = t.dataset.i; t.replaceWith(s); } }, true);
const empty = (t, d, a) => `<div class="glass empty"><h2>${t}</h2><p class="mut">${d}</p>${a ? '<button class="btn" data-a="settings">Abrir definições</button>' : ''}</div>`;
const sec = (t, b) => b ? `<section><h2>${t}</h2>${b}</section>` : '';
const cards = (l, k) => { S.L[k] = l; return `<div class="hs">${l.map(c => `<button class="card" data-a="play" data-k="${k}" data-u="${esc(c.u)}">${logo(c)}<b>${esc(c.n)}</b><small>${esc(c.g || '')}</small></button>`).join('')}</div>`; };
const rows = (l, k) => { S.L[k] = l; return l.map(c => `<div class="ch"><button class="play" data-a="play" data-k="${k}" data-u="${esc(c.u)}">${logo(c)}<span class="grow"><b>${esc(c.n)}</b><small>${esc([c.g, c.c].filter(Boolean).join(' · '))}</small>${np(c)}</span></button><button class="star ${isFav(c) ? 'on' : ''}" data-a="fav" data-u="${esc(c.u)}" aria-label="Favorito">★</button></div>`).join(''); };

function vHome() {
  if (!sources.length) return empty('Ainda não há fontes', 'Adicione listas autorizadas em Definições › Fontes de transmissão. O VISION TV não inclui canais próprios.', 1);
  const all = chans(), h = hist(), f = favs(), epgOn = Object.keys(S.epg).length > 0;
  const live = [...h, ...f].filter((c, i, a) => a.findIndex(x => x.u === c.u) === i).filter(c => nowNext(c));
  const banner = h[0] ? `<div class="glass banner"><small>Continuar a assistir</small><h1>${esc(h[0].n)}</h1><p class="mut">${esc(h[0].g || '')}</p><button class="btn" data-a="play" data-k="b" data-u="${esc(h[0].u)}">▶ Continuar</button></div>` : '';
  S.L.b = [h[0]].filter(Boolean);
  return banner + sec('Últimos canais', h.length ? cards(h.slice(0, 15), 'h') : '') + sec('Favoritos', f.length ? cards(f.slice(0, 15), 'f') : '')
    + sec('Programação de hoje', live.length ? rows(live.slice(0, 8), 'e') : `<p class="mut">Programação indisponível${epgOn ? ' para os seus canais' : ''}.</p>`)
    + sec('Desporto', cards(all.filter(isSport).slice(0, 15), 's')) + sec('Canais populares', cards(all.slice(0, 20), 'a'))
    + (all.length ? '' : empty('Sem canais disponíveis', 'Nenhum canal permitido para este perfil nas fontes ativas.'));
}
function vTV() {
  let l = chans(); if (S.src) l = l.filter(c => c.s === S.src);
  const cats = [...new Set(l.map(c => c.g).filter(Boolean))].sort(), ctr = [...new Set(l.map(c => c.c).filter(Boolean))].sort();
  if (S.cat) l = l.filter(c => c.g === S.cat); if (S.country) l = l.filter(c => c.c === S.country);
  if (S.q) l = l.filter(c => c.n.toLowerCase().includes(S.q.toLowerCase()));
  const opt = (a, v, all) => `<option value="">${all}</option>${a.map(x => `<option ${x === v ? 'selected' : ''}>${esc(x)}</option>`).join('')}`;
  return `<div class="filters"><input id="tq" type="search" placeholder="Pesquisar canais" value="${esc(S.q)}"><select id="tc">${opt(cats, S.cat, 'Todas as categorias')}</select>${ctr.length ? `<select id="tk">${opt(ctr, S.country, 'Todos os países')}</select>` : ''}</div>${S.src ? `<button class="btn sec" data-a="clearsrc">Lista: ${esc(sources.find(s => s.id === S.src)?.name || '')} ✕</button>` : ''}`
    + (l.length ? `<div id="tl">${rows(l.slice(0, S.limit), 'tv')}</div>${l.length > S.limit ? '<button class="btn sec" data-a="more" style="width:100%">Mostrar mais</button>' : ''}` : empty('Sem canais', sources.length ? 'Nenhum canal corresponde aos filtros ou ao perfil ativo.' : 'Adicione fontes em Definições.', !sources.length));
}
function vSport() {
  const l = chans().filter(isSport);
  return `<div class="glass empty"><h2>Jogos e resultados</h2><p class="mut">Não há fonte de calendário desportivo configurada, por isso não são apresentados jogos, horários nem resultados. Os canais de desporto das suas listas aparecem abaixo.</p></div>` + sec('Canais de desporto', l.length ? rows(l.slice(0, 200), 'sp') : '<p class="mut">Nenhum canal de desporto disponível.</p>');
}
function vLists() {
  if (!sources.length) return empty('Nenhuma lista', 'Adicione fontes em Definições › Fontes de transmissão.', 1);
  return sources.map(s => `<div class="glass set"><b>${esc(s.name)}</b> ${s.on ? '' : '(pausada)'}<small>${esc(s.url ? new URL(s.url).host : 'Ficheiro local')} · ${s.count} canais</small><small>Atualizada: ${s.updated ? new Date(s.updated).toLocaleString('pt-PT') : '—'} · ${esc(s.status || '')}</small><div class="row"><button class="btn sec" data-a="viewsrc" data-id="${s.id}">Ver canais</button></div></div>`).join('');
}
function vLib() {
  const f = favs(), h = hist();
  return sec('Favoritos', f.length ? rows(f, 'lf') : '<p class="mut">Sem favoritos. Toque em ★ num canal.</p>') + sec('Histórico', h.length ? rows(h, 'lh') + '<button class="btn sec" data-a="clrhist">Limpar histórico</button>' : '<p class="mut">Sem histórico.</p>');
}

/* ---------- Playback ---------- */
function play(k, u) {
  const l = S.L[k] || []; const i = l.findIndex(c => c.u === u); if (i < 0) return;
  const c = l[i];
  if (!okFor(c)) return toast('Conteúdo não permitido para este perfil');
  const from = Math.max(0, i - 100), items = l.slice(from, from + 300).filter(okFor).map(x => ({ n: x.n, u: x.u }));
  const idx = items.findIndex(x => x.u === u);
  if (!N.play(JSON.stringify({ items, i: idx }))) return toast('Não foi possível iniciar a reprodução');
  const hk = histKey(); kv.set(hk, [u, ...kv.get(hk, []).filter(x => x !== u)].slice(0, 30));
}
function toggleFav(u) { const k = favKey(), l = kv.get(k, []); kv.set(k, l.includes(u) ? l.filter(x => x !== u) : [u, ...l]); if (S.tab === 'lib' || S.tab === 'home') view(); else document.querySelectorAll(`.star[data-u="${CSS.escape(u)}"]`).forEach(b => b.classList.toggle('on')); }

/* ---------- Sources ---------- */
async function storeSource(id, name, url, text) {
  const l = parseM3U(text); if (!l.length) throw new Error('Nenhum canal válido encontrado na lista');
  if (!kv.set('ch_' + id, l)) throw new Error('Lista demasiado grande para guardar');
  const s = sources.find(x => x.id === id); Object.assign(s, { name, url, count: l.length, updated: Date.now(), status: 'OK' }); saveSources();
}
async function addSourceUrl() {
  const v = await dlg(`<h2>Adicionar lista por URL</h2><p class="mut">Utilize apenas listas que tem autorização para aceder.</p><label>Nome</label><input id="sn" maxlength="40"><label>URL M3U/M3U8</label><input id="su" type="url" placeholder="https://..."><label>Origem autorizada</label><select id="sa"><option value="">Selecione…</option><option>Fonte pública / gratuita</option><option>Lista pessoal autorizada</option></select>`, m => {
    const n = m.querySelector('#sn').value.trim(), u = m.querySelector('#su').value.trim();
    if (!n) throw new Error('Indique um nome'); if (!/^https?:\/\/[^\s]+$/i.test(u)) throw new Error('URL inválido');
    if (!m.querySelector('#sa').value) throw new Error('Confirme a origem autorizada'); return { n, u }; });
  if (!v) return; const id = 's' + Date.now(); toast('A descarregar lista…');
  try { sources.push({ id, name: v.n, url: v.u, on: true, count: 0, updated: 0, status: '' }); const t = await fetchText(v.u); await storeSource(id, v.n, v.u, t); toast('Lista adicionada'); }
  catch (e) { sources = sources.filter(s => s.id !== id); saveSources(); toast('Erro: ' + e.message); }
  settings();
}
async function importFile() {
  try {
    const t = await pickFile(); if (!/#EXTM3U|#EXTINF/.test(t.slice(0, 4000))) throw new Error('Ficheiro M3U/M3U8 inválido');
    const v = await dlg(`<h2>Nome da lista</h2><input id="sn" maxlength="40" value="Lista importada">`, m => m.querySelector('#sn').value.trim() || undefined); if (!v) return;
    const id = 's' + Date.now(); sources.push({ id, name: v, url: '', on: true, count: 0, updated: 0, status: '' });
    try { await storeSource(id, v, '', t); toast('Lista importada'); } catch (e) { sources = sources.filter(s => s.id !== id); saveSources(); throw e; }
  } catch (e) { if (e.message !== 'Cancelado') toast('Erro: ' + e.message); }
  settings();
}
async function updateSource(s, quiet) {
  try { await updateSource0(s, quiet); } finally { if (active && $('#view') && !document.querySelector('.overlay,.modal')) view(); }
}
async function updateSource0(s, quiet) {
  if (!s.url) return quiet || toast('Listas de ficheiro não se atualizam por URL');
  try { await storeSource(s.id, s.name, s.url, await fetchText(s.url)); quiet || toast('Lista atualizada'); }
  catch (e) { s.status = 'Indisponível: ' + e.message; saveSources(); quiet || toast('Erro: ' + e.message); }
}
async function updateEPG(u, quiet) {
  try { S.epg = parseEPG(await fetchText(u)); kv.set('epg', S.epg); kv.set('epgat', Date.now()); quiet || toast('Guia atualizado'); }
  catch (e) { quiet || toast('Erro EPG: ' + e.message); }
}
function autoUpdate() {
  sources.filter(s => s.on && s.url && Date.now() - s.updated > 864e5).forEach(s => updateSource(s, true));
  const u = kv.get('epgurl', ''); if (u && Date.now() - kv.get('epgat', 0) > 864e5) updateEPG(u, true);
}

/* ---------- Search & settings ---------- */
function overlay(id, html) { let o = document.getElementById(id); if (!o) { o = document.createElement('div'); o.id = id; o.className = 'overlay'; document.body.append(o); } o.innerHTML = html; return o; }
function search() {
  const o = overlay('so', `<div class="row" style="margin:0"><input id="sq" type="search" placeholder="Pesquisar canais" autofocus><button class="btn sec" data-a="closeov">Fechar</button></div><div id="sr"></div>`);
  const inp = $('#sq'); inp.oninput = () => { const q = inp.value.trim().toLowerCase(); S.L.q = q.length < 2 ? [] : chans().filter(c => c.n.toLowerCase().includes(q) || (c.g || '').toLowerCase().includes(q)).slice(0, 100); $('#sr').innerHTML = q.length < 2 ? '' : S.L.q.length ? rows(S.L.q, 'q') : '<p class="mut">Sem resultados.</p>'; }; inp.focus();
}
async function openSettings() {
  if (grp(active.age) !== 'adult') { if (!N.pinExists()) return toast('Peça a um adulto para definir o PIN'); if (!(await askPin('PIN parental para abrir as definições'))) return; }
  settings();
}
function settings() {
  const th = document.documentElement.dataset.theme, epg = kv.get('epgurl', '');
  overlay('st', `<div class="row" style="margin:0"><h1 class="grow">Definições</h1><button class="btn sec" data-a="closeov">Fechar</button></div>
  <div class="glass set"><h2>Aparência</h2><div class="row"><button class="btn sec" data-a="theme">Tema: ${th === 'light' ? 'Claro' : 'Escuro'} (alternar)</button></div></div>
  <div class="glass set"><h2>Perfis e família</h2><p class="mut">Perfil ativo: ${active.av} ${esc(active.name)} (${GL[grp(active.age)]})</p><div class="row"><button class="btn sec" data-a="manageov">Gerir perfis</button><button class="btn sec" data-a="chpin">${N.pinExists() ? 'Alterar' : 'Definir'} PIN</button></div><p class="mut">Perfis infantis só mostram conteúdo classificado como infantil; a validação repete-se antes de cada reprodução.</p></div>
  <div class="glass set"><h2>Fontes de transmissão</h2><div class="row"><button class="btn" data-a="addurl">Adicionar URL M3U</button><button class="btn sec" data-a="impfile">Importar M3U/M3U8</button></div>
  ${sources.map(s => `<div class="src"><b>${esc(s.name)}</b><small>${s.count} canais · ${s.updated ? new Date(s.updated).toLocaleString('pt-PT') : '—'} · ${esc(s.status || '')}${s.on ? '' : ' · pausada'}${s.core ? ' · lista fixa' : ''}</small><div class="row"><button class="btn sec" data-a="upd" data-id="${s.id}">Atualizar</button>${s.core ? '' : `<button class="btn sec" data-a="tog" data-id="${s.id}">${s.on ? 'Pausar' : 'Ativar'}</button><button class="btn danger" data-a="del" data-id="${s.id}">Eliminar</button>`}</div></div>`).join('')}
  <h2>Guia de programação (XMLTV)</h2><p class="mut">${epg ? esc(new URL(epg).host) : 'Sem guia configurado.'}</p><div class="row"><button class="btn sec" data-a="epgset">Definir URL XMLTV</button>${epg ? '<button class="btn sec" data-a="epgupd">Atualizar guia</button>' : ''}</div></div>
  <div class="glass set"><h2>Reprodução</h2><p class="mut">Ecrã inteiro horizontal, fila de canais (anterior/seguinte), botão Proporção e Picture-in-Picture ao sair da aplicação (se o dispositivo suportar).</p></div>
  <div class="glass set"><h2>Sobre o VISION TV</h2><div class="row"><button class="btn sec" data-a="verpage">Versão ${esc(N.version())} (build ${N.versionCode()}) ›</button></div><p>Desenvolvido por Haymette Tech</p><p class="mut">Smart Entertainment. Utilize apenas transmissões autorizadas. Os direitos dos canais pertencem aos respetivos titulares. Os dados ficam apenas neste dispositivo; não há analytics.</p><div class="row"><button class="btn sec" data-a="intro">Rever apresentação</button></div></div>`);
}

/* ---------- App updates (GitHub Releases, signed APK) ---------- */
function verPage() {
  const cfg = !!N.updateRepo();
  overlay('up', `<div class="row" style="margin:0"><h1 class="grow">VISION TV</h1><button class="btn sec" data-a="closeup">Voltar</button></div><div class="glass set"><h2>Versão atual</h2><p><b>${esc(N.version())}</b> <span class="mut">(build ${N.versionCode()})</span></p><p class="mut" id="ust">${cfg ? 'Toque abaixo para procurar uma versão mais recente.' : 'Atualizações não configuradas neste build.'}</p><div class="row"><button class="btn" id="ubtn" data-a="chkupd" ${cfg ? '' : 'disabled'}>Verificar nova atualização</button></div></div>`);
}
async function checkUpdate(manual) {
  const repo = N.updateRepo(); if (!repo) return manual ? Promise.reject(new Error('não configurado')) : null;
  try {
    const j = JSON.parse(await fetchText(`https://api.github.com/repos/${repo}/releases/latest`));
    const m = /(\d+)$/.exec(j.tag_name || ''), a = (j.assets || []).find(x => /\.apk$/i.test(x.name || ''));
    if (!m || !a) throw new Error('release sem APK');
    return +m[1] > N.versionCode() ? { build: +m[1], name: j.name || j.tag_name, notes: j.body || '', url: a.browser_download_url, size: a.size || 0 } : false;
  } catch (e) { if (manual) throw e; return null; }
}
async function promptUpdate(i) {
  if (document.querySelector('.modal')) return;
  const r = await dlg(`<h2>Nova atualização disponível</h2><p>${esc(i.name)} (build ${i.build})</p>${i.notes ? `<p class="mut">${esc(i.notes.slice(0, 300))}</p>` : ''}${i.size ? `<p class="mut">${(i.size / 1048576).toFixed(1)} MB</p>` : ''}`, () => true, 'Atualizar agora', 'Mais tarde');
  if (r) runUpdate(i);
}
async function runUpdate(i) {
  verPage(); const st = $('#ust'), btn = $('#ubtn'); btn.disabled = true; st.textContent = 'A descarregar… 0%';
  window.__prog = p => { st.textContent = `A descarregar… ${p}%`; };
  try {
    await bridge(id => N.downloadUpdate(i.url, id));
    btn.textContent = 'Instalar'; btn.dataset.a = 'instupd'; btn.disabled = false;
    const r = N.installUpdate();
    st.textContent = r === 'perm' ? 'Permita "instalar apps desconhecidas" para o VISION TV, volte e toque em Instalar.' : r === 'ok' ? 'Confirme a instalação no ecrã do sistema.' : 'APK não encontrado.';
  } catch (e) { st.textContent = 'Erro: ' + e.message; btn.disabled = false; }
}

/* ---------- Event delegation ---------- */
document.addEventListener('click', async e => {
  const b = e.target.closest('[data-a]'); if (!b) return; const a = b.dataset.a, id = b.dataset.id;
  const src = () => sources.find(s => s.id === id);
  switch (a) {
    case 'tab': S.tab = b.dataset.t; S.limit = 150; view(); break;
    case 'play': play(b.dataset.k, b.dataset.u); break;
    case 'fav': toggleFav(b.dataset.u); break;
    case 'more': S.limit += 150; view(); break;
    case 'clearsrc': S.src = ''; view(); break;
    case 'viewsrc': S.src = id; S.tab = 'tv'; view(); break;
    case 'clrhist': kv.set(histKey(), []); view(); break;
    case 'search': search(); break;
    case 'settings': openSettings(); break;
    case 'closeov': document.querySelectorAll('.overlay').forEach(o => o.remove()); view(); break;
    case 'switch': if (grp(active.age) !== 'adult' && N.pinExists() && !(await askPin('PIN parental para trocar de perfil'))) break; active = null; S.manage = false; profilesScreen(); break;
    case 'back': pickProfile(kv.get('last', null)); break;
    case 'pick': pickProfile(id); break;
    case 'new': createProfile(); break;
    case 'edit': editProfile(id); break;
    case 'manage': S.manage = !S.manage; profilesScreen(); break;
    case 'manageov': document.querySelectorAll('.overlay').forEach(o => o.remove()); active = null; S.manage = true; profilesScreen(); break;
    case 'theme': { const t = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light'; document.documentElement.dataset.theme = t; kv.set('theme', t); settings(); break; }
    case 'chpin': if (N.pinExists() && !(await askPin('PIN atual'))) break; await newPin(); settings(); break;
    case 'addurl': addSourceUrl(); break;
    case 'impfile': importFile(); break;
    case 'upd': toast('A atualizar…'); await updateSource(src()); settings(); break;
    case 'tog': if (src().core) break; src().on = !src().on; saveSources(); settings(); break;
    case 'del': if (src().core) break; if (confirm('Eliminar esta lista?')) { sources = sources.filter(s => s.id !== id); kv.set('ch_' + id, []); saveSources(); settings(); } break;
    case 'epgset': { const u = await dlg(`<h2>URL XMLTV</h2><input id="eu" type="url" placeholder="https://..." value="${esc(kv.get('epgurl', ''))}">`, m => { const v = m.querySelector('#eu').value.trim(); if (v && !/^https?:\/\/[^\s]+$/i.test(v)) throw new Error('URL inválido'); return v; }); if (u === null) break; kv.set('epgurl', u); if (u) { toast('A descarregar guia…'); await updateEPG(u); } else { S.epg = {}; kv.set('epg', {}); } settings(); break; }
    case 'epgupd': toast('A atualizar guia…'); await updateEPG(kv.get('epgurl', '')); settings(); break;
    case 'verpage': verPage(); break;
    case 'closeup': $('#up')?.remove(); break;
    case 'chkupd': { const st = $('#ust'); st.textContent = 'A verificar…'; try { const i = await checkUpdate(true); if (i === false) st.textContent = 'Já tem a versão mais recente.'; else { st.textContent = 'Nova versão disponível: build ' + i.build; promptUpdate(i); } } catch (x) { st.textContent = 'Não foi possível verificar: ' + x.message; } break; }
    case 'instupd': { const st = $('#ust'), r = N.installUpdate(); st.textContent = r === 'perm' ? 'Permita "instalar apps desconhecidas" para o VISION TV, volte e toque em Instalar.' : r === 'missing' ? 'APK não encontrado. Verifique novamente.' : 'A abrir o instalador…'; break; }
    case 'intro': document.querySelectorAll('.overlay').forEach(o => o.remove()); welcome(); break;
  }
});
document.addEventListener('input', e => {
  const t = e.target;
  if (t.id === 'tq') { S.q = t.value; S.limit = 150; clearTimeout(vTV.h); vTV.h = setTimeout(() => { const p = t.selectionStart; view(); const n = $('#tq'); n.focus(); n.setSelectionRange(p, p); }, 250); }
});
document.addEventListener('change', e => { const t = e.target; if (t.id === 'tc') { S.cat = t.value; view(); } if (t.id === 'tk') { S.country = t.value; view(); } });
window.goBack = () => {
  const m = [...document.querySelectorAll('.modal')].pop(); if (m) { m._c(); return true; }
  const o = [...document.querySelectorAll('.overlay')].pop(); if (o) { o.remove(); if (active) view(); return true; }
  if (active && S.tab !== 'home' && $('#view')) { S.tab = 'home'; view(); return true; }
  return false;
};
document.documentElement.dataset.theme = kv.get('theme', 'dark');
S.epg = kv.get('epg', {});
{
  const core = sources.find(s => s.id === 'iptvorg');
  if (!core) sources.unshift({ id: 'iptvorg', core: true, name: 'Canais públicos do mundo (iptv-org)', url: 'https://iptv-org.github.io/iptv/index.m3u', on: true, count: 0, updated: 0, status: 'A aguardar primeira atualização' });
  else { core.core = true; core.on = true; }
  saveSources();
}
kv.get('seen', false) ? profilesScreen() : welcome();
