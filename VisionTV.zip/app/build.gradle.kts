plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.haymette.visiontv"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.haymette.visiontv"
        minSdk = 26
        targetSdk = 34
        versionCode = (project.findProperty("VERSION_CODE") as String?)?.toIntOrNull() ?: 1
        versionName = "1.0"
        buildConfigField("String", "UPDATE_REPO", "\"${(project.findProperty("UPDATE_REPO") as String?) ?: ""}\"")
    }
    buildFeatures { buildConfig = true }
    signingConfigs {
        create("release") {
            val pass = System.getenv("KS_PASSWORD")?.takeIf { it.isNotBlank() } ?: "visiontv123"
            storeFile = rootProject.file("keystore/visiontv.jks")
            storePassword = pass
            keyAlias = "visiontv"
            keyPassword = pass
        }
    }
    buildTypes { release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("release") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.3.1")
    implementation("androidx.media3:media3-datasource:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    implementation("androidx.core:core:1.12.0")
}
