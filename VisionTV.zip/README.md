# VISION TV 1.0 — Haymette Tech
Kotlin (Media3/ExoPlayer) + HTML/CSS/JS puro em WebView. Sem Firebase, sem contas, sem analytics.

Compilar: Android Studio (abrir a pasta) ou `gradle assembleDebug`.

## Estrutura
- `app/src/main/assets` — interface (index.html com sprite de ícones SVG, style.css, app.js). Sem emojis: todos os ícones são SVG.
- `PlayerActivity.kt` — leitor nativo próprio (controlos, lista lateral de canais, favoritos, proporção, gestos de volume/brilho, repetição automática, PiP).
- `res/drawable/ic_pl_*.xml` — ícones vetoriais do leitor.

## Design
Paleta petróleo/ciano (variáveis CSS em `:root`), tema escuro por defeito e tema claro opcional.

## Correções (versão 1.0)
- Logótipos de canais: `tvg-logo` da lista → logótipo da base iptv-org (`logos.json`) → distintivo com iniciais; fallback http→https.
- Fontes fixas: Portugal, Brasil (canais públicos iptv-org) e Mundo; PT/BR aparecem primeiro; atalhos "Portugal"/"Brasil" em TV.
- Correção do fecho da app ao reproduzir: lista de reprodução via `PlayData` (sem Intent gigante), `onRenderProcessGone` na WebView, decodificador alternativo, redirecionamentos http↔https, User-Agent/Referer por canal (`#EXTVLCOPT`), `largeHeap`, suporte DASH.
- Calendário de futebol em destaque no Início (Liga Portugal, Brasileirão, Champions) com o canal que transmite.

## Início (versão 1.0)
- Destaque, cartões e "Programação de Hoje" com o logótipo do canal como imagem de fundo (ligeiro desfoque) e o texto por cima; tenta https primeiro e usa alternativas se o logótipo falhar.
- Calendário de futebol: ESPN + TheSportsDB com fusão de duplicados (Sporting CP / Sporting Lisbon, SL Benfica / Benfica), canal correto da transmissão, atualização a cada 30 min, "ao vivo" até 2h30, lista agrupada por dia em Desporto e atualização automática da lista sem reabrir a app.
- Pedidos de rede seguem redirecionamentos http↔https; favoritos no leitor usam o endereço original do canal.
