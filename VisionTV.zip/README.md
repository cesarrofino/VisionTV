# VISION TV 1.0 — Haymette Tech
Kotlin (Media3/ExoPlayer) + HTML/CSS/JS puro em WebView. Sem Firebase, sem contas, sem analytics.
Compilar: Android Studio (abrir a pasta) ou `gradle assembleDebug`. UI em app/src/main/assets.
